--
-- PostgreSQL database dump
--

\restrict mjlx64shom0GQxreFF10m7cbfBuO5ONgR1qZQqTg6L4ysBEoJ1azP4Tpkdx8Oms

-- Dumped from database version 13.22
-- Dumped by pg_dump version 13.22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_applications (
    id bigint NOT NULL,
    tenant_id bigint,
    name character varying(255) NOT NULL,
    slug character varying(64) NOT NULL,
    api_key_hash character varying(255) NOT NULL,
    payment_gateways json,
    allowed_ips json,
    webhook_url character varying(512),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    webhook_secret character varying(64),
    logo character varying(512),
    checkout_sidebar_bg character varying(32),
    default_return_url character varying(512)
);


--
-- Name: api_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_applications_id_seq OWNED BY public.api_applications.id;


--
-- Name: api_checkout_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_checkout_sessions (
    id bigint NOT NULL,
    api_application_id bigint NOT NULL,
    tenant_id bigint,
    session_token character varying(64) NOT NULL,
    customer json NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'BRL'::character varying NOT NULL,
    product_id character varying(36),
    product_offer_id bigint,
    subscription_plan_id bigint,
    metadata json,
    return_url character varying(512),
    expires_at timestamp(0) without time zone NOT NULL,
    order_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: api_checkout_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_checkout_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_checkout_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_checkout_sessions_id_seq OWNED BY public.api_checkout_sessions.id;


--
-- Name: branding_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_settings (
    id bigint NOT NULL,
    tenant_id bigint,
    data json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: branding_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.branding_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: branding_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.branding_settings_id_seq OWNED BY public.branding_settings.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: cademi_integration_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cademi_integration_product (
    id bigint NOT NULL,
    cademi_integration_id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    cademi_tag_id bigint,
    cademi_produto_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    cademi_produto_ids text
);


--
-- Name: cademi_integration_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cademi_integration_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cademi_integration_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cademi_integration_product_id_seq OWNED BY public.cademi_integration_product.id;


--
-- Name: cademi_integration_product_offer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cademi_integration_product_offer (
    id bigint NOT NULL,
    cademi_integration_id bigint NOT NULL,
    product_offer_id bigint NOT NULL,
    cademi_tag_id bigint,
    cademi_produto_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    cademi_produto_ids text
);


--
-- Name: cademi_integration_product_offer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cademi_integration_product_offer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cademi_integration_product_offer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cademi_integration_product_offer_id_seq OWNED BY public.cademi_integration_product_offer.id;


--
-- Name: cademi_integration_subscription_plan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cademi_integration_subscription_plan (
    id bigint NOT NULL,
    cademi_integration_id bigint NOT NULL,
    subscription_plan_id bigint NOT NULL,
    cademi_tag_id bigint,
    cademi_produto_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    cademi_produto_ids text
);


--
-- Name: cademi_integration_subscription_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cademi_integration_subscription_plan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cademi_integration_subscription_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cademi_integration_subscription_plan_id_seq OWNED BY public.cademi_integration_subscription_plan.id;


--
-- Name: cademi_integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cademi_integrations (
    id bigint NOT NULL,
    tenant_id bigint,
    name character varying(255) NOT NULL,
    base_url character varying(255) NOT NULL,
    api_key text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    delivery_method character varying(32) DEFAULT 'postback_custom'::character varying NOT NULL,
    postback_token text
);


--
-- Name: cademi_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cademi_integrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cademi_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cademi_integrations_id_seq OWNED BY public.cademi_integrations.id;


--
-- Name: checkout_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checkout_sessions (
    id bigint NOT NULL,
    tenant_id bigint,
    product_offer_id bigint,
    subscription_plan_id bigint,
    checkout_slug character varying(64) NOT NULL,
    session_token character varying(64) NOT NULL,
    step character varying(32) DEFAULT 'visit'::character varying NOT NULL,
    email character varying(255),
    name character varying(255),
    customer_ip character varying(45),
    order_id bigint,
    utm_source character varying(255),
    utm_medium character varying(255),
    utm_campaign character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    abandoned_webhook_fired_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: checkout_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.checkout_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: checkout_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.checkout_sessions_id_seq OWNED BY public.checkout_sessions.id;


--
-- Name: coupon_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupon_product (
    coupon_id bigint NOT NULL,
    product_id character(36) NOT NULL
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupons (
    id bigint NOT NULL,
    tenant_id bigint,
    code character varying(64) NOT NULL,
    type character varying(16) DEFAULT 'percent'::character varying NOT NULL,
    value numeric(10,2) NOT NULL,
    min_amount numeric(10,2),
    max_uses integer,
    used_count integer DEFAULT 0 NOT NULL,
    valid_from timestamp(0) without time zone,
    valid_until timestamp(0) without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36)
);


--
-- Name: coupons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.coupons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: coupons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.coupons_id_seq OWNED BY public.coupons.id;


--
-- Name: email_campaign_sends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_campaign_sends (
    id bigint NOT NULL,
    email_campaign_id bigint NOT NULL,
    user_id bigint,
    email character varying(255) NOT NULL,
    sent_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: email_campaign_sends_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_campaign_sends_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_campaign_sends_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_campaign_sends_id_seq OWNED BY public.email_campaign_sends.id;


--
-- Name: email_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_campaigns (
    id bigint NOT NULL,
    tenant_id bigint,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    body_html text NOT NULL,
    filter_config json,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    total_recipients integer,
    sent_count integer DEFAULT 0 NOT NULL,
    scheduled_at timestamp(0) without time zone,
    sent_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: email_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_campaigns_id_seq OWNED BY public.email_campaigns.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: gateway_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gateway_credentials (
    id bigint NOT NULL,
    tenant_id bigint,
    gateway_slug character varying(64) NOT NULL,
    credentials text,
    is_connected boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: gateway_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gateway_credentials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gateway_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gateway_credentials_id_seq OWNED BY public.gateway_credentials.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: kyc_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kyc_documents (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kind character varying(32) NOT NULL,
    disk_path character varying(512) NOT NULL,
    original_mime character varying(128),
    size_bytes integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    public_token character varying(36) NOT NULL
);


--
-- Name: kyc_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kyc_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kyc_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kyc_documents_id_seq OWNED BY public.kyc_documents.id;


--
-- Name: member_achievement_unlocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_achievement_unlocks (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    achievement_id character varying(64) NOT NULL,
    unlocked_at timestamp(0) without time zone NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: member_achievement_unlocks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_achievement_unlocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_achievement_unlocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_achievement_unlocks_id_seq OWNED BY public.member_achievement_unlocks.id;


--
-- Name: member_area_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_area_domains (
    id bigint NOT NULL,
    type character varying(32) NOT NULL,
    value character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: member_area_domains_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_area_domains_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_area_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_area_domains_id_seq OWNED BY public.member_area_domains.id;


--
-- Name: member_certificates_issued; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_certificates_issued (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    issued_at timestamp(0) without time zone NOT NULL,
    completion_percent smallint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: member_certificates_issued_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_certificates_issued_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_certificates_issued_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_certificates_issued_id_seq OWNED BY public.member_certificates_issued.id;


--
-- Name: member_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_comments (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    member_lesson_id bigint,
    parent_id bigint,
    content text NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    reviewed_at timestamp(0) without time zone,
    reviewed_by bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: member_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_comments_id_seq OWNED BY public.member_comments.id;


--
-- Name: member_community_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_community_pages (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    is_public_posting boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    icon character varying(50),
    banner character varying(500),
    is_default boolean DEFAULT false NOT NULL,
    product_id character(36) NOT NULL
);


--
-- Name: member_community_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_community_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_community_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_community_pages_id_seq OWNED BY public.member_community_pages.id;


--
-- Name: member_community_post_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_community_post_comments (
    id bigint NOT NULL,
    member_community_post_id bigint NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: member_community_post_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_community_post_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_community_post_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_community_post_comments_id_seq OWNED BY public.member_community_post_comments.id;


--
-- Name: member_community_post_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_community_post_likes (
    id bigint NOT NULL,
    member_community_post_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: member_community_post_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_community_post_likes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_community_post_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_community_post_likes_id_seq OWNED BY public.member_community_post_likes.id;


--
-- Name: member_community_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_community_posts (
    id bigint NOT NULL,
    member_community_page_id bigint NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    image character varying(500)
);


--
-- Name: member_community_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_community_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_community_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_community_posts_id_seq OWNED BY public.member_community_posts.id;


--
-- Name: member_internal_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_internal_products (
    id bigint NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL,
    related_product_id character(36)
);


--
-- Name: member_internal_products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_internal_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_internal_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_internal_products_id_seq OWNED BY public.member_internal_products.id;


--
-- Name: member_lesson_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_lesson_progress (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    member_lesson_id bigint NOT NULL,
    completed_at timestamp(0) without time zone,
    progress_percent smallint DEFAULT '0'::smallint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: member_lesson_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_lesson_progress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_lesson_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_lesson_progress_id_seq OWNED BY public.member_lesson_progress.id;


--
-- Name: member_lessons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_lessons (
    id bigint NOT NULL,
    member_module_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    type character varying(32) DEFAULT 'video'::character varying NOT NULL,
    content_url text,
    content_text text,
    duration_seconds integer,
    is_free boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    watermark_enabled boolean DEFAULT false NOT NULL,
    link_title character varying(255),
    product_id character(36) NOT NULL,
    content_files json,
    release_after_days integer,
    release_at_date date
);


--
-- Name: member_lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_lessons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_lessons_id_seq OWNED BY public.member_lessons.id;


--
-- Name: member_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_modules (
    id bigint NOT NULL,
    member_section_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    thumbnail character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    show_title_on_cover boolean DEFAULT true NOT NULL,
    access_type character varying(20),
    external_url character varying(500),
    product_id character(36) NOT NULL,
    related_product_id character(36),
    release_after_days integer,
    release_at_date date
);


--
-- Name: member_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_modules_id_seq OWNED BY public.member_modules.id;


--
-- Name: member_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_notifications (
    id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    user_id bigint NOT NULL,
    type character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    body text,
    url character varying(500),
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: member_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_notifications_id_seq OWNED BY public.member_notifications.id;


--
-- Name: member_push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_push_subscriptions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    endpoint character varying(500) NOT NULL,
    keys json,
    user_agent character varying(500),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: member_push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_push_subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_push_subscriptions_id_seq OWNED BY public.member_push_subscriptions.id;


--
-- Name: member_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_sections (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    cover_mode character varying(20) DEFAULT 'vertical'::character varying NOT NULL,
    section_type character varying(30) DEFAULT 'courses'::character varying NOT NULL,
    product_id character(36) NOT NULL
);


--
-- Name: member_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_sections_id_seq OWNED BY public.member_sections.id;


--
-- Name: member_turma_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_turma_user (
    id bigint NOT NULL,
    member_turma_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: member_turma_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_turma_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_turma_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_turma_user_id_seq OWNED BY public.member_turma_user.id;


--
-- Name: member_turmas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_turmas (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    start_date date,
    end_date date,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: member_turmas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_turmas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_turmas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_turmas_id_seq OWNED BY public.member_turmas.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    product_offer_id bigint,
    subscription_plan_id bigint,
    amount numeric(10,2) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    tenant_id bigint,
    user_id bigint,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    email character varying(255),
    gateway character varying(64),
    gateway_id character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    cpf character varying(14),
    phone character varying(24),
    coupon_code character varying(64),
    customer_ip character varying(45),
    product_offer_id bigint,
    subscription_plan_id bigint,
    period_start date,
    period_end date,
    is_renewal boolean DEFAULT false NOT NULL,
    product_id character(36) NOT NULL,
    metadata json,
    approved_manually boolean DEFAULT false NOT NULL,
    payment_method character varying(32),
    public_reference character varying(16)
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: panel_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.panel_notifications (
    id bigint NOT NULL,
    tenant_id bigint,
    user_id bigint NOT NULL,
    type character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    body text,
    url character varying(500),
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    event_key character varying(128)
);


--
-- Name: panel_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.panel_notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: panel_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.panel_notifications_id_seq OWNED BY public.panel_notifications.id;


--
-- Name: panel_push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.panel_push_subscriptions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    tenant_id bigint,
    endpoint character varying(500) NOT NULL,
    keys json,
    user_agent character varying(500),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: panel_push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.panel_push_subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: panel_push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.panel_push_subscriptions_id_seq OWNED BY public.panel_push_subscriptions.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- Name: platform_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_audit_logs (
    id bigint NOT NULL,
    user_id bigint,
    action character varying(128) NOT NULL,
    metadata json,
    ip character varying(45),
    user_agent text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: platform_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_audit_logs_id_seq OWNED BY public.platform_audit_logs.id;


--
-- Name: platform_languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_languages (
    id bigint NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: platform_languages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_languages_id_seq OWNED BY public.platform_languages.id;


--
-- Name: platform_translations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_translations (
    id bigint NOT NULL,
    "group" character varying(60) NOT NULL,
    key character varying(190) NOT NULL,
    locale character varying(20) NOT NULL,
    value text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: platform_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.platform_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.platform_translations_id_seq OWNED BY public.platform_translations.id;


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugins (
    slug character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(50) DEFAULT '1.0.0'::character varying NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    config json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: product_affiliate_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_affiliate_enrollments (
    id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    affiliate_user_id bigint NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    public_ref character varying(32),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    conversion_pixels json
);


--
-- Name: product_affiliate_enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_affiliate_enrollments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_affiliate_enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_affiliate_enrollments_id_seq OWNED BY public.product_affiliate_enrollments.id;


--
-- Name: product_coproducers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_coproducers (
    id bigint NOT NULL,
    product_id character varying(255) NOT NULL,
    inviter_user_id bigint NOT NULL,
    co_producer_user_id bigint,
    email character varying(255) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    token character varying(64) NOT NULL,
    commission_percent numeric(5,2) NOT NULL,
    commission_on_direct_sales boolean DEFAULT true NOT NULL,
    commission_on_affiliate_sales boolean DEFAULT false NOT NULL,
    duration_preset character varying(16) DEFAULT 'eternal'::character varying NOT NULL,
    starts_at timestamp(0) without time zone,
    ends_at timestamp(0) without time zone,
    accepted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: product_coproducers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_coproducers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_coproducers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_coproducers_id_seq OWNED BY public.product_coproducers.id;


--
-- Name: product_offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_offers (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(10,2) NOT NULL,
    currency character varying(8),
    checkout_slug character varying(16) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL,
    checkout_config json
);


--
-- Name: product_offers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_offers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_offers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_offers_id_seq OWNED BY public.product_offers.id;


--
-- Name: product_order_bumps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_order_bumps (
    id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    target_product_id character varying(36) NOT NULL,
    target_product_offer_id bigint,
    title character varying(255) NOT NULL,
    description text,
    price_override numeric(10,2),
    cta_title character varying(255) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: product_order_bumps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_order_bumps_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_order_bumps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_order_bumps_id_seq OWNED BY public.product_order_bumps.id;


--
-- Name: product_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_user (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: product_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_user_id_seq OWNED BY public.product_user.id;


--
-- Name: product_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_webhook (
    id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    webhook_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: product_webhook_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_webhook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_webhook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_webhook_id_seq OWNED BY public.product_webhook.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    tenant_id bigint,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    type character varying(32) DEFAULT 'course'::character varying NOT NULL,
    price numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    image character varying(500),
    currency character varying(8) DEFAULT 'BRL'::character varying NOT NULL,
    billing_type character varying(32) DEFAULT 'one_time'::character varying NOT NULL,
    checkout_slug character varying(16),
    checkout_config json,
    member_area_config json,
    id character(36) NOT NULL,
    conversion_pixels json,
    affiliate_enabled boolean DEFAULT false NOT NULL,
    affiliate_commission_percent numeric(8,2) DEFAULT '0'::numeric NOT NULL,
    affiliate_manual_approval boolean DEFAULT true NOT NULL,
    affiliate_show_in_showcase boolean DEFAULT false NOT NULL,
    affiliate_page_url character varying(2048),
    affiliate_support_email character varying(255),
    affiliate_showcase_description text,
    refund_policy_days smallint
);


--
-- Name: refund_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refund_requests (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    user_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    customer_reason text NOT NULL,
    seller_rejection_reason text,
    gateway_refund_status character varying(32),
    gateway_refund_note text,
    resolved_by_user_id bigint,
    resolved_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: refund_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.refund_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refund_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.refund_requests_id_seq OWNED BY public.refund_requests.id;


--
-- Name: sales_achievements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_achievements (
    id bigint NOT NULL,
    slug character varying(120) NOT NULL,
    name character varying(180) NOT NULL,
    threshold numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    image character varying(2048),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: sales_achievements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_achievements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_achievements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_achievements_id_seq OWNED BY public.sales_achievements.id;


--
-- Name: saved_payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_payment_methods (
    id bigint NOT NULL,
    tenant_id bigint,
    user_id bigint NOT NULL,
    gateway character varying(64) NOT NULL,
    gateway_payment_method_id character varying(255),
    last_four character varying(4),
    brand character varying(32),
    type character varying(16) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: saved_payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.saved_payment_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: saved_payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.saved_payment_methods_id_seq OWNED BY public.saved_payment_methods.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    tenant_id bigint,
    key character varying(255) NOT NULL,
    value text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: spedy_integration_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spedy_integration_product (
    id bigint NOT NULL,
    spedy_integration_id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: spedy_integration_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spedy_integration_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spedy_integration_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spedy_integration_product_id_seq OWNED BY public.spedy_integration_product.id;


--
-- Name: spedy_integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spedy_integrations (
    id bigint NOT NULL,
    tenant_id bigint,
    name character varying(255) NOT NULL,
    api_key text,
    environment character varying(20) DEFAULT 'production'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: spedy_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spedy_integrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spedy_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spedy_integrations_id_seq OWNED BY public.spedy_integrations.id;


--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(10,2) NOT NULL,
    currency character varying(8),
    "interval" character varying(32) NOT NULL,
    checkout_slug character varying(16) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    gateway_plan_id character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL,
    checkout_config json
);


--
-- Name: subscription_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_plans_id_seq OWNED BY public.subscription_plans.id;


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id bigint NOT NULL,
    tenant_id bigint,
    user_id bigint NOT NULL,
    subscription_plan_id bigint NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    current_period_start date,
    current_period_end date,
    saved_payment_method_id bigint,
    gateway_subscription_id character varying(255),
    renewal_token character varying(64),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    product_id character(36) NOT NULL
);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscriptions_id_seq OWNED BY public.subscriptions.id;


--
-- Name: team_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_audit_logs (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    actor_user_id bigint,
    action character varying(80) NOT NULL,
    target_type character varying(80),
    target_id character varying(64),
    metadata json,
    ip character varying(45),
    user_agent text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: team_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_audit_logs_id_seq OWNED BY public.team_audit_logs.id;


--
-- Name: team_role_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_role_product (
    id bigint NOT NULL,
    team_role_id bigint NOT NULL,
    product_id character(36) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: team_role_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_role_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_role_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_role_product_id_seq OWNED BY public.team_role_product.id;


--
-- Name: team_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_roles (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    name character varying(100) NOT NULL,
    permissions json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: team_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_roles_id_seq OWNED BY public.team_roles.id;


--
-- Name: tenant_wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_wallets (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    available_balance numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    pending_balance numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    currency character varying(8) DEFAULT 'BRL'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    available_pix numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    available_card numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    available_boleto numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    pending_pix numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    pending_card numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    pending_boleto numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    admin_withdrawal_blocked boolean DEFAULT false NOT NULL,
    admin_blocked_amount numeric(14,2),
    admin_block_until timestamp(0) without time zone,
    admin_block_note character varying(500)
);


--
-- Name: tenant_wallets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tenant_wallets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tenant_wallets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tenant_wallets_id_seq OWNED BY public.tenant_wallets.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    role character varying(32) DEFAULT 'aluno'::character varying NOT NULL,
    tenant_id bigint,
    avatar character varying(255),
    username character varying(255),
    team_role_id bigint,
    person_type character varying(16),
    document character varying(32),
    account_status character varying(32) DEFAULT 'approved'::character varying NOT NULL,
    merchant_fees json,
    merchant_settlement_overrides json,
    merchant_gateway_order json,
    payout_settings json,
    birth_date date,
    company_name character varying(255),
    legal_representative_cpf character varying(14),
    address_zip character varying(16),
    address_street character varying(255),
    address_number character varying(32),
    address_complement character varying(120),
    address_neighborhood character varying(120),
    address_city character varying(120),
    address_state character varying(2),
    monthly_revenue_range character varying(32),
    kyc_status character varying(32) DEFAULT 'not_submitted'::character varying NOT NULL,
    kyc_rejection_reason text,
    kyc_reviewed_at timestamp(0) without time zone,
    kyc_reviewed_by bigint,
    seller_onboarded_at timestamp(0) without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: utmify_integration_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.utmify_integration_product (
    id bigint NOT NULL,
    utmify_integration_id bigint NOT NULL,
    product_id character varying(36) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: utmify_integration_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.utmify_integration_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utmify_integration_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.utmify_integration_product_id_seq OWNED BY public.utmify_integration_product.id;


--
-- Name: utmify_integrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.utmify_integrations (
    id bigint NOT NULL,
    tenant_id bigint,
    api_key text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) DEFAULT 'UTMfy'::character varying NOT NULL
);


--
-- Name: utmify_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.utmify_integrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: utmify_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.utmify_integrations_id_seq OWNED BY public.utmify_integrations.id;


--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_transactions (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    order_id bigint,
    withdrawal_id bigint,
    bucket character varying(16) NOT NULL,
    type character varying(32) NOT NULL,
    amount_gross numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    amount_fee numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    amount_net numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    meta json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wallet_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wallet_transactions_id_seq OWNED BY public.wallet_transactions.id;


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_logs (
    id bigint NOT NULL,
    webhook_id bigint NOT NULL,
    event character varying(255) NOT NULL,
    event_label character varying(255),
    request_payload json,
    response_status smallint,
    response_body text,
    success boolean NOT NULL,
    error_message character varying(1024),
    source character varying(32) DEFAULT 'job'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhook_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhook_logs_id_seq OWNED BY public.webhook_logs.id;


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id bigint NOT NULL,
    tenant_id bigint,
    name character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    bearer_token text,
    events json,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_id_seq OWNED BY public.webhooks.id;


--
-- Name: withdrawals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.withdrawals (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    user_id bigint,
    amount numeric(14,2) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    notes text,
    currency character varying(8) DEFAULT 'BRL'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    payout_provider character varying(32),
    payout_external_id character varying(80),
    payout_meta json,
    payout_manual boolean DEFAULT false NOT NULL,
    fee_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    net_amount numeric(14,2) DEFAULT '0'::numeric NOT NULL,
    bucket character varying(16) DEFAULT 'pix'::character varying NOT NULL
);


--
-- Name: withdrawals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.withdrawals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: withdrawals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.withdrawals_id_seq OWNED BY public.withdrawals.id;


--
-- Name: api_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_applications ALTER COLUMN id SET DEFAULT nextval('public.api_applications_id_seq'::regclass);


--
-- Name: api_checkout_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_checkout_sessions ALTER COLUMN id SET DEFAULT nextval('public.api_checkout_sessions_id_seq'::regclass);


--
-- Name: branding_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_settings ALTER COLUMN id SET DEFAULT nextval('public.branding_settings_id_seq'::regclass);


--
-- Name: cademi_integration_product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product ALTER COLUMN id SET DEFAULT nextval('public.cademi_integration_product_id_seq'::regclass);


--
-- Name: cademi_integration_product_offer id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product_offer ALTER COLUMN id SET DEFAULT nextval('public.cademi_integration_product_offer_id_seq'::regclass);


--
-- Name: cademi_integration_subscription_plan id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_subscription_plan ALTER COLUMN id SET DEFAULT nextval('public.cademi_integration_subscription_plan_id_seq'::regclass);


--
-- Name: cademi_integrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integrations ALTER COLUMN id SET DEFAULT nextval('public.cademi_integrations_id_seq'::regclass);


--
-- Name: checkout_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_sessions ALTER COLUMN id SET DEFAULT nextval('public.checkout_sessions_id_seq'::regclass);


--
-- Name: coupons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons ALTER COLUMN id SET DEFAULT nextval('public.coupons_id_seq'::regclass);


--
-- Name: email_campaign_sends id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaign_sends ALTER COLUMN id SET DEFAULT nextval('public.email_campaign_sends_id_seq'::regclass);


--
-- Name: email_campaigns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns ALTER COLUMN id SET DEFAULT nextval('public.email_campaigns_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: gateway_credentials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_credentials ALTER COLUMN id SET DEFAULT nextval('public.gateway_credentials_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: kyc_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_documents ALTER COLUMN id SET DEFAULT nextval('public.kyc_documents_id_seq'::regclass);


--
-- Name: member_achievement_unlocks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_achievement_unlocks ALTER COLUMN id SET DEFAULT nextval('public.member_achievement_unlocks_id_seq'::regclass);


--
-- Name: member_area_domains id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_area_domains ALTER COLUMN id SET DEFAULT nextval('public.member_area_domains_id_seq'::regclass);


--
-- Name: member_certificates_issued id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_certificates_issued ALTER COLUMN id SET DEFAULT nextval('public.member_certificates_issued_id_seq'::regclass);


--
-- Name: member_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_comments ALTER COLUMN id SET DEFAULT nextval('public.member_comments_id_seq'::regclass);


--
-- Name: member_community_pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_pages ALTER COLUMN id SET DEFAULT nextval('public.member_community_pages_id_seq'::regclass);


--
-- Name: member_community_post_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_comments ALTER COLUMN id SET DEFAULT nextval('public.member_community_post_comments_id_seq'::regclass);


--
-- Name: member_community_post_likes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_likes ALTER COLUMN id SET DEFAULT nextval('public.member_community_post_likes_id_seq'::regclass);


--
-- Name: member_community_posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_posts ALTER COLUMN id SET DEFAULT nextval('public.member_community_posts_id_seq'::regclass);


--
-- Name: member_internal_products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_internal_products ALTER COLUMN id SET DEFAULT nextval('public.member_internal_products_id_seq'::regclass);


--
-- Name: member_lesson_progress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lesson_progress ALTER COLUMN id SET DEFAULT nextval('public.member_lesson_progress_id_seq'::regclass);


--
-- Name: member_lessons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lessons ALTER COLUMN id SET DEFAULT nextval('public.member_lessons_id_seq'::regclass);


--
-- Name: member_modules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_modules ALTER COLUMN id SET DEFAULT nextval('public.member_modules_id_seq'::regclass);


--
-- Name: member_notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_notifications ALTER COLUMN id SET DEFAULT nextval('public.member_notifications_id_seq'::regclass);


--
-- Name: member_push_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.member_push_subscriptions_id_seq'::regclass);


--
-- Name: member_sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_sections ALTER COLUMN id SET DEFAULT nextval('public.member_sections_id_seq'::regclass);


--
-- Name: member_turma_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turma_user ALTER COLUMN id SET DEFAULT nextval('public.member_turma_user_id_seq'::regclass);


--
-- Name: member_turmas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turmas ALTER COLUMN id SET DEFAULT nextval('public.member_turmas_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: panel_notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.panel_notifications ALTER COLUMN id SET DEFAULT nextval('public.panel_notifications_id_seq'::regclass);


--
-- Name: panel_push_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.panel_push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.panel_push_subscriptions_id_seq'::regclass);


--
-- Name: platform_audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.platform_audit_logs_id_seq'::regclass);


--
-- Name: platform_languages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_languages ALTER COLUMN id SET DEFAULT nextval('public.platform_languages_id_seq'::regclass);


--
-- Name: platform_translations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_translations ALTER COLUMN id SET DEFAULT nextval('public.platform_translations_id_seq'::regclass);


--
-- Name: product_affiliate_enrollments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_affiliate_enrollments ALTER COLUMN id SET DEFAULT nextval('public.product_affiliate_enrollments_id_seq'::regclass);


--
-- Name: product_coproducers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_coproducers ALTER COLUMN id SET DEFAULT nextval('public.product_coproducers_id_seq'::regclass);


--
-- Name: product_offers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_offers ALTER COLUMN id SET DEFAULT nextval('public.product_offers_id_seq'::regclass);


--
-- Name: product_order_bumps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_order_bumps ALTER COLUMN id SET DEFAULT nextval('public.product_order_bumps_id_seq'::regclass);


--
-- Name: product_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_user ALTER COLUMN id SET DEFAULT nextval('public.product_user_id_seq'::regclass);


--
-- Name: product_webhook id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_webhook ALTER COLUMN id SET DEFAULT nextval('public.product_webhook_id_seq'::regclass);


--
-- Name: refund_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_requests ALTER COLUMN id SET DEFAULT nextval('public.refund_requests_id_seq'::regclass);


--
-- Name: sales_achievements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_achievements ALTER COLUMN id SET DEFAULT nextval('public.sales_achievements_id_seq'::regclass);


--
-- Name: saved_payment_methods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_payment_methods ALTER COLUMN id SET DEFAULT nextval('public.saved_payment_methods_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: spedy_integration_product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spedy_integration_product ALTER COLUMN id SET DEFAULT nextval('public.spedy_integration_product_id_seq'::regclass);


--
-- Name: spedy_integrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spedy_integrations ALTER COLUMN id SET DEFAULT nextval('public.spedy_integrations_id_seq'::regclass);


--
-- Name: subscription_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans ALTER COLUMN id SET DEFAULT nextval('public.subscription_plans_id_seq'::regclass);


--
-- Name: subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions ALTER COLUMN id SET DEFAULT nextval('public.subscriptions_id_seq'::regclass);


--
-- Name: team_audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.team_audit_logs_id_seq'::regclass);


--
-- Name: team_role_product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_role_product ALTER COLUMN id SET DEFAULT nextval('public.team_role_product_id_seq'::regclass);


--
-- Name: team_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_roles ALTER COLUMN id SET DEFAULT nextval('public.team_roles_id_seq'::regclass);


--
-- Name: tenant_wallets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_wallets ALTER COLUMN id SET DEFAULT nextval('public.tenant_wallets_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: utmify_integration_product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utmify_integration_product ALTER COLUMN id SET DEFAULT nextval('public.utmify_integration_product_id_seq'::regclass);


--
-- Name: utmify_integrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utmify_integrations ALTER COLUMN id SET DEFAULT nextval('public.utmify_integrations_id_seq'::regclass);


--
-- Name: wallet_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions ALTER COLUMN id SET DEFAULT nextval('public.wallet_transactions_id_seq'::regclass);


--
-- Name: webhook_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs ALTER COLUMN id SET DEFAULT nextval('public.webhook_logs_id_seq'::regclass);


--
-- Name: webhooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks ALTER COLUMN id SET DEFAULT nextval('public.webhooks_id_seq'::regclass);


--
-- Name: withdrawals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals ALTER COLUMN id SET DEFAULT nextval('public.withdrawals_id_seq'::regclass);


--
-- Data for Name: api_applications; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.api_applications VALUES (1, 4, 'Loja JaderBrandao', 'loja-jaderbrandao', '$2y$10$Q7uH3a./B2fUWROZEpZNf.M1X3RxLkMm2kOa9TTOVhizQFhmCntLu', '{"pix":"mercadopago","pix_redundancy":[],"card":"mercadopago","card_redundancy":[],"boleto":"mercadopago","boleto_redundancy":[],"pix_auto":null,"pix_auto_redundancy":[],"crypto":null,"crypto_redundancy":[]}', '[]', NULL, true, '2026-06-06 01:30:33', '2026-06-06 01:30:33', '12345678', NULL, NULL, 'https://web.winfy.com.br');


--
-- Data for Name: api_checkout_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.api_checkout_sessions VALUES (1, 1, 4, '2aeefa34-45f4-491e-a94b-1b476ad6c02b', '{"email":"jader_bs@hotmail.com","name":"Jader Silva","cpf":"00316765476","phone":"21969648240"}', 97.90, 'BRL', NULL, NULL, NULL, '[]', 'https://web.winfy.com.br', '2026-06-06 02:28:07', NULL, '2026-06-06 01:58:07', '2026-06-06 01:58:07');


--
-- Data for Name: branding_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.branding_settings VALUES (1, NULL, '{"app_logo":"https:\/\/web.winfy.com.br\/storage\/white-label\/\/WfiOEIbkF5Qe6uy0OKVOOkHBN0irVZ3jaQZGnPRt.png","app_logo_dark":"https:\/\/web.winfy.com.br\/storage\/white-label\/\/CwwHRI8UREQveFYbzOc7It3FyCR7s3wIkcQ8o1jm.png","login_hero_image":"https:\/\/web.winfy.com.br\/storage\/white-label\/\/js7fTPOJv5teqR52Q71WCqWM83pv7sT6AnGzDmus.png","favicon_url":"https:\/\/web.winfy.com.br\/storage\/white-label\/\/tuYFRQ4fV1DCG6FuSQVkBCPYPTtqSfuBYGl4Pysg.png","app_name":"Winfy Tecnologia","app_logo_icon":"https:\/\/web.winfy.com.br\/storage\/white-label\/\/XkUTAkOj3dlUzPGqmryZKE385u3zazSE5hUhC3iS.png","app_logo_icon_dark":"https:\/\/web.winfy.com.br\/storage\/white-label\/\/tlMTLHOPV1l8taYHkePkyK5lISNn9fZHjpKcUydr.png","theme_primary":"#32e768"}', '2026-04-30 14:56:43', '2026-04-30 17:35:48');


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cache VALUES ('winfy-cache-9460362699693ca1433206861d2e9b6da1cd8c16:timer', 'i:1777582456;', 1777582456);
INSERT INTO public.cache VALUES ('winfy-cache-9460362699693ca1433206861d2e9b6da1cd8c16', 'i:1;', 1777582456);
INSERT INTO public.cache VALUES ('winfy-cache-webhook_processing.mercadopago.157148841606', 'b:1;', 1777583403);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.merchant_fee_rules', 's:337:"{"pix":{"percent":1.4899999999999999911182158029987476766109466552734375,"fixed":0},"card":{"percent":5.980000000000000426325641456060111522674560546875,"fixed":0},"boleto":{"percent":0,"fixed":4.4900000000000002131628207280300557613372802734375},"withdrawal":{"percent":0,"fixed":1.9899999999999999911182158029987476766109466552734375}}";', 1780720403);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.gateway_order', 'N;', 1780723966);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.storage_provider', 's:5:"local";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.storage_s3_key', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.storage_s3_bucket', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.storage_s3_region', 's:9:"us-east-1";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.storage_s3_endpoint', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-c0e524cb4ef55ff8a285624856f2f573c88b70d3', 'i:2;', 1777584157);
INSERT INTO public.cache VALUES ('winfy-cache-c1dfd96eea8cc2b62785275bca38ac261256e278:timer', 'i:1777586700;', 1777586700);
INSERT INTO public.cache VALUES ('winfy-cache-c1dfd96eea8cc2b62785275bca38ac261256e278', 'i:1;', 1777586700);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.storage_s3_url', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.storage_s3_secret', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-access_email_sent.1', 'b:1;', 1777586704);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.mail_from_address', 's:17:"noreply@getfy.com";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-tenant_owner_backfill_done:4', 'b:1;', 1809111623);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.hostinger_smtp_username', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.hostinger_mail_from_address', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-webhook_processing.mercadopago.156388971233', 'b:1;', 1777584425);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.hostinger_mail_from_name', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.hostinger_reply_to', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-c0e524cb4ef55ff8a285624856f2f573c88b70d3:timer', 'i:1777584156;', 1777584157);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.sendgrid_mail_from_address', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.email_provider', 's:4:"smtp";', 1777584185);
INSERT INTO public.cache VALUES ('winfy-cache-1fbd9d322454b3a66ef2c73deaadd3c71206c12a:timer', 'i:1780718382;', 1780718382);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.smtp_host', 's:9:"127.0.0.1";', 1777584185);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.smtp_port', 'i:2525;', 1777584185);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.sendgrid_mail_from_name', 's:0:"";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.smtp_encryption', 'N;', 1777584185);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.kyc_notification_emails', 's:20:"contato@winfy.com.br";', 1777585859);
INSERT INTO public.cache VALUES ('winfy-cache-affc65c4c0f51c30753d799a77f9d3d0c672be53:timer', 'i:1777573392;', 1777573392);
INSERT INTO public.cache VALUES ('winfy-cache-affc65c4c0f51c30753d799a77f9d3d0c672be53', 'i:1;', 1777573392);
INSERT INTO public.cache VALUES ('winfy-cache-1fbd9d322454b3a66ef2c73deaadd3c71206c12a', 'i:2;', 1780718382);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.smtp_username', 'N;', 1777584185);
INSERT INTO public.cache VALUES ('winfy-cache-dashboard:v2:4:mes', 'a:12:{s:6:"period";s:3:"mes";s:13:"vendas_totais";d:0;s:16:"vendas_pendentes";d:0;s:17:"quantidade_vendas";i:0;s:12:"ticket_medio";d:0;s:16:"formas_pagamento";a:0:{}s:14:"taxa_conversao";i:0;s:17:"abandono_carrinho";i:0;s:16:"reembolsos_count";i:0;s:16:"reembolsos_total";d:0;s:19:"quantidade_produtos";i:1;s:14:"grafico_vendas";a:0:{}}', 1780718642);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.smtp_password', 'N;', 1777584186);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.mail_from_name', 's:10:"gatewayLab";', 1777584186);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.reply_to', 'N;', 1777584186);
INSERT INTO public.cache VALUES ('winfy-cache-access_password.7.45d8e4f6-1be9-4499-a71e-a57e2309cd62', 's:12:"f4jMFyYLs2zF";', 1780728981);
INSERT INTO public.cache VALUES ('winfy-cache-1b6453892473a467d07372d45eb05abc2031647a:timer', 'i:1780722028;', 1780722028);
INSERT INTO public.cache VALUES ('winfy-cache-1b6453892473a467d07372d45eb05abc2031647a', 'i:1;', 1780722028);
INSERT INTO public.cache VALUES ('winfy-cache-access_email_sent.2', 'b:1;', 1777587726);
INSERT INTO public.cache VALUES ('winfy-cache-geo_ip:7a9ad6fac45ff1fac063380478df74e9', 'N;', 1777670122);
INSERT INTO public.cache VALUES ('winfy-cache-geo_ip:7780430a94801891c22de8515ae46e93', 'N;', 1777672559);
INSERT INTO public.cache VALUES ('winfy-cache-setting.4.storage_provider', 'N;', 1780723966);
INSERT INTO public.cache VALUES ('winfy-cache-geo_ip:8049816f25800e022947f3c93cd80e53', 'N;', 1780810306);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.checkout_translations', 's:9535:"{"pt_BR":{"checkout.seus_dados":"Seus dados","checkout.name":"Nome","checkout.email":"E-mail","checkout.phone":"Telefone","checkout.cpf":"CPF","checkout.coupon_label":"Cupom de desconto","checkout.coupon_placeholder":"C\u00f3digo do cupom","checkout.submit_button":"Concluir compra","checkout.processing":"Processando\u2026","checkout.name_placeholder":"Como quer ser chamado","checkout.email_placeholder":"seu@email.com","checkout.phone_placeholder_br":"(11) 99999-9999","checkout.phone_placeholder_other":"N\u00famero","checkout.cpf_placeholder":"000.000.000-00","checkout.country_code_label":"C\u00f3digo do pa\u00eds","checkout.summary_title":"Resumo da compra","checkout.discount_coupon":"Desconto (cupom)","checkout.total":"Total","checkout.secure_purchase":"Compra 100% segura","checkout.voce_pode_gostar":"Voc\u00ea pode gostar","checkout.voce_pode_gostar_subtitle":"Adicione estes itens \u00e0 sua compra","checkout.deselect_all":"Desmarcar todos","checkout.oferta_especial":"Oferta especial","checkout.total_a_pagar":"Total a pagar","checkout.ver_mais":"Ver mais","checkout.ver_menos":"Ver menos","checkout.timer_text":"Esta oferta expira em:","checkout.validating_coupon":"Validando cupom\u2026","checkout.forma_pagamento":"Forma de pagamento","checkout.gerar_pix":"Gerar PIX","checkout.gerar_pix_auto":"Gerar PIX Autom\u00e1tico","checkout.pix_auto":"PIX autom\u00e1tico","checkout.gerar_boleto":"Gerar boleto","checkout.corrija_erros":"Corrija os erros abaixo antes de continuar.","checkout.preencher_dados_gerar_pix":"Preencha seus dados acima e clique em \"Gerar PIX\".","checkout.preencher_dados_gerar_boleto":"Preencha seus dados acima e clique em \"Gerar boleto\".","checkout.preencher_e_gerar_pix":"Preencha nome, e-mail e CPF (se solicitado) e clique em \"Gerar PIX\" abaixo.","checkout.preencher_e_gerar_boleto":"Preencha nome, e-mail e CPF (se solicitado) e clique em \"Gerar boleto\" abaixo.","checkout.editar_dados":"Editar dados","checkout.dados_cartao":"Dados do cart\u00e3o","checkout.card_holder":"Nome no cart\u00e3o","checkout.card_holder_placeholder":"Como est\u00e1 impresso no cart\u00e3o","checkout.card_number":"N\u00famero do cart\u00e3o","checkout.card_number_placeholder":"0000 0000 0000 0000","checkout.card_exp":"Validade (MM\/AA)","checkout.card_exp_placeholder":"MM\/AAAA","checkout.card_cvv":"CVV","checkout.card_cvv_placeholder":"123","checkout.card_cvv_help":"3 ou 4 d\u00edgitos no verso do cart\u00e3o","checkout.pagar_cartao":"Pagar com cart\u00e3o","checkout.card_not_configured":"Pagamento por cart\u00e3o n\u00e3o est\u00e1 configurado.","checkout.card_fill_all":"Preencha todos os dados do cart\u00e3o corretamente.","checkout.installments":"N\u00famero de parcelas","checkout.endereco_boleto":"Endere\u00e7o para o boleto","checkout.endereco_boleto_cep":"CEP","checkout.endereco_boleto_buscar":"Buscar","checkout.endereco_boleto_numero":"N\u00famero","exit_popup.title":"Espere! Temos um desconto para voc\u00ea","exit_popup.description":"Use o cupom abaixo na pr\u00f3xima etapa","exit_popup.button_accept":"Quero o desconto","exit_popup.button_decline":"N\u00e3o, obrigado","exit_popup.close":"Fechar","exit_popup.coupon_label":"Seu cupom"},"en":{"checkout.seus_dados":"Your details","checkout.name":"Name","checkout.email":"Email","checkout.phone":"Phone","checkout.cpf":"Tax ID","checkout.coupon_label":"Discount coupon","checkout.coupon_placeholder":"Coupon code","checkout.submit_button":"Complete purchase","checkout.processing":"Processing\u2026","checkout.name_placeholder":"How you want to be called","checkout.email_placeholder":"your@email.com","checkout.phone_placeholder_br":"(11) 99999-9999","checkout.phone_placeholder_other":"Number","checkout.cpf_placeholder":"000.000.000-00","checkout.country_code_label":"Country code","checkout.summary_title":"Order summary","checkout.discount_coupon":"Discount (coupon)","checkout.total":"Total","checkout.secure_purchase":"100% secure purchase","checkout.voce_pode_gostar":"You may also like","checkout.voce_pode_gostar_subtitle":"Add these items to your order","checkout.deselect_all":"Deselect all","checkout.oferta_especial":"Special offer","checkout.total_a_pagar":"Total to pay","checkout.ver_mais":"See more","checkout.ver_menos":"See less","checkout.timer_text":"This offer expires in:","checkout.validating_coupon":"Validating coupon\u2026","checkout.forma_pagamento":"Payment method","checkout.gerar_pix":"Generate PIX","checkout.gerar_pix_auto":"Generate PIX (auto renewal)","checkout.pix_auto":"Automatic PIX","checkout.gerar_boleto":"Generate bank slip","checkout.corrija_erros":"Please fix the errors below before continuing.","checkout.preencher_dados_gerar_pix":"Fill in your details above and click \"Generate PIX\".","checkout.preencher_dados_gerar_boleto":"Fill in your details above and click \"Generate bank slip\".","checkout.preencher_e_gerar_pix":"Fill in name, email and CPF (if required) and click \"Generate PIX\" below.","checkout.preencher_e_gerar_boleto":"Fill in name, email and CPF (if required) and click \"Generate bank slip\" below.","checkout.editar_dados":"Edit details","checkout.dados_cartao":"Card details","checkout.card_holder":"Name on card","checkout.card_holder_placeholder":"As shown on card","checkout.card_number":"Card number","checkout.card_number_placeholder":"0000 0000 0000 0000","checkout.card_exp":"Expiry (MM\/YY)","checkout.card_exp_placeholder":"MM\/YYYY","checkout.card_cvv":"CVV","checkout.card_cvv_placeholder":"123","checkout.card_cvv_help":"3 or 4 digits on the back of the card","checkout.pagar_cartao":"Pay with card","checkout.card_not_configured":"Card payment is not configured.","checkout.card_fill_all":"Please fill in all card details correctly.","checkout.installments":"Number of installments","checkout.endereco_boleto":"Address for bank slip","checkout.endereco_boleto_cep":"ZIP code","checkout.endereco_boleto_buscar":"Search","checkout.endereco_boleto_numero":"Number","exit_popup.title":"Wait! We have a discount for you","exit_popup.description":"Use the coupon below in the next step","exit_popup.button_accept":"I want the discount","exit_popup.button_decline":"No, thanks","exit_popup.close":"Close","exit_popup.coupon_label":"Your coupon"},"es":{"checkout.seus_dados":"Tus datos","checkout.name":"Nombre","checkout.email":"Correo electr\u00f3nico","checkout.phone":"Tel\u00e9fono","checkout.cpf":"Documento","checkout.coupon_label":"Cup\u00f3n de descuento","checkout.coupon_placeholder":"C\u00f3digo del cup\u00f3n","checkout.submit_button":"Completar compra","checkout.processing":"Procesando\u2026","checkout.name_placeholder":"C\u00f3mo quieres que te llamen","checkout.email_placeholder":"tu@email.com","checkout.phone_placeholder_br":"(11) 99999-9999","checkout.phone_placeholder_other":"N\u00famero","checkout.cpf_placeholder":"000.000.000-00","checkout.country_code_label":"C\u00f3digo de pa\u00eds","checkout.summary_title":"Resumen del pedido","checkout.discount_coupon":"Descuento (cup\u00f3n)","checkout.total":"Total","checkout.secure_purchase":"Compra 100% segura","checkout.voce_pode_gostar":"Tambi\u00e9n te puede gustar","checkout.voce_pode_gostar_subtitle":"A\u00f1ade estos productos a tu compra","checkout.deselect_all":"Desmarcar todos","checkout.oferta_especial":"Oferta especial","checkout.total_a_pagar":"Total a pagar","checkout.ver_mais":"Ver m\u00e1s","checkout.ver_menos":"Ver menos","checkout.timer_text":"Esta oferta expira en:","checkout.validating_coupon":"Validando cup\u00f3n\u2026","checkout.forma_pagamento":"Forma de pago","checkout.gerar_pix":"Generar PIX","checkout.gerar_pix_auto":"Generar PIX (renovaci\u00f3n autom\u00e1tica)","checkout.pix_auto":"PIX autom\u00e1tico","checkout.gerar_boleto":"Generar boleto","checkout.corrija_erros":"Corrija los errores antes de continuar.","checkout.preencher_dados_gerar_pix":"Complete sus datos arriba y haga clic en \"Generar PIX\".","checkout.preencher_dados_gerar_boleto":"Complete sus datos arriba y haga clic en \"Generar boleto\".","checkout.preencher_e_gerar_pix":"Complete nombre, correo y CPF (si se solicita) y haga clic en \"Generar PIX\" abajo.","checkout.preencher_e_gerar_boleto":"Complete nombre, correo y CPF (si se solicita) y haga clic en \"Generar boleto\" abajo.","checkout.editar_dados":"Editar datos","checkout.dados_cartao":"Datos de la tarjeta","checkout.card_holder":"Nombre en la tarjeta","checkout.card_holder_placeholder":"Como aparece en la tarjeta","checkout.card_number":"N\u00famero de la tarjeta","checkout.card_number_placeholder":"0000 0000 0000 0000","checkout.card_exp":"Vencimiento (MM\/AA)","checkout.card_exp_placeholder":"MM\/AAAA","checkout.card_cvv":"CVV","checkout.card_cvv_placeholder":"123","checkout.card_cvv_help":"3 o 4 d\u00edgitos en el dorso de la tarjeta","checkout.pagar_cartao":"Pagar con tarjeta","checkout.card_not_configured":"El pago con tarjeta no est\u00e1 configurado.","checkout.card_fill_all":"Complete todos los datos de la tarjeta correctamente.","checkout.installments":"N\u00famero de cuotas","checkout.endereco_boleto":"Direcci\u00f3n para el boleto","checkout.endereco_boleto_cep":"C\u00f3digo postal","checkout.endereco_boleto_buscar":"Buscar","checkout.endereco_boleto_numero":"N\u00famero","exit_popup.title":"\u00a1Espera! Tenemos un descuento para ti","exit_popup.description":"Usa el cup\u00f3n abajo en el siguiente paso","exit_popup.button_accept":"Quiero el descuento","exit_popup.button_decline":"No, gracias","exit_popup.close":"Cerrar","exit_popup.coupon_label":"Tu cup\u00f3n"}}";', 1780723966);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.currencies', 's:324:"[{"code":"BRL","symbol":"R$","label":"Real brasileiro","rate_to_brl":1},{"code":"USD","symbol":"US$","label":"D\u00f3lar americano","rate_to_brl":0.179999999999999993338661852249060757458209991455078125},{"code":"EUR","symbol":"\u20ac","label":"Euro","rate_to_brl":0.1600000000000000033306690738754696212708950042724609375}]";', 1780723966);
INSERT INTO public.cache VALUES ('winfy-cache-dashboard:v2:4:hoje', 'a:12:{s:6:"period";s:4:"hoje";s:13:"vendas_totais";d:0;s:16:"vendas_pendentes";d:0;s:17:"quantidade_vendas";i:0;s:12:"ticket_medio";d:0;s:16:"formas_pagamento";a:0:{}s:14:"taxa_conversao";i:0;s:17:"abandono_carrinho";i:0;s:16:"reembolsos_count";i:0;s:16:"reembolsos_total";d:0;s:19:"quantidade_produtos";i:1;s:14:"grafico_vendas";a:24:{i:0;a:2:{s:4:"data";s:1:"0";s:5:"total";d:0;}i:1;a:2:{s:4:"data";s:1:"1";s:5:"total";d:0;}i:2;a:2:{s:4:"data";s:1:"2";s:5:"total";d:0;}i:3;a:2:{s:4:"data";s:1:"3";s:5:"total";d:0;}i:4;a:2:{s:4:"data";s:1:"4";s:5:"total";d:0;}i:5;a:2:{s:4:"data";s:1:"5";s:5:"total";d:0;}i:6;a:2:{s:4:"data";s:1:"6";s:5:"total";d:0;}i:7;a:2:{s:4:"data";s:1:"7";s:5:"total";d:0;}i:8;a:2:{s:4:"data";s:1:"8";s:5:"total";d:0;}i:9;a:2:{s:4:"data";s:1:"9";s:5:"total";d:0;}i:10;a:2:{s:4:"data";s:2:"10";s:5:"total";d:0;}i:11;a:2:{s:4:"data";s:2:"11";s:5:"total";d:0;}i:12;a:2:{s:4:"data";s:2:"12";s:5:"total";d:0;}i:13;a:2:{s:4:"data";s:2:"13";s:5:"total";d:0;}i:14;a:2:{s:4:"data";s:2:"14";s:5:"total";d:0;}i:15;a:2:{s:4:"data";s:2:"15";s:5:"total";d:0;}i:16;a:2:{s:4:"data";s:2:"16";s:5:"total";d:0;}i:17;a:2:{s:4:"data";s:2:"17";s:5:"total";d:0;}i:18;a:2:{s:4:"data";s:2:"18";s:5:"total";d:0;}i:19;a:2:{s:4:"data";s:2:"19";s:5:"total";d:0;}i:20;a:2:{s:4:"data";s:2:"20";s:5:"total";d:0;}i:21;a:2:{s:4:"data";s:2:"21";s:5:"total";d:0;}i:22;a:2:{s:4:"data";s:2:"22";s:5:"total";d:0;}i:23;a:2:{s:4:"data";s:2:"23";s:5:"total";d:0;}}}', 1780720644);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.dashboard_banners', 'a:0:{}', 1780720404);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.merchant_settlement_rules', 'N;', 1780720227);
INSERT INTO public.cache VALUES ('winfy-cache-dashboard:v2:4:ano', 'a:12:{s:6:"period";s:3:"ano";s:13:"vendas_totais";d:5;s:16:"vendas_pendentes";d:0;s:17:"quantidade_vendas";i:2;s:12:"ticket_medio";d:2.5;s:16:"formas_pagamento";a:1:{i:0;a:4:{s:6:"metodo";s:3:"pix";s:5:"label";s:3:"PIX";s:5:"total";d:5;s:10:"quantidade";i:2;}}s:14:"taxa_conversao";i:0;s:17:"abandono_carrinho";i:0;s:16:"reembolsos_count";i:0;s:16:"reembolsos_total";d:0;s:19:"quantidade_produtos";i:1;s:14:"grafico_vendas";a:1:{i:0;a:2:{s:4:"data";s:10:"2026-04-30";s:5:"total";d:5;}}}', 1780718642);
INSERT INTO public.cache VALUES ('winfy-cache-e986aeb8a1a01904154ce85af2f140c8', 'i:1;', 1780721947);
INSERT INTO public.cache VALUES ('winfy-cache-c08e8dde09f87d2be1501461f81ee54f8d76ffa8:timer', 'i:1777584185;', 1777584185);
INSERT INTO public.cache VALUES ('winfy-cache-c08e8dde09f87d2be1501461f81ee54f8d76ffa8', 'i:1;', 1777584185);
INSERT INTO public.cache VALUES ('winfy-cache-5052603d875de8298812cddb4af7d783fd04d22a:timer', 'i:1777583164;', 1777583164);
INSERT INTO public.cache VALUES ('winfy-cache-queue_heartbeat', 's:25:"2026-04-30T18:22:06-03:00";', 1777584426);
INSERT INTO public.cache VALUES ('winfy-cache-5052603d875de8298812cddb4af7d783fd04d22a', 'i:1;', 1777583164);
INSERT INTO public.cache VALUES ('winfy-cache-8fc56699d38cfd2f6f75cba824c7c3d0c8fff6be:timer', 'i:1777586627;', 1777586627);
INSERT INTO public.cache VALUES ('winfy-cache-77de68daecd823babbb58edb1c8e14d7106e83bb:timer', 'i:1777584917;', 1777584917);
INSERT INTO public.cache VALUES ('winfy-cache-8fc56699d38cfd2f6f75cba824c7c3d0c8fff6be', 'i:2;', 1777586627);
INSERT INTO public.cache VALUES ('winfy-cache-77de68daecd823babbb58edb1c8e14d7106e83bb', 'i:1;', 1777584917);
INSERT INTO public.cache VALUES ('winfy-cache-dashboard:v2:4:ontem', 'a:12:{s:6:"period";s:5:"ontem";s:13:"vendas_totais";d:0;s:16:"vendas_pendentes";d:0;s:17:"quantidade_vendas";i:0;s:12:"ticket_medio";d:0;s:16:"formas_pagamento";a:0:{}s:14:"taxa_conversao";i:0;s:17:"abandono_carrinho";i:0;s:16:"reembolsos_count";i:0;s:16:"reembolsos_total";d:0;s:19:"quantidade_produtos";i:1;s:14:"grafico_vendas";a:24:{i:0;a:2:{s:4:"data";s:1:"0";s:5:"total";d:0;}i:1;a:2:{s:4:"data";s:1:"1";s:5:"total";d:0;}i:2;a:2:{s:4:"data";s:1:"2";s:5:"total";d:0;}i:3;a:2:{s:4:"data";s:1:"3";s:5:"total";d:0;}i:4;a:2:{s:4:"data";s:1:"4";s:5:"total";d:0;}i:5;a:2:{s:4:"data";s:1:"5";s:5:"total";d:0;}i:6;a:2:{s:4:"data";s:1:"6";s:5:"total";d:0;}i:7;a:2:{s:4:"data";s:1:"7";s:5:"total";d:0;}i:8;a:2:{s:4:"data";s:1:"8";s:5:"total";d:0;}i:9;a:2:{s:4:"data";s:1:"9";s:5:"total";d:0;}i:10;a:2:{s:4:"data";s:2:"10";s:5:"total";d:0;}i:11;a:2:{s:4:"data";s:2:"11";s:5:"total";d:0;}i:12;a:2:{s:4:"data";s:2:"12";s:5:"total";d:0;}i:13;a:2:{s:4:"data";s:2:"13";s:5:"total";d:0;}i:14;a:2:{s:4:"data";s:2:"14";s:5:"total";d:0;}i:15;a:2:{s:4:"data";s:2:"15";s:5:"total";d:0;}i:16;a:2:{s:4:"data";s:2:"16";s:5:"total";d:0;}i:17;a:2:{s:4:"data";s:2:"17";s:5:"total";d:0;}i:18;a:2:{s:4:"data";s:2:"18";s:5:"total";d:0;}i:19;a:2:{s:4:"data";s:2:"19";s:5:"total";d:0;}i:20;a:2:{s:4:"data";s:2:"20";s:5:"total";d:0;}i:21;a:2:{s:4:"data";s:2:"21";s:5:"total";d:0;}i:22;a:2:{s:4:"data";s:2:"22";s:5:"total";d:0;}i:23;a:2:{s:4:"data";s:2:"23";s:5:"total";d:0;}}}', 1780718638);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.platform_payout_gateway', 'N;', 1780719827);
INSERT INTO public.cache VALUES ('winfy-cache-geo_ip:44955bee5a5b11dc39012dc420163060', 'N;', 1780808204);
INSERT INTO public.cache VALUES ('winfy-cache-e986aeb8a1a01904154ce85af2f140c8:timer', 'i:1780721947;', 1780721947);
INSERT INTO public.cache VALUES ('winfy-cache-0f81c68bdc5dfe62a04223717e95e91ba7fb397c:timer', 'i:1777657490;', 1777657490);
INSERT INTO public.cache VALUES ('winfy-cache-a3f26aa6c6a83d9e509e9cfe6f9e16566880ea69:timer', 'i:1777595946;', 1777595946);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.email_provider', 's:4:"smtp";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.smtp_host', 's:17:"smtp.kinghost.net";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-a3f26aa6c6a83d9e509e9cfe6f9e16566880ea69', 'i:1;', 1777595946);
INSERT INTO public.cache VALUES ('winfy-cache-0f81c68bdc5dfe62a04223717e95e91ba7fb397c', 'i:1;', 1777657490);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.smtp_port', 's:3:"587";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.smtp_encryption', 's:3:"tls";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.smtp_username', 's:20:"contato@winfy.com.br";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.smtp_password', 's:228:"eyJpdiI6IkN0TktkVjEyQVR4akVLUmtsQi9FYmc9PSIsInZhbHVlIjoiNm9ZcFlSNDVPQnR4L3E3SVNvU3UxbzFnUjkvTnowc1R5QnhpQkYrRFBwWT0iLCJtYWMiOiIzY2NkYjY2ZmM0ZWYxMjJmMGJjMTQ4OTJmNzRiN2ZjMWVkOWM1OTQzMmUwMzQ2MDI2OTFjN2RlMjE5MzBkMjJmIiwidGFnIjoiIn0=";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.mail_from_name', 's:5:"winfy";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-setting.global.reply_to', 's:0:"";', 1780719559);
INSERT INTO public.cache VALUES ('winfy-cache-dashboard:v2:4:7dias', 'a:12:{s:6:"period";s:5:"7dias";s:13:"vendas_totais";d:0;s:16:"vendas_pendentes";d:0;s:17:"quantidade_vendas";i:0;s:12:"ticket_medio";d:0;s:16:"formas_pagamento";a:0:{}s:14:"taxa_conversao";i:0;s:17:"abandono_carrinho";i:0;s:16:"reembolsos_count";i:0;s:16:"reembolsos_total";d:0;s:19:"quantidade_produtos";i:1;s:14:"grafico_vendas";a:0:{}}', 1780718640);
INSERT INTO public.cache VALUES ('winfy-cache-407e967fceb88f34c03bc25f9c184bc23e2a73ca:timer', 'i:1780720122;', 1780720122);
INSERT INTO public.cache VALUES ('winfy-cache-schedule_fallback_last_run', 's:25:"2026-06-06T01:59:15-03:00";', 1780722255);
INSERT INTO public.cache VALUES ('winfy-cache-407e967fceb88f34c03bc25f9c184bc23e2a73ca', 'i:1;', 1780720122);


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cademi_integration_product; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cademi_integration_product_offer; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cademi_integration_subscription_plan; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cademi_integrations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: checkout_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.checkout_sessions VALUES (1, 4, NULL, NULL, 'oenmpop', 'e579fdcc-6da1-47b8-9e62-225cc2509668', 'visit', NULL, NULL, '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 16:36:29', '2026-04-30 16:36:29', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (2, 4, NULL, NULL, 'oenmpop', '05bcdaa5-cf5c-4442-81b4-3b4c141acd3c', 'visit', NULL, NULL, '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 16:37:23', '2026-04-30 16:37:23', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (3, 4, NULL, NULL, 'oenmpop', '79656ada-f449-4cda-8911-86e756223767', 'visit', NULL, NULL, '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 16:40:32', '2026-04-30 16:40:32', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (4, 4, NULL, NULL, 'oenmpop', '18d7f9fb-f2ae-4566-8b4e-919bb4554e53', 'visit', NULL, NULL, '186.244.137.96', NULL, NULL, NULL, NULL, '2026-04-30 16:41:11', '2026-04-30 16:41:11', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (5, 4, NULL, NULL, 'oenmpop', 'ce35e71c-1c97-4ea2-8668-5047cf9e27a7', 'visit', NULL, NULL, '186.244.137.96', NULL, NULL, NULL, NULL, '2026-04-30 17:53:36', '2026-04-30 17:53:36', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (6, 4, NULL, NULL, 'oenmpop', 'fef1e108-9a9b-47ea-8626-0e3130210124', 'visit', NULL, NULL, '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 17:54:20', '2026-04-30 17:54:20', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (7, 4, NULL, NULL, 'oenmpop', 'a1cba8f6-d70e-4ef3-91c1-87fe344bcd9b', 'visit', NULL, NULL, '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 17:59:49', '2026-04-30 17:59:49', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (19, 4, NULL, NULL, 'oenmpop', '6c3f5687-6606-43a5-9b2c-38bc792c4d8f', 'visit', NULL, NULL, '2804:13c:60b:d00:ad25:b720:2252:bd31', NULL, NULL, NULL, NULL, '2026-06-06 00:55:50', '2026-06-06 00:55:50', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (20, 4, NULL, NULL, 'oenmpop', '58011bde-32e2-4004-add8-d6c8f7bd4421', 'visit', NULL, NULL, '2804:13c:60b:d00:3d56:da0b:5c4d:62b', NULL, NULL, NULL, NULL, '2026-06-06 01:55:55', '2026-06-06 01:55:55', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (8, 4, NULL, NULL, 'oenmpop', 'f765ca42-5a71-4d6b-8dfa-b7af4de3a920', 'converted', 'contato@win', 'Contato Winfy', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 1, NULL, NULL, NULL, '2026-04-30 18:01:22', '2026-04-30 18:04:01', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (21, 4, NULL, NULL, 'oenmpop', '745bfdeb-9c77-4f2d-837b-8b37e9513a93', 'visit', NULL, NULL, '2804:13c:60b:d00:3d56:da0b:5c4d:62b', NULL, NULL, NULL, NULL, '2026-06-06 01:56:23', '2026-06-06 01:56:23', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (9, 4, NULL, NULL, 'oenmpop', '663514d7-5a2d-41a1-8c65-7c36b0664483', 'form_filled', 'contato@winfy.com.br', 'Contato Winfy', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:11:01', '2026-04-30 18:11:02', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (10, 4, NULL, NULL, 'oenmpop', '72df34fd-600d-4dee-87df-b4d9e256851d', 'form_filled', 'contato@winfy.com.br', 'Contato Winfy', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:13:34', '2026-04-30 18:13:34', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (22, 4, NULL, NULL, 'oenmpop', 'b32f1173-9291-4ebe-a77c-b4921d9e9e58', 'form_filled', 'ok@ok.com', 'ok', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', NULL, NULL, NULL, NULL, '2026-06-06 01:56:44', '2026-06-06 01:56:45', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (11, 4, NULL, NULL, 'oenmpop', 'ba069142-632f-4efc-a713-9c45141f0e44', 'form_filled', 'contato@winfy.com.br', 'Contato Winfy', '186.244.137.96', NULL, NULL, NULL, NULL, '2026-04-30 18:15:22', '2026-04-30 18:15:23', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (23, 4, NULL, NULL, 'oenmpop', 'efddb84e-fabe-430c-ac3b-98ca28368b85', 'visit', NULL, NULL, '2804:13c:60b:d00:ad25:b720:2252:bd31', NULL, NULL, NULL, NULL, '2026-06-06 02:31:46', '2026-06-06 02:31:46', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (12, 4, NULL, NULL, 'oenmpop', '0fd57430-7da8-49c8-9e87-03263cf13681', 'form_filled', 'contato@winfy.com.br', 'Contato Winfy', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:19:55', '2026-04-30 18:19:56', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (13, 4, NULL, NULL, 'oenmpop', '16f08f00-dc10-40ce-b255-874ae5be8c37', 'form_filled', 'contato@winfy.com.br', 'Contato Winfy', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:19:59', '2026-04-30 18:20:00', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (14, 4, NULL, NULL, 'oenmpop', '06f59c61-eef8-4533-a335-9a0d44f164a5', 'form_filled', 'contato@winfy.com.br', 'Contato Winfy', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:20:14', '2026-04-30 18:20:15', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (15, 4, NULL, NULL, 'oenmpop', '7a9e2644-34b6-4648-b7d8-302de931e0dd', 'converted', 'contato@winfy.com.br', 'Contato Winfy', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 2, NULL, NULL, NULL, '2026-04-30 18:21:06', '2026-04-30 18:21:36', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (16, 4, NULL, NULL, 'oenmpop', 'dfe160b2-5521-49ad-875e-96bf42c02a85', 'form_filled', 'jaderbrandao@winfy.com.br', 'Jader Brandao', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:55:16', '2026-04-30 18:55:17', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (17, 4, NULL, NULL, 'oenmpop', '3c8821f8-522c-4568-9a43-fcf9b231f830', 'form_filled', 'jaderbrandao@winfy.com.br', 'Jader Brandao', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:55:44', '2026-04-30 18:55:45', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.checkout_sessions VALUES (18, 4, NULL, NULL, 'oenmpop', '47b9af12-6c57-462b-8d21-72eefe693630', 'form_filled', 'jaderbrandao@winfy.com.br', 'Jader Brandao', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, '2026-04-30 18:55:59', '2026-04-30 18:56:00', NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: coupon_product; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_campaign_sends; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: gateway_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.gateway_credentials VALUES (1, NULL, 'mercadopago', 'eyJpdiI6IlIrSjdMMXpzNy81Y0ZObXEzVEdtdVE9PSIsInZhbHVlIjoiSEN3NldBRTdkSmxRRmtxeHJlOVI2akFEYmxwZG5DSEV0V21zdHljcGtyUHphSFpVVnF3UCs3cVVwSnZMd2d1WldrekY5aGZKT1NlT2RUZjBpTjF3T00rYWh4T1FuQmxDaHBzNXA4dmZQbUVURjBIclNoUHBuSjZPQ3lpNmdiVi9XcVJ2MU01dzFXejJsbjBRWHNFck1wampRMFYrdFR3STFNUDdVd1NINGV6bkNLWTZBZVZmL0FXNHBNZDQ1Q0wxbnlQK0o4UWZFMnFqbjdOVTcvTUptWUFGVys3MCtuN2ZhbkpBT0QrRE9ibz0iLCJtYWMiOiIxNDljZmI1YjRhMWQxNzlmMzc0ZTllMzYzMWEyYzlmNDVlMTEwZDRiYjRmNjU4MjU0OTk0YjhiMzFlOTM3YjU3IiwidGFnIjoiIn0=', true, '2026-04-30 17:23:54', '2026-04-30 17:23:54');


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.jobs VALUES (1, 'default', '{"uuid":"e5c76afb-871f-4e8c-8862-1f2d4281ec7b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777575623,"delay":null}', 0, NULL, 1777575623, 1777575623);
INSERT INTO public.jobs VALUES (2, 'default', '{"uuid":"5e0f1c2b-f2d5-492e-8824-d34f0e26b30f","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777575692,"delay":null}', 0, NULL, 1777575692, 1777575692);
INSERT INTO public.jobs VALUES (3, 'default', '{"uuid":"c2832dd3-72e9-4d86-838f-6af55ef61643","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777575763,"delay":null}', 0, NULL, 1777575763, 1777575763);
INSERT INTO public.jobs VALUES (4, 'default', '{"uuid":"c21fb13d-65d2-488f-929f-f0a1af87bce6","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777575832,"delay":null}', 0, NULL, 1777575832, 1777575832);
INSERT INTO public.jobs VALUES (5, 'default', '{"uuid":"f883e588-648c-40c1-8e95-9ecca64cd63c","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777575908,"delay":null}', 0, NULL, 1777575908, 1777575908);
INSERT INTO public.jobs VALUES (6, 'default', '{"uuid":"d98cc593-15fd-4135-bb7f-928ede75ed10","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576000,"delay":null}', 0, NULL, 1777576000, 1777576000);
INSERT INTO public.jobs VALUES (7, 'default', '{"uuid":"293c58e2-6803-4afe-b93f-86281df3be80","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576284,"delay":null}', 0, NULL, 1777576284, 1777576284);
INSERT INTO public.jobs VALUES (8, 'default', '{"uuid":"b49a8629-c4f1-4e50-8092-47ed88b37647","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576342,"delay":null}', 0, NULL, 1777576342, 1777576342);
INSERT INTO public.jobs VALUES (9, 'default', '{"uuid":"ae20ff60-666d-48c7-9178-c3780164c650","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576477,"delay":null}', 0, NULL, 1777576477, 1777576477);
INSERT INTO public.jobs VALUES (10, 'default', '{"uuid":"3a3cdee4-458f-456d-9c25-a1816484134d","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576553,"delay":null}', 0, NULL, 1777576553, 1777576553);
INSERT INTO public.jobs VALUES (11, 'default', '{"uuid":"c2249aea-a719-4b47-98af-853e7db1652f","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576649,"delay":null}', 0, NULL, 1777576649, 1777576649);
INSERT INTO public.jobs VALUES (12, 'default', '{"uuid":"b3c99057-014b-4e11-b7d8-69d7533ce41d","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576785,"delay":null}', 0, NULL, 1777576785, 1777576785);
INSERT INTO public.jobs VALUES (13, 'default', '{"uuid":"aa9b7e13-5e98-4a35-94df-fe4c3834173a","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576840,"delay":null}', 0, NULL, 1777576840, 1777576840);
INSERT INTO public.jobs VALUES (14, 'default', '{"uuid":"1ca0288f-46b0-4b10-b08e-59512193462a","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576901,"delay":null}', 0, NULL, 1777576901, 1777576901);
INSERT INTO public.jobs VALUES (15, 'default', '{"uuid":"71c0d984-77c4-40f7-ab3f-dd49dd9d2c7a","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777576956,"delay":null}', 0, NULL, 1777576956, 1777576956);
INSERT INTO public.jobs VALUES (16, 'default', '{"uuid":"69db2778-de7a-4b44-bfff-4dd3635b458a","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577015,"delay":null}', 0, NULL, 1777577015, 1777577015);
INSERT INTO public.jobs VALUES (17, 'default', '{"uuid":"a028ed94-ec20-4969-999d-f3b97208b247","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577080,"delay":null}', 0, NULL, 1777577080, 1777577080);
INSERT INTO public.jobs VALUES (18, 'default', '{"uuid":"7988b637-e21c-4256-93f2-5beecdf9c9a8","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577172,"delay":null}', 0, NULL, 1777577172, 1777577172);
INSERT INTO public.jobs VALUES (19, 'default', '{"uuid":"f7671da9-6c70-4cbc-a6b3-c92c1749b74b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577269,"delay":null}', 0, NULL, 1777577269, 1777577269);
INSERT INTO public.jobs VALUES (20, 'default', '{"uuid":"3e593138-640d-422c-9d1d-7d578151ee3b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577325,"delay":null}', 0, NULL, 1777577325, 1777577325);
INSERT INTO public.jobs VALUES (21, 'default', '{"uuid":"8063fb97-fbd2-45e3-8749-db977ac6b1b2","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577467,"delay":null}', 0, NULL, 1777577467, 1777577467);
INSERT INTO public.jobs VALUES (22, 'default', '{"uuid":"3ba2c022-6954-49d3-81c0-c67397aa2d51","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577554,"delay":null}', 0, NULL, 1777577554, 1777577554);
INSERT INTO public.jobs VALUES (23, 'default', '{"uuid":"6bdb4953-8d60-4326-925e-a9697836dbc8","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577709,"delay":null}', 0, NULL, 1777577709, 1777577709);
INSERT INTO public.jobs VALUES (24, 'default', '{"uuid":"32fbd9b7-5c7f-4fda-9608-8c1196ed2c65","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577767,"delay":null}', 0, NULL, 1777577767, 1777577767);
INSERT INTO public.jobs VALUES (25, 'default', '{"uuid":"4c6f7959-d6fd-490d-aeae-d4f662d1117a","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577837,"delay":null}', 0, NULL, 1777577837, 1777577837);
INSERT INTO public.jobs VALUES (26, 'default', '{"uuid":"92531841-bae7-4993-aedb-e48427f177e4","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577925,"delay":null}', 0, NULL, 1777577925, 1777577925);
INSERT INTO public.jobs VALUES (27, 'default', '{"uuid":"18cdd16b-6ef4-410b-bc40-610491add0c3","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777577990,"delay":null}', 0, NULL, 1777577990, 1777577990);
INSERT INTO public.jobs VALUES (28, 'default', '{"uuid":"9d75e1b8-52c8-4cff-9aa4-732ac27c9acd","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777578049,"delay":null}', 0, NULL, 1777578049, 1777578049);
INSERT INTO public.jobs VALUES (29, 'default', '{"uuid":"318ef49e-ea51-4b38-9c56-23f1bfb4cdc8","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777578106,"delay":null}', 0, NULL, 1777578106, 1777578106);
INSERT INTO public.jobs VALUES (30, 'default', '{"uuid":"23bc81a5-8105-4b42-a0cf-f24fcb6b525c","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777578164,"delay":null}', 0, NULL, 1777578164, 1777578164);
INSERT INTO public.jobs VALUES (31, 'default', '{"uuid":"68af8578-a7ec-44e2-9451-1455fa79e9f5","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777580187,"delay":null}', 0, NULL, 1777580187, 1777580187);
INSERT INTO public.jobs VALUES (32, 'default', '{"uuid":"61a77903-ee8a-43e2-81b6-2823d648e70d","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777582242,"delay":null}', 0, NULL, 1777582242, 1777582242);
INSERT INTO public.jobs VALUES (33, 'default', '{"uuid":"35a95469-6c9c-4ace-8ac2-ff89afe39416","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777582397,"delay":null}', 0, NULL, 1777582397, 1777582397);
INSERT INTO public.jobs VALUES (34, 'default', '{"uuid":"7e9e4c2f-de08-45bb-9726-d34a9ab35ee1","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777582454,"delay":null}', 0, NULL, 1777582454, 1777582454);
INSERT INTO public.jobs VALUES (35, 'default', '{"uuid":"f9176015-7c81-44a3-980a-b16889e60fc9","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777582662,"delay":null}', 0, NULL, 1777582662, 1777582662);
INSERT INTO public.jobs VALUES (36, 'default', '{"uuid":"3cf40dd6-af17-4e5a-b318-0b222446971d","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777582774,"delay":null}', 0, NULL, 1777582774, 1777582774);
INSERT INTO public.jobs VALUES (37, 'default', '{"uuid":"98e0f8ca-ad4f-4c11-96ad-0da05cff0647","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777582860,"delay":null}', 0, NULL, 1777582860, 1777582860);
INSERT INTO public.jobs VALUES (38, 'default', '{"uuid":"cabf8cb0-a538-42f5-b83c-c8295e000294","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777582919,"delay":null}', 0, NULL, 1777582919, 1777582919);
INSERT INTO public.jobs VALUES (39, 'default', '{"uuid":"7ace0770-ea6c-4922-aada-11b10058718b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777583041,"delay":null}', 0, NULL, 1777583041, 1777583041);
INSERT INTO public.jobs VALUES (40, 'default', '{"uuid":"c49e5bbb-45c6-4866-a883-3ed3b7f0606f","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777583098,"delay":null}', 0, NULL, 1777583098, 1777583098);
INSERT INTO public.jobs VALUES (41, 'default', '{"uuid":"63411328-bc4f-4ff4-954f-0f554df8d6a8","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777583460,"delay":null}', 0, NULL, 1777583460, 1777583460);
INSERT INTO public.jobs VALUES (42, 'default', '{"uuid":"e7ae4281-57f8-4569-9164-589c1f65602a","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777583556,"delay":null}', 0, NULL, 1777583556, 1777583556);
INSERT INTO public.jobs VALUES (43, 'default', '{"uuid":"e6a85faa-d653-4dca-8e40-568b1058997e","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777583611,"delay":null}', 0, NULL, 1777583611, 1777583611);
INSERT INTO public.jobs VALUES (44, 'default', '{"uuid":"85986d38-3444-41c4-a804-3bd3e0f1fc57","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777583715,"delay":null}', 0, NULL, 1777583715, 1777583715);
INSERT INTO public.jobs VALUES (45, 'default', '{"uuid":"76412337-7814-4c5b-88d4-698e61890fc6","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777583995,"delay":null}', 0, NULL, 1777583995, 1777583995);
INSERT INTO public.jobs VALUES (46, 'default', '{"uuid":"cdd21ec3-2f5d-4d18-b4a4-520f62f74708","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777584543,"delay":null}', 0, NULL, 1777584543, 1777584543);
INSERT INTO public.jobs VALUES (47, 'default', '{"uuid":"28007110-7d52-4b04-a7a9-9bbc73825dc4","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777584670,"delay":null}', 0, NULL, 1777584670, 1777584670);
INSERT INTO public.jobs VALUES (48, 'default', '{"uuid":"70fd1922-cc67-4f7b-8e72-462698d71a6e","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777584801,"delay":null}', 0, NULL, 1777584801, 1777584801);
INSERT INTO public.jobs VALUES (49, 'default', '{"uuid":"a60e5f91-2397-45d2-9bcb-959f83e56972","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777584883,"delay":null}', 0, NULL, 1777584883, 1777584883);
INSERT INTO public.jobs VALUES (50, 'default', '{"uuid":"c660313e-0a8a-4260-8907-24766f808773","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777584968,"delay":null}', 0, NULL, 1777584968, 1777584968);
INSERT INTO public.jobs VALUES (51, 'default', '{"uuid":"e6db9c92-47ba-46ec-aaa8-280195518e4d","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777585472,"delay":null}', 0, NULL, 1777585472, 1777585472);
INSERT INTO public.jobs VALUES (52, 'default', '{"uuid":"0066e66c-6924-40e3-94ed-2c940d45b4bd","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777585540,"delay":null}', 0, NULL, 1777585540, 1777585540);
INSERT INTO public.jobs VALUES (53, 'default', '{"uuid":"cdf0c2d8-7a25-4317-96ea-d61487a94b8f","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777585612,"delay":null}', 0, NULL, 1777585612, 1777585612);
INSERT INTO public.jobs VALUES (54, 'default', '{"uuid":"eacb312b-f57d-4f51-a117-ecafcb42e63f","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777586105,"delay":null}', 0, NULL, 1777586105, 1777586105);
INSERT INTO public.jobs VALUES (55, 'default', '{"uuid":"8ae57183-4aca-4a0c-8969-a25cf4094393","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777586161,"delay":null}', 0, NULL, 1777586161, 1777586161);
INSERT INTO public.jobs VALUES (56, 'default', '{"uuid":"88768f20-b5ae-4a52-a012-6ee20134d475","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777586216,"delay":null}', 0, NULL, 1777586216, 1777586216);
INSERT INTO public.jobs VALUES (57, 'default', '{"uuid":"163eccf3-8b24-4d93-a54b-79df8a8b1ec5","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777586272,"delay":null}', 0, NULL, 1777586272, 1777586272);
INSERT INTO public.jobs VALUES (58, 'default', '{"uuid":"33dec18a-e412-4e16-b0e1-7f3e2f6511e1","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777594918,"delay":null}', 0, NULL, 1777594918, 1777594918);
INSERT INTO public.jobs VALUES (59, 'default', '{"uuid":"8f0bbb74-c54d-4fba-adcc-ce3a8ca267f8","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777595400,"delay":null}', 0, NULL, 1777595400, 1777595400);
INSERT INTO public.jobs VALUES (60, 'default', '{"uuid":"dd951bea-b978-4027-b96b-4b8ae5f9ae50","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777595456,"delay":null}', 0, NULL, 1777595456, 1777595456);
INSERT INTO public.jobs VALUES (61, 'default', '{"uuid":"86647c44-cdc7-462d-b604-599172ddc08c","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777595788,"delay":null}', 0, NULL, 1777595788, 1777595788);
INSERT INTO public.jobs VALUES (62, 'default', '{"uuid":"4b3b8909-3021-4906-9220-2f46af7a60a9","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1777657367,"delay":null}', 0, NULL, 1777657367, 1777657367);
INSERT INTO public.jobs VALUES (63, 'default', '{"uuid":"ff5be51a-23fa-4345-990a-b7d738e09149","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718135,"delay":null}', 0, NULL, 1780718135, 1780718135);
INSERT INTO public.jobs VALUES (64, 'default', '{"uuid":"b51c8718-b2e7-44b6-9a4e-1bdd47b4b54d","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718219,"delay":null}', 0, NULL, 1780718219, 1780718219);
INSERT INTO public.jobs VALUES (65, 'default', '{"uuid":"b31b4ac0-fd78-4db4-b2dd-2671fc885905","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718330,"delay":null}', 0, NULL, 1780718330, 1780718330);
INSERT INTO public.jobs VALUES (66, 'default', '{"uuid":"93bbbc18-9171-4e9b-bdb4-10da93ffde09","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718427,"delay":null}', 0, NULL, 1780718427, 1780718427);
INSERT INTO public.jobs VALUES (67, 'default', '{"uuid":"6ae60fec-54c6-48c9-9e84-d63cc6992ab7","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718495,"delay":null}', 0, NULL, 1780718495, 1780718495);
INSERT INTO public.jobs VALUES (68, 'default', '{"uuid":"c2b9238c-013b-4d34-84c0-e20b2b4f5cc7","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718550,"delay":null}', 0, NULL, 1780718550, 1780718550);
INSERT INTO public.jobs VALUES (69, 'default', '{"uuid":"9d1fc8bc-17b2-401b-b2bd-0568698ac491","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718606,"delay":null}', 0, NULL, 1780718606, 1780718606);
INSERT INTO public.jobs VALUES (70, 'default', '{"uuid":"39a405ae-b487-47b7-bad0-4787507251d6","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718673,"delay":null}', 0, NULL, 1780718673, 1780718673);
INSERT INTO public.jobs VALUES (71, 'default', '{"uuid":"03af8cf1-33ed-458f-86e0-884ffcae725b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718742,"delay":null}', 0, NULL, 1780718742, 1780718742);
INSERT INTO public.jobs VALUES (72, 'default', '{"uuid":"1939dc74-dc91-48b0-b255-e8d843841a9e","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718819,"delay":null}', 0, NULL, 1780718819, 1780718819);
INSERT INTO public.jobs VALUES (73, 'default', '{"uuid":"a04edec0-45b4-44ee-a4d7-6fe257079baa","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780718879,"delay":null}', 0, NULL, 1780718879, 1780718879);
INSERT INTO public.jobs VALUES (74, 'default', '{"uuid":"6053c087-e3da-4904-8881-653eaa0fb566","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719025,"delay":null}', 0, NULL, 1780719025, 1780719025);
INSERT INTO public.jobs VALUES (75, 'default', '{"uuid":"06921937-ca57-41e8-a39a-578d92a5622d","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719121,"delay":null}', 0, NULL, 1780719121, 1780719121);
INSERT INTO public.jobs VALUES (76, 'default', '{"uuid":"85c4c7b3-2564-410d-8b84-96c24158cb6b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719183,"delay":null}', 0, NULL, 1780719183, 1780719183);
INSERT INTO public.jobs VALUES (77, 'default', '{"uuid":"6b9c4891-ec6c-4648-8969-4ffe053b1a70","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719295,"delay":null}', 0, NULL, 1780719295, 1780719295);
INSERT INTO public.jobs VALUES (78, 'default', '{"uuid":"9b5b65e0-e167-428d-a42c-c65fd2fffd9b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719419,"delay":null}', 0, NULL, 1780719419, 1780719419);
INSERT INTO public.jobs VALUES (79, 'default', '{"uuid":"47e7a13e-a27f-4a5a-8b90-511c74ab1f3b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719540,"delay":null}', 0, NULL, 1780719540, 1780719540);
INSERT INTO public.jobs VALUES (80, 'default', '{"uuid":"1411e6b3-e1d7-40a2-afe6-cab68be96072","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719897,"delay":null}', 0, NULL, 1780719897, 1780719897);
INSERT INTO public.jobs VALUES (81, 'default', '{"uuid":"b39eed21-63e2-4bb2-ade3-3e556dc9861c","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780719970,"delay":null}', 0, NULL, 1780719970, 1780719970);
INSERT INTO public.jobs VALUES (82, 'default', '{"uuid":"2625d581-b101-40c3-943c-675db78e3711","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780720062,"delay":null}', 0, NULL, 1780720062, 1780720062);
INSERT INTO public.jobs VALUES (83, 'default', '{"uuid":"7926d652-b1ee-406e-97d3-73cd95d2ac06","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780720129,"delay":null}', 0, NULL, 1780720129, 1780720129);
INSERT INTO public.jobs VALUES (84, 'default', '{"uuid":"ed78d9a4-2bcd-4ff6-9c43-bac0b77a7b1f","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780720233,"delay":null}', 0, NULL, 1780720233, 1780720233);
INSERT INTO public.jobs VALUES (85, 'default', '{"uuid":"f9be852c-e5e7-4207-b755-82071bcdef6a","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780720337,"delay":null}', 0, NULL, 1780720337, 1780720337);
INSERT INTO public.jobs VALUES (86, 'default', '{"uuid":"703c0400-3fdd-45ee-a749-a3c676dd5fc3","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721296,"delay":null}', 0, NULL, 1780721296, 1780721296);
INSERT INTO public.jobs VALUES (87, 'default', '{"uuid":"96c7e39e-c454-4f69-92f7-5837f3720dcc","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721355,"delay":null}', 0, NULL, 1780721355, 1780721355);
INSERT INTO public.jobs VALUES (88, 'default', '{"uuid":"eebdc151-dffe-4950-89eb-137c67088493","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721469,"delay":null}', 0, NULL, 1780721469, 1780721469);
INSERT INTO public.jobs VALUES (89, 'default', '{"uuid":"f30e19bb-5ae6-42ea-a7a4-698cb3f1afe9","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721530,"delay":null}', 0, NULL, 1780721530, 1780721530);
INSERT INTO public.jobs VALUES (90, 'default', '{"uuid":"c8044ce1-b84b-4314-863d-780c0e233fd0","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721606,"delay":null}', 0, NULL, 1780721606, 1780721606);
INSERT INTO public.jobs VALUES (91, 'default', '{"uuid":"47bd36bd-3114-414b-8d50-8a66a8bd73db","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721739,"delay":null}', 0, NULL, 1780721739, 1780721739);
INSERT INTO public.jobs VALUES (92, 'default', '{"uuid":"6da209f1-e446-433d-9dc3-8e711cf05a5b","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721804,"delay":null}', 0, NULL, 1780721804, 1780721804);
INSERT INTO public.jobs VALUES (93, 'default', '{"uuid":"9dce73cc-d4eb-4c63-87ef-c156cebbda02","displayName":"App\\Jobs\\QueueHeartbeatJob","job":"Illuminate\\Queue\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"App\\Jobs\\QueueHeartbeatJob","command":"O:26:\"App\\Jobs\\QueueHeartbeatJob\":0:{}","batchId":null},"createdAt":1780721955,"delay":null}', 0, NULL, 1780721955, 1780721955);


--
-- Data for Name: kyc_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.kyc_documents VALUES (1, 4, 'rg_front', 'kyc/4/65cc8749-9765-4836-803e-a217cd0cb1ec.png', 'image/png', 1771228, '2026-04-30 18:33:19', '2026-04-30 18:33:19', '447ed47f-d357-4eca-94d1-4bd282e8a98d');
INSERT INTO public.kyc_documents VALUES (2, 4, 'rg_back', 'kyc/4/916273bb-cc11-444e-93b5-d37150b4ffb8.png', 'image/png', 5951545, '2026-04-30 18:33:19', '2026-04-30 18:33:19', '71a7e968-c3cb-4bb8-8ef2-1e5bd9e1d22c');


--
-- Data for Name: member_achievement_unlocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_area_domains; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_area_domains VALUES (1, 'path', 'acesso', '2026-04-30 16:27:49', '2026-04-30 18:57:49', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: member_certificates_issued; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_certificates_issued VALUES (1, 4, '2026-04-30 16:31:23', 100, '2026-04-30 16:31:23', '2026-04-30 16:31:23', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: member_comments; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_comments VALUES (1, 6, 1, NULL, 'legal, muito bom', 'approved', '2026-04-30 18:56:56', 4, '2026-04-30 18:23:17', '2026-04-30 18:56:56', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.member_comments VALUES (2, 4, 3, NULL, 'muito bom', 'pending', NULL, NULL, '2026-06-06 01:52:31', '2026-06-06 01:52:31', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.member_comments VALUES (3, 4, 3, NULL, 'top', 'pending', NULL, NULL, '2026-06-06 01:52:40', '2026-06-06 01:52:40', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: member_community_pages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_community_post_comments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_community_post_likes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_community_posts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_internal_products; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_lesson_progress; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_lesson_progress VALUES (1, 4, 1, '2026-04-30 16:12:21', 100, '2026-04-30 16:11:33', '2026-04-30 16:12:21', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.member_lesson_progress VALUES (2, 4, 2, '2026-04-30 16:24:39', 100, '2026-04-30 16:21:41', '2026-04-30 16:24:39', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.member_lesson_progress VALUES (3, 6, 1, '2026-04-30 19:00:04', 100, '2026-04-30 18:23:06', '2026-04-30 19:00:04', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.member_lesson_progress VALUES (4, 4, 3, '2026-06-06 01:51:20', 100, '2026-06-06 01:51:19', '2026-06-06 01:51:20', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.member_lesson_progress VALUES (5, 4, 4, '2026-06-06 01:52:49', 100, '2026-06-06 01:52:48', '2026-06-06 01:52:49', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: member_lessons; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_lessons VALUES (3, 1, 'Material', 3, 'link', 'https://dl.pstmn.io/download/latest/win64', 'executavel', 0, false, '2026-06-06 01:51:09', '2026-06-06 01:51:09', false, 'Postman', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', NULL, NULL, NULL);
INSERT INTO public.member_lessons VALUES (4, 1, 'Sem título', 4, 'text', NULL, 'Conteudo de texto', 0, false, '2026-06-06 01:52:10', '2026-06-06 01:52:10', false, NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', NULL, NULL, NULL);
INSERT INTO public.member_lessons VALUES (1, 1, 'Introdução', 1, 'video', 'https://www.youtube.com/watch?v=qMQiN65sgyg', NULL, 0, false, '2026-04-30 16:11:24', '2026-04-30 16:20:34', false, NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', NULL, NULL, NULL);
INSERT INTO public.member_lessons VALUES (2, 1, 'Instalações', 2, 'video', 'https://www.youtube.com/watch?v=qMQiN65sgyg', NULL, 0, false, '2026-04-30 16:21:24', '2026-04-30 16:28:39', false, NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', NULL, NULL, NULL);


--
-- Data for Name: member_modules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_modules VALUES (1, 1, 'Introdução', 1, 'https://web.winfy.com.br/storage/member-area/45d8e4f6-1be9-4499-a71e-a57e2309cd62/4EJTxOvKL6IJEjUGiuuutbWkXOay6edOOlqVuX3m.jpg', '2026-04-30 16:05:07', '2026-04-30 16:31:07', true, NULL, NULL, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', NULL, NULL, NULL);


--
-- Data for Name: member_notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_sections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_sections VALUES (1, 'Módulo 1', 1, '2026-04-30 16:03:52', '2026-04-30 16:03:52', 'horizontal', 'courses', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: member_turma_user; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: member_turmas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.member_turmas VALUES (1, 'Turma padrão', NULL, NULL, NULL, 1, '2026-04-30 16:03:26', '2026-04-30 16:03:26', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.migrations VALUES (1, '0001_01_01_000000_create_users_table', 1);
INSERT INTO public.migrations VALUES (2, '0001_01_01_000001_create_cache_table', 1);
INSERT INTO public.migrations VALUES (3, '0001_01_01_000002_create_jobs_table', 1);
INSERT INTO public.migrations VALUES (4, '2025_02_20_000001_add_role_and_tenant_to_users_table', 1);
INSERT INTO public.migrations VALUES (5, '2025_02_20_000002_create_settings_table', 1);
INSERT INTO public.migrations VALUES (6, '2025_02_20_000003_create_products_table', 1);
INSERT INTO public.migrations VALUES (7, '2025_02_20_000004_create_product_user_table', 1);
INSERT INTO public.migrations VALUES (8, '2025_02_20_000005_create_orders_table', 1);
INSERT INTO public.migrations VALUES (9, '2025_02_20_100000_create_plugins_table', 1);
INSERT INTO public.migrations VALUES (10, '2025_02_20_100001_add_product_image_and_currency', 1);
INSERT INTO public.migrations VALUES (11, '2025_02_20_120001_create_coupons_table', 1);
INSERT INTO public.migrations VALUES (12, '2025_02_20_130001_create_coupon_product_table', 1);
INSERT INTO public.migrations VALUES (13, '2025_02_20_140001_add_billing_type_to_products_table', 1);
INSERT INTO public.migrations VALUES (14, '2025_02_20_150001_add_conversion_pixels_to_products_table', 1);
INSERT INTO public.migrations VALUES (15, '2025_02_20_200000_drop_cloud_tenant_tables_if_exist', 1);
INSERT INTO public.migrations VALUES (16, '2025_02_21_000001_add_checkout_slug_and_config_to_products_table', 1);
INSERT INTO public.migrations VALUES (17, '2025_02_21_000002_add_cpf_phone_to_orders_table', 1);
INSERT INTO public.migrations VALUES (18, '2025_02_21_000003_add_coupon_code_to_orders_table', 1);
INSERT INTO public.migrations VALUES (19, '2025_02_21_100000_create_gateway_credentials_table', 1);
INSERT INTO public.migrations VALUES (20, '2025_02_21_160000_add_customer_ip_to_orders_table', 1);
INSERT INTO public.migrations VALUES (21, '2025_02_22_000001_add_member_area_config_to_products_table', 1);
INSERT INTO public.migrations VALUES (22, '2025_02_22_000002_create_member_area_domains_table', 1);
INSERT INTO public.migrations VALUES (23, '2025_02_22_000003_create_member_sections_table', 1);
INSERT INTO public.migrations VALUES (24, '2025_02_22_000004_create_member_modules_table', 1);
INSERT INTO public.migrations VALUES (25, '2025_02_22_000005_create_member_lessons_table', 1);
INSERT INTO public.migrations VALUES (26, '2025_02_22_000006_create_member_lesson_progress_table', 1);
INSERT INTO public.migrations VALUES (27, '2025_02_22_000007_create_member_internal_products_table', 1);
INSERT INTO public.migrations VALUES (28, '2025_02_22_000008_create_member_turmas_table', 1);
INSERT INTO public.migrations VALUES (29, '2025_02_22_000009_create_member_turma_user_table', 1);
INSERT INTO public.migrations VALUES (30, '2025_02_22_000010_create_member_comments_table', 1);
INSERT INTO public.migrations VALUES (31, '2025_02_22_000011_create_member_community_pages_table', 1);
INSERT INTO public.migrations VALUES (32, '2025_02_22_000012_create_member_community_posts_table', 1);
INSERT INTO public.migrations VALUES (33, '2025_02_22_000013_create_member_certificates_issued_table', 1);
INSERT INTO public.migrations VALUES (34, '2025_02_22_000014_create_member_push_subscriptions_table', 1);
INSERT INTO public.migrations VALUES (35, '2025_02_22_200001_add_cover_mode_to_member_sections_table', 1);
INSERT INTO public.migrations VALUES (36, '2025_02_22_200001_add_watermark_enabled_to_member_lessons_table', 1);
INSERT INTO public.migrations VALUES (37, '2025_02_22_200002_add_show_title_on_cover_to_member_modules_table', 1);
INSERT INTO public.migrations VALUES (38, '2025_02_22_200003_add_section_type_to_member_sections_table', 1);
INSERT INTO public.migrations VALUES (39, '2025_02_22_200004_add_related_product_and_external_to_member_modules_table', 1);
INSERT INTO public.migrations VALUES (40, '2025_02_23_000001_add_icon_and_banner_to_member_community_pages', 1);
INSERT INTO public.migrations VALUES (41, '2025_02_23_000002_add_image_to_member_community_posts', 1);
INSERT INTO public.migrations VALUES (42, '2025_02_24_000001_add_is_default_to_member_community_pages', 1);
INSERT INTO public.migrations VALUES (43, '2025_02_24_000001_add_link_title_to_member_lessons_table', 1);
INSERT INTO public.migrations VALUES (44, '2025_02_24_000001_create_member_community_post_likes_table', 1);
INSERT INTO public.migrations VALUES (45, '2025_02_24_000002_add_avatar_to_users_table', 1);
INSERT INTO public.migrations VALUES (46, '2025_02_24_000002_create_member_community_post_comments_table', 1);
INSERT INTO public.migrations VALUES (47, '2025_02_24_000003_create_member_achievement_unlocks_table', 1);
INSERT INTO public.migrations VALUES (48, '2025_02_25_000001_create_product_offers_table', 1);
INSERT INTO public.migrations VALUES (49, '2025_02_25_000002_create_subscription_plans_table', 1);
INSERT INTO public.migrations VALUES (50, '2025_02_25_000003_add_offer_plan_period_to_orders_table', 1);
INSERT INTO public.migrations VALUES (51, '2025_02_25_000004_create_saved_payment_methods_table', 1);
INSERT INTO public.migrations VALUES (52, '2025_02_25_000005_create_subscriptions_table', 1);
INSERT INTO public.migrations VALUES (53, '2025_02_26_000001_change_products_id_to_uuid', 1);
INSERT INTO public.migrations VALUES (54, '2025_02_27_000001_add_metadata_to_orders_table', 1);
INSERT INTO public.migrations VALUES (55, '2026_02_25_000001_fix_product_offers_subscription_plans_product_id_uuid', 1);
INSERT INTO public.migrations VALUES (56, '2026_02_26_000001_make_checkout_slug_nullable_on_offers_and_plans', 1);
INSERT INTO public.migrations VALUES (57, '2026_02_26_000002_add_checkout_config_to_offers_and_plans', 1);
INSERT INTO public.migrations VALUES (58, '2026_02_27_000001_fix_member_tables_product_id_uuid', 1);
INSERT INTO public.migrations VALUES (59, '2026_02_27_000002_create_product_order_bumps_table', 1);
INSERT INTO public.migrations VALUES (60, '2026_02_27_000003_create_order_items_table', 1);
INSERT INTO public.migrations VALUES (61, '2026_02_27_000004_change_conversion_pixels_to_json', 1);
INSERT INTO public.migrations VALUES (62, '2026_02_27_012304_create_checkout_sessions_table', 1);
INSERT INTO public.migrations VALUES (63, '2026_02_27_012305_fix_checkout_sessions_product_id_uuid', 1);
INSERT INTO public.migrations VALUES (64, '2026_02_27_100001_create_webhooks_table', 1);
INSERT INTO public.migrations VALUES (65, '2026_02_27_120000_add_abandoned_webhook_fired_at_to_checkout_sessions', 1);
INSERT INTO public.migrations VALUES (66, '2026_02_27_130000_create_webhook_logs_table', 1);
INSERT INTO public.migrations VALUES (67, '2026_02_27_140000_create_utmify_integrations_table', 1);
INSERT INTO public.migrations VALUES (68, '2026_02_27_150000_add_name_to_utmify_integrations', 1);
INSERT INTO public.migrations VALUES (69, '2026_02_27_150000_add_product_filtering_to_webhooks', 1);
INSERT INTO public.migrations VALUES (70, '2026_02_27_150001_create_utmify_integration_product_table', 1);
INSERT INTO public.migrations VALUES (71, '2026_02_27_160000_create_spedy_integrations_table', 1);
INSERT INTO public.migrations VALUES (72, '2026_02_27_160001_create_spedy_integration_product_table', 1);
INSERT INTO public.migrations VALUES (73, '2026_03_01_000001_fix_product_user_product_id_uuid', 1);
INSERT INTO public.migrations VALUES (74, '2026_03_01_000002_fix_subscriptions_product_id_uuid', 1);
INSERT INTO public.migrations VALUES (75, '2026_03_07_000001_create_email_campaigns_tables', 1);
INSERT INTO public.migrations VALUES (76, '2026_03_09_100001_create_api_applications_table', 1);
INSERT INTO public.migrations VALUES (77, '2026_03_09_100002_create_api_checkout_sessions_table', 1);
INSERT INTO public.migrations VALUES (78, '2026_03_09_100003_add_api_fields_to_orders_table', 1);
INSERT INTO public.migrations VALUES (79, '2026_03_09_100004_add_webhook_secret_to_api_applications_table', 1);
INSERT INTO public.migrations VALUES (80, '2026_03_09_100005_add_logo_to_api_applications_table', 1);
INSERT INTO public.migrations VALUES (81, '2026_03_09_100006_add_checkout_sidebar_bg_to_api_applications_table', 1);
INSERT INTO public.migrations VALUES (82, '2026_03_09_200000_add_username_to_users_table', 1);
INSERT INTO public.migrations VALUES (83, '2026_03_09_200001_add_approved_manually_to_orders_table', 1);
INSERT INTO public.migrations VALUES (84, '2026_03_09_300001_create_panel_push_subscriptions_table', 1);
INSERT INTO public.migrations VALUES (85, '2026_03_11_000001_create_panel_notifications_table', 1);
INSERT INTO public.migrations VALUES (86, '2026_03_12_000001_add_event_key_to_panel_notifications_table', 1);
INSERT INTO public.migrations VALUES (87, '2026_03_13_000001_create_member_notifications_table', 1);
INSERT INTO public.migrations VALUES (88, '2026_03_15_000001_add_default_return_url_to_api_applications_table', 1);
INSERT INTO public.migrations VALUES (89, '2026_03_15_000003_add_content_files_to_member_lessons_table', 1);
INSERT INTO public.migrations VALUES (90, '2026_03_15_000004_add_release_schedule_to_member_modules_and_lessons_tables', 1);
INSERT INTO public.migrations VALUES (91, '2026_04_07_000001_create_cademi_integrations_table', 1);
INSERT INTO public.migrations VALUES (92, '2026_04_07_000002_create_cademi_integration_product_table', 1);
INSERT INTO public.migrations VALUES (93, '2026_04_07_000003_create_cademi_integration_product_offer_table', 1);
INSERT INTO public.migrations VALUES (94, '2026_04_07_000004_create_cademi_integration_subscription_plan_table', 1);
INSERT INTO public.migrations VALUES (95, '2026_04_07_000005_add_delivery_method_and_postback_token_to_cademi_integrations_table', 1);
INSERT INTO public.migrations VALUES (96, '2026_04_07_000006_add_cademi_produto_ids_to_cademi_pivot_tables', 1);
INSERT INTO public.migrations VALUES (97, '2026_04_07_120000_create_team_roles_table', 1);
INSERT INTO public.migrations VALUES (98, '2026_04_07_120001_create_team_role_product_table', 1);
INSERT INTO public.migrations VALUES (99, '2026_04_07_120002_add_team_role_id_to_users_table', 1);
INSERT INTO public.migrations VALUES (100, '2026_04_07_180000_create_team_audit_logs_table', 1);
INSERT INTO public.migrations VALUES (101, '2026_04_10_000001_platform_gateway_roles_and_merchant_tables', 1);
INSERT INTO public.migrations VALUES (102, '2026_04_10_120000_email_campaigns_global_tenant_null', 1);
INSERT INTO public.migrations VALUES (103, '2026_04_10_140000_promote_dev_at_dev_com_to_admin', 1);
INSERT INTO public.migrations VALUES (104, '2026_04_11_000001_ensure_platform_merchant_tables', 1);
INSERT INTO public.migrations VALUES (105, '2026_04_11_120000_fix_checkout_sessions_product_id_uuid_pgsql', 1);
INSERT INTO public.migrations VALUES (106, '2026_04_11_140000_merchant_settlement_withdrawals_payout', 1);
INSERT INTO public.migrations VALUES (107, '2026_04_11_200000_ensure_users_payout_and_settlement_columns', 1);
INSERT INTO public.migrations VALUES (108, '2026_04_12_100000_financial_wallets_fees_and_payment_method', 1);
INSERT INTO public.migrations VALUES (109, '2026_04_13_100000_create_branding_settings_table', 1);
INSERT INTO public.migrations VALUES (110, '2026_04_13_100001_migrate_white_label_settings_to_branding_settings', 1);
INSERT INTO public.migrations VALUES (111, '2026_04_13_120000_add_kyc_fields_and_kyc_documents_table', 1);
INSERT INTO public.migrations VALUES (112, '2026_04_13_120000_add_public_reference_to_orders_table', 1);
INSERT INTO public.migrations VALUES (113, '2026_04_13_130000_create_sales_achievements_table', 1);
INSERT INTO public.migrations VALUES (114, '2026_04_13_130001_seed_sales_achievements_from_config', 1);
INSERT INTO public.migrations VALUES (115, '2026_04_13_160000_create_platform_languages_table', 1);
INSERT INTO public.migrations VALUES (116, '2026_04_13_160001_create_platform_translations_table', 1);
INSERT INTO public.migrations VALUES (117, '2026_04_13_160002_seed_platform_languages_and_translations', 1);
INSERT INTO public.migrations VALUES (118, '2026_04_13_170000_seed_spanish_platform_language', 1);
INSERT INTO public.migrations VALUES (119, '2026_04_13_200000_create_product_coproducers_table', 1);
INSERT INTO public.migrations VALUES (120, '2026_04_14_100000_add_affiliate_columns_to_products_table', 1);
INSERT INTO public.migrations VALUES (121, '2026_04_14_100001_create_product_affiliate_enrollments_table', 1);
INSERT INTO public.migrations VALUES (122, '2026_04_14_120000_add_public_token_to_kyc_documents_table', 1);
INSERT INTO public.migrations VALUES (123, '2026_04_15_100000_fix_products_showcase_requires_affiliate_enabled', 1);
INSERT INTO public.migrations VALUES (124, '2026_04_16_100000_add_conversion_pixels_to_product_affiliate_enrollments_table', 1);
INSERT INTO public.migrations VALUES (125, '2026_04_17_100000_add_admin_wallet_block_to_tenant_wallets_table', 1);
INSERT INTO public.migrations VALUES (126, '2026_04_20_100000_add_seller_onboarded_at_to_users_table', 1);
INSERT INTO public.migrations VALUES (127, '2026_04_20_100001_migrate_aluno_to_cliente_and_buyer_tenant', 1);
INSERT INTO public.migrations VALUES (128, '2026_04_20_100002_add_refund_policy_days_to_products_table', 1);
INSERT INTO public.migrations VALUES (129, '2026_04_20_100003_create_refund_requests_table', 1);
INSERT INTO public.migrations VALUES (130, '2026_04_21_120000_backfill_products_refund_policy_days', 1);


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.order_items VALUES (1, 1, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', NULL, NULL, 2.50, 0, '2026-04-30 18:03:59', '2026-04-30 18:03:59');
INSERT INTO public.order_items VALUES (2, 2, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', NULL, NULL, 2.50, 0, '2026-04-30 18:21:34', '2026-04-30 18:21:34');


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.orders VALUES (1, 4, 5, 'completed', 2.50, 'contato@winfy.com.br', 'mercadopago', '157148841606', '2026-04-30 18:03:59', '2026-04-30 18:05:04', '00316765376', '55', NULL, '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, false, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"checkout_payment_method":"pix"}', false, 'pix', 'MQDNUDLMLT');
INSERT INTO public.orders VALUES (2, 4, 6, 'completed', 2.50, 'jaderbrandao@winfy.com.br', 'mercadopago', '156388971233', '2026-04-30 18:21:34', '2026-04-30 18:22:06', '00316765376', '55', NULL, '2804:13c:60b:d00:d98e:ed68:c0be:ee7', NULL, NULL, NULL, NULL, false, '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"checkout_payment_method":"pix"}', false, 'pix', 'UKQIJR4TPC');


--
-- Data for Name: panel_notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: panel_push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: platform_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.platform_audit_logs VALUES (1, NULL, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 14:41:20', '2026-04-30 14:41:20');
INSERT INTO public.platform_audit_logs VALUES (2, NULL, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:02:44', '2026-04-30 15:02:44');
INSERT INTO public.platform_audit_logs VALUES (3, NULL, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:02:56', '2026-04-30 15:02:56');
INSERT INTO public.platform_audit_logs VALUES (4, NULL, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:03:03', '2026-04-30 15:03:03');
INSERT INTO public.platform_audit_logs VALUES (5, NULL, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:03:23', '2026-04-30 15:03:23');
INSERT INTO public.platform_audit_logs VALUES (6, NULL, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:03:38', '2026-04-30 15:03:38');
INSERT INTO public.platform_audit_logs VALUES (7, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:31:33', '2026-04-30 15:31:33');
INSERT INTO public.platform_audit_logs VALUES (8, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:33:30', '2026-04-30 15:33:30');
INSERT INTO public.platform_audit_logs VALUES (9, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:33:40', '2026-04-30 15:33:40');
INSERT INTO public.platform_audit_logs VALUES (10, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:34:16', '2026-04-30 15:34:16');
INSERT INTO public.platform_audit_logs VALUES (11, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 15:34:21', '2026-04-30 15:34:21');
INSERT INTO public.platform_audit_logs VALUES (12, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:21:03', '2026-04-30 17:21:03');
INSERT INTO public.platform_audit_logs VALUES (13, 3, 'platform.gateway.update', '{"gateway_slug":"mercadopago"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:23:54', '2026-04-30 17:23:54');
INSERT INTO public.platform_audit_logs VALUES (14, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:28:43', '2026-04-30 17:28:43');
INSERT INTO public.platform_audit_logs VALUES (15, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:28:59', '2026-04-30 17:28:59');
INSERT INTO public.platform_audit_logs VALUES (16, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:35:17', '2026-04-30 17:35:17');
INSERT INTO public.platform_audit_logs VALUES (17, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:35:27', '2026-04-30 17:35:27');
INSERT INTO public.platform_audit_logs VALUES (18, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:35:56', '2026-04-30 17:35:56');
INSERT INTO public.platform_audit_logs VALUES (19, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:49:57', '2026-04-30 17:49:57');
INSERT INTO public.platform_audit_logs VALUES (20, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:51:36', '2026-04-30 17:51:36');
INSERT INTO public.platform_audit_logs VALUES (21, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:24:29', '2026-04-30 18:24:29');
INSERT INTO public.platform_audit_logs VALUES (22, 3, 'platform.financial.fees_updated', '{"rules":{"pix":{"percent":1.4899999999999999911182158029987476766109466552734375,"fixed":0},"card":{"percent":5.980000000000000426325641456060111522674560546875,"fixed":0},"boleto":{"percent":0,"fixed":4.4900000000000002131628207280300557613372802734375},"withdrawal":{"percent":0,"fixed":1.9899999999999999911182158029987476766109466552734375}}}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:27:40', '2026-04-30 18:27:40');
INSERT INTO public.platform_audit_logs VALUES (23, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:28:30', '2026-04-30 18:28:30');
INSERT INTO public.platform_audit_logs VALUES (24, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:33:51', '2026-04-30 18:33:51');
INSERT INTO public.platform_audit_logs VALUES (25, 3, 'platform.kyc.approved', '{"merchant_id":4}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:34:17', '2026-04-30 18:34:17');
INSERT INTO public.platform_audit_logs VALUES (31, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:c132:f9fe:5f22:258c', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-01 14:43:50', '2026-05-01 14:43:50');
INSERT INTO public.platform_audit_logs VALUES (33, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:20:00', '2026-06-06 01:20:00');
INSERT INTO public.platform_audit_logs VALUES (34, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:24:06', '2026-06-06 01:24:06');
INSERT INTO public.platform_audit_logs VALUES (26, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:34:27', '2026-04-30 18:34:27');
INSERT INTO public.platform_audit_logs VALUES (27, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:41:47', '2026-04-30 18:41:47');
INSERT INTO public.platform_audit_logs VALUES (28, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:43:53', '2026-04-30 18:43:53');
INSERT INTO public.platform_audit_logs VALUES (29, 3, 'platform.auth.login', '{"email":"jader.development@gmail.com"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:49:38', '2026-04-30 18:49:38');
INSERT INTO public.platform_audit_logs VALUES (30, 3, 'platform.auth.logout', '[]', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:52:27', '2026-04-30 18:52:27');
INSERT INTO public.platform_audit_logs VALUES (32, 3, 'platform.auth.logout', '[]', '186.244.137.96', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-01 14:44:44', '2026-05-01 14:44:44');


--
-- Data for Name: platform_languages; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.platform_languages VALUES (1, 'pt_BR', 'Português (Brasil)', true, true, 1, '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_languages VALUES (2, 'es', 'ES', true, false, 2, '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_languages VALUES (3, 'en', 'EN', true, false, 2, '2026-04-30 14:12:04', '2026-04-30 14:12:04');


--
-- Data for Name: platform_translations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.platform_translations VALUES (1, 'seller', 'header.language', 'pt_BR', 'Idioma', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (2, 'seller', 'header.notifications', 'pt_BR', 'Notificações', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (3, 'seller', 'sidebar.dashboard', 'pt_BR', 'Dashboard', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (4, 'seller', 'sidebar.sales', 'pt_BR', 'Vendas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (5, 'seller', 'sidebar.products', 'pt_BR', 'Produtos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (6, 'seller', 'sidebar.affiliate_showcase', 'pt_BR', 'Vitrine', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (7, 'seller', 'sidebar.coupons', 'pt_BR', 'Cupons', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (8, 'seller', 'sidebar.students', 'pt_BR', 'Alunos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (9, 'seller', 'sidebar.affiliates_menu', 'pt_BR', 'Afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (10, 'seller', 'affiliates.my_affiliates_title', 'pt_BR', 'Meus Afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (11, 'seller', 'affiliates.my_affiliates_subtitle', 'pt_BR', 'Gerencie solicitações e afiliações de todos os seus produtos.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (12, 'seller', 'affiliates.filter_status', 'pt_BR', 'Situação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (13, 'seller', 'affiliates.filter_all', 'pt_BR', 'Todos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (14, 'seller', 'affiliates.filter_pending', 'pt_BR', 'Pendentes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (15, 'seller', 'affiliates.filter_active', 'pt_BR', 'Ativos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (16, 'seller', 'affiliates.filter_blocked', 'pt_BR', 'Bloqueados (recusados/revogados)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (17, 'seller', 'affiliates.filter_rejected', 'pt_BR', 'Recusados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (18, 'seller', 'affiliates.filter_revoked', 'pt_BR', 'Revogados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (19, 'seller', 'affiliates.filter_product', 'pt_BR', 'Produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (20, 'seller', 'affiliates.all_products', 'pt_BR', 'Todos os produtos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (21, 'seller', 'affiliates.search_affiliate', 'pt_BR', 'Buscar afiliado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (22, 'seller', 'affiliates.search_placeholder', 'pt_BR', 'Nome ou e-mail', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (23, 'seller', 'affiliates.col_affiliate', 'pt_BR', 'Afiliado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (24, 'seller', 'affiliates.col_product', 'pt_BR', 'Produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (25, 'seller', 'affiliates.col_status', 'pt_BR', 'Situação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (26, 'seller', 'affiliates.col_actions', 'pt_BR', 'Ações', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (27, 'seller', 'affiliates.status_approved', 'pt_BR', 'Ativo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (28, 'seller', 'affiliates.status_pending', 'pt_BR', 'Pendente', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (29, 'seller', 'affiliates.status_rejected', 'pt_BR', 'Recusado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (30, 'seller', 'affiliates.status_revoked', 'pt_BR', 'Revogado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (31, 'seller', 'affiliates.action_approve', 'pt_BR', 'Aprovar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (32, 'seller', 'affiliates.action_reject', 'pt_BR', 'Recusar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (33, 'seller', 'affiliates.action_revoke', 'pt_BR', 'Bloquear / revogar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (34, 'seller', 'affiliates.empty', 'pt_BR', 'Nenhuma afiliação encontrada com os filtros atuais.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (35, 'seller', 'sidebar.reports', 'pt_BR', 'Relatórios', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (36, 'seller', 'sidebar.integrations', 'pt_BR', 'Integrações', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (37, 'seller', 'sidebar.team', 'pt_BR', 'Equipe', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (38, 'seller', 'sidebar.finance', 'pt_BR', 'Financeiro', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (39, 'seller', 'dashboard.title', 'pt_BR', 'Dashboard', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (40, 'seller', 'dashboard.subtitle', 'pt_BR', 'Visão geral de desempenho, vendas e métricas do período.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (41, 'seller', 'dashboard.period', 'pt_BR', 'Período', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (42, 'seller', 'dashboard.hide_values', 'pt_BR', 'Ocultar valores', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (43, 'seller', 'dashboard.show_values', 'pt_BR', 'Mostrar valores', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (44, 'seller', 'dashboard.total_sales', 'pt_BR', 'Vendas totais', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (45, 'seller', 'dashboard.pending_sales', 'pt_BR', 'Vendas pendentes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (46, 'seller', 'dashboard.sales_count', 'pt_BR', 'Quantidade de vendas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (47, 'seller', 'dashboard.avg_ticket', 'pt_BR', 'Ticket médio', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (48, 'seller', 'dashboard.payment_methods', 'pt_BR', 'Formas de pagamento', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (49, 'seller', 'dashboard.no_payments', 'pt_BR', 'Nenhum pagamento no período', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (50, 'seller', 'dashboard.conversion_rate', 'pt_BR', 'Taxa de conversão geral', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (51, 'seller', 'dashboard.cart_abandonment', 'pt_BR', 'Abandono de carrinho', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (52, 'seller', 'dashboard.refunds', 'pt_BR', 'Reembolso', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (53, 'seller', 'dashboard.orders_count', 'pt_BR', 'pedido(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (54, 'seller', 'dashboard.products', 'pt_BR', 'Produtos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (55, 'seller', 'dashboard.sales_performance', 'pt_BR', 'Desempenho de vendas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (56, 'seller', 'dashboard.no_sales_data', 'pt_BR', 'Nenhum dado de vendas no período', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (57, 'seller', 'period.today', 'pt_BR', 'Hoje', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (58, 'seller', 'period.yesterday', 'pt_BR', 'Ontem', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (59, 'seller', 'period.7days', 'pt_BR', '7 dias', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (60, 'seller', 'period.month', 'pt_BR', 'Mês', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (61, 'seller', 'period.year', 'pt_BR', 'Ano', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (62, 'seller', 'period.total', 'pt_BR', 'Total', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (63, 'seller', 'sales.tab_sales', 'pt_BR', 'Vendas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (64, 'seller', 'sales.tab_subscriptions', 'pt_BR', 'Assinaturas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (65, 'seller', 'products.tab_products', 'pt_BR', 'Produtos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (66, 'seller', 'products.tab_coupons', 'pt_BR', 'Cupons', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (67, 'seller', 'products.tab_students', 'pt_BR', 'Alunos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (68, 'seller', 'products.tab_coproduction', 'pt_BR', 'Co-produção', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (69, 'seller', 'products.tab_showcase', 'pt_BR', 'Vitrine', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (70, 'seller', 'products.tab_affiliates', 'pt_BR', 'Afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (71, 'seller', 'products.affiliates_page_title', 'pt_BR', 'Afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (72, 'seller', 'products.affiliates_page_subtitle', 'pt_BR', 'Produtos em que você é afiliado aprovado. Use seu link exclusivo e configure seus pixels de conversão.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (73, 'seller', 'products.affiliate_badge', 'pt_BR', 'Afiliado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (74, 'seller', 'products.affiliate_status_pending', 'pt_BR', 'Pendente', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (75, 'seller', 'products.affiliate_status_approved', 'pt_BR', 'Aprovado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (76, 'seller', 'products.affiliate_panel', 'pt_BR', 'Painel do afiliado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (146, 'seller', 'team.no_roles', 'pt_BR', 'Nenhum cargo criado.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (77, 'seller', 'products.affiliate_open_checkout', 'pt_BR', 'Abrir checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (78, 'seller', 'products.affiliate_no_link', 'pt_BR', 'Link indisponível (defina o checkout do produto ou aguarde aprovação).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (79, 'seller', 'products.affiliates_empty', 'pt_BR', 'Nenhum produto como afiliado ainda.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (80, 'seller', 'products.affiliate_panel_title', 'pt_BR', 'Painel do afiliado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (81, 'seller', 'products.affiliate_panel_subtitle', 'pt_BR', 'Seu link de afiliação e pixels usados nas vendas pelo seu ref.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (82, 'seller', 'products.affiliate_link_section', 'pt_BR', 'Link de afiliação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (83, 'seller', 'products.affiliate_copy_link', 'pt_BR', 'Copiar link', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (84, 'seller', 'products.affiliate_pix_hint', 'pt_BR', 'Configure sua chave PIX para receber comissões em Financeiro.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (85, 'seller', 'products.affiliate_pix_finance_link', 'pt_BR', 'Configurar PIX de saque', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (86, 'seller', 'products.affiliate_pixels_only_hint', 'pt_BR', 'Quando a venda vier pelo seu link (?ref=), apenas estes pixels serão usados no checkout e páginas de obrigado — não os do produtor.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (87, 'seller', 'products.coproduction_page_title', 'pt_BR', 'Co-produção', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (88, 'seller', 'products.coproduction_page_subtitle', 'pt_BR', 'Produtos em que você é co-produtor e convites aguardando sua aprovação.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (89, 'seller', 'products.coproduction_section_pending', 'pt_BR', 'Pendentes de aprovação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (90, 'seller', 'products.coproduction_section_active', 'pt_BR', 'Co-produções ativas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (91, 'seller', 'products.coproduction_by', 'pt_BR', 'Produtor', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (92, 'seller', 'products.coproduction_accept', 'pt_BR', 'Aceitar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (93, 'seller', 'products.coproduction_details', 'pt_BR', 'Detalhes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (94, 'seller', 'products.coproduction_empty_pending', 'pt_BR', 'Nenhum convite pendente.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (95, 'seller', 'products.coproduction_empty_active', 'pt_BR', 'Nenhuma co-produção ativa ainda.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (96, 'seller', 'products.coproduction_until', 'pt_BR', 'até', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (97, 'seller', 'products.coproduction_view_checkout', 'pt_BR', 'Ver checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (98, 'seller', 'integrations.title', 'pt_BR', 'Apps', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (99, 'seller', 'integrations.subtitle', 'pt_BR', 'Conecte sua plataforma com sistemas externos via webhooks e outras integrações. Os gateways de pagamento são configurados no painel da plataforma (operador).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (100, 'seller', 'integrations.webhook.description', 'pt_BR', 'Envie eventos da plataforma para sua URL. Configure quais eventos deseja receber e use Bearer token para autenticação.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (101, 'seller', 'integrations.utmify.description', 'pt_BR', 'Rastreie vendas e envie eventos para a UTMfy. Requer apenas a chave de API.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (102, 'seller', 'integrations.spedy.description', 'pt_BR', 'Emissão automática de notas fiscais. Envie vendas para a Spedy e emita NF-e/NFS-e.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (103, 'seller', 'integrations.cademi.description', 'pt_BR', 'Área de membros externa. Após a compra, sincronize o aluno e conceda acesso na Cademí.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (104, 'seller', 'users.title', 'pt_BR', 'Usuários', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (105, 'seller', 'users.subtitle', 'pt_BR', 'Conta Master e infoprodutores da plataforma.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (106, 'seller', 'users.tab_infoproducers', 'pt_BR', 'Infoprodutores', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (107, 'seller', 'users.tab_team', 'pt_BR', 'Equipe', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (108, 'seller', 'users.new_infoproducer', 'pt_BR', 'Novo infoprodutor', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (109, 'seller', 'users.edit_user', 'pt_BR', 'Editar usuário', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (110, 'seller', 'users.delete_user', 'pt_BR', 'Excluir usuário', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (111, 'seller', 'users.empty', 'pt_BR', 'Nenhum usuário cadastrado.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (112, 'seller', 'finance.request_withdrawal', 'pt_BR', 'Solicitar saque', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (113, 'seller', 'finance.available_balance', 'pt_BR', 'Saldo disponível', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (114, 'seller', 'finance.ready_for_withdrawal', 'pt_BR', 'Pronto para saque', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (115, 'seller', 'finance.pending_receive', 'pt_BR', 'A receber', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (116, 'seller', 'finance.settling', 'pt_BR', 'Em liquidação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (117, 'seller', 'finance.by_method', 'pt_BR', 'Por método', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (118, 'seller', 'finance.my_fees_and_payout', 'pt_BR', 'Minhas taxas e prazo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (119, 'seller', 'finance.by_payment_method', 'pt_BR', 'Por método de pagamento', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (120, 'seller', 'finance.fee', 'pt_BR', 'Taxa', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (121, 'seller', 'finance.payout_deadline', 'pt_BR', 'Prazo de saque', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (122, 'seller', 'finance.statement', 'pt_BR', 'Extrato', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (123, 'seller', 'finance.bank_details', 'pt_BR', 'Dados bancários', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (124, 'seller', 'finance.no_withdrawals', 'pt_BR', 'Nenhum saque ainda', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (125, 'seller', 'finance.no_withdrawals_hint', 'pt_BR', 'Seus saques solicitados aparecerão aqui.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (126, 'seller', 'finance.withdrawals', 'pt_BR', 'Saques', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (127, 'seller', 'common.view', 'pt_BR', 'Ver', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (128, 'seller', 'common.hide', 'pt_BR', 'Ocultar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (129, 'seller', 'common.close', 'pt_BR', 'Fechar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (130, 'seller', 'common.save', 'pt_BR', 'Salvar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (131, 'seller', 'common.cancel', 'pt_BR', 'Cancelar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (132, 'seller', 'common.name', 'pt_BR', 'Nome', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (133, 'seller', 'common.email', 'pt_BR', 'E-mail', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (134, 'seller', 'common.password', 'pt_BR', 'Senha', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (135, 'seller', 'common.confirm_password', 'pt_BR', 'Confirmar senha', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (136, 'seller', 'team.roles', 'pt_BR', 'Cargos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (137, 'seller', 'team.members', 'pt_BR', 'Membros', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (138, 'seller', 'team.logs', 'pt_BR', 'Logs', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (139, 'seller', 'team.new_role', 'pt_BR', 'Novo cargo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (140, 'seller', 'team.new_member', 'pt_BR', 'Novo membro', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (141, 'seller', 'team.clear_logs', 'pt_BR', 'Limpar logs', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (142, 'seller', 'team.permissions', 'pt_BR', 'Permissões', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (143, 'seller', 'team.products_count', 'pt_BR', 'produto(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (144, 'seller', 'team.edit_role', 'pt_BR', 'Editar cargo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (145, 'seller', 'team.remove_role', 'pt_BR', 'Remover cargo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (147, 'seller', 'team.no_role', 'pt_BR', 'Sem cargo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (148, 'seller', 'team.edit_member', 'pt_BR', 'Editar membro', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (149, 'seller', 'team.remove_member', 'pt_BR', 'Remover membro', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (150, 'seller', 'team.no_members', 'pt_BR', 'Nenhum membro cadastrado.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (151, 'seller', 'team.when', 'pt_BR', 'Quando', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (152, 'seller', 'team.user', 'pt_BR', 'Usuário', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (153, 'seller', 'team.action', 'pt_BR', 'Ação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (154, 'seller', 'team.no_logs', 'pt_BR', 'Nenhum log registrado ainda.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (155, 'seller', 'team.role_name', 'pt_BR', 'Nome do cargo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (156, 'seller', 'team.allowed_products', 'pt_BR', 'Produtos permitidos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (157, 'seller', 'team.allowed_products_hint', 'pt_BR', 'Afeta todos os módulos por produto (Dashboard, Vendas, Produtos, etc.).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (158, 'seller', 'team.role', 'pt_BR', 'Cargo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (159, 'seller', 'team.new_password_optional', 'pt_BR', 'Nova senha (opcional)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (160, 'seller', 'team.send_access_email', 'pt_BR', 'Enviar e-mail de acesso com login e senha', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (161, 'seller', 'team.send_access_email_hint', 'pt_BR', 'O e-mail será enviado para o endereço informado acima.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (162, 'seller', 'team.confirm_delete_role', 'pt_BR', 'Remover o cargo "{name}"?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (163, 'seller', 'team.confirm_delete_member', 'pt_BR', 'Remover "{name}" da equipe?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (164, 'seller', 'team.confirm_clear_logs', 'pt_BR', 'Limpar todos os logs de auditoria deste tenant?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (165, 'seller', 'team.permission_email_marketing', 'pt_BR', 'E-mail Marketing', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (166, 'seller', 'team.permission_api_payments', 'pt_BR', 'API de Pagamentos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (167, 'seller', 'team.permission_settings', 'pt_BR', 'Configurações', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (168, 'seller', 'team.permission_manage_team', 'pt_BR', 'Gerenciar equipe', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (169, 'seller', 'products.edit.custom_script', 'pt_BR', 'Script personalizado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (170, 'seller', 'products.edit.tab_general', 'pt_BR', 'Geral', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (171, 'seller', 'products.edit.tab_settings', 'pt_BR', 'Configurações', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (172, 'seller', 'products.edit.tab_email', 'pt_BR', 'E-mail', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (173, 'seller', 'products.edit.tab_links', 'pt_BR', 'Links', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (174, 'seller', 'products.edit.tab_coproduction', 'pt_BR', 'Co-produção', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (175, 'seller', 'products.edit.coproduction_title', 'pt_BR', 'Convidar co-produtor', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (176, 'seller', 'products.edit.coproduction_help', 'pt_BR', 'O convidado deve ser infoprodutor. Ele receberá um e-mail para aceitar. Comissões são sobre o valor bruto da venda; taxas da plataforma aplicam-se na carteira de cada parte.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (177, 'seller', 'products.edit.tab_affiliates', 'pt_BR', 'Afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (178, 'seller', 'products.edit.affiliate_title', 'pt_BR', 'Programa de afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (179, 'seller', 'products.edit.affiliate_help', 'pt_BR', 'Comissões sobre o valor bruto da venda; taxas da plataforma aplicam na carteira de cada parte. Soma co-produção (vendas por afiliado) + afiliado não pode exceder 100%.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (180, 'seller', 'products.edit.affiliate_enable', 'pt_BR', 'Ativar afiliação para este produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (181, 'seller', 'products.edit.affiliate_commission', 'pt_BR', 'Comissão do afiliado (%)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (182, 'seller', 'products.edit.affiliate_manual', 'pt_BR', 'Aprovar afiliações manualmente', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (183, 'seller', 'products.edit.affiliate_showcase', 'pt_BR', 'Mostrar na vitrine', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (184, 'seller', 'products.edit.affiliate_page_url', 'pt_BR', 'Link da página de afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (185, 'seller', 'products.edit.affiliate_support_email', 'pt_BR', 'E-mail de suporte', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (186, 'seller', 'products.edit.affiliate_showcase_desc', 'pt_BR', 'Descrição (vitrine)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (187, 'seller', 'products.edit.affiliate_checkout_hint', 'pt_BR', 'Link base do checkout (adicione ?ref= após aprovar um afiliado)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (188, 'seller', 'products.edit.affiliate_enrollments', 'pt_BR', 'Afiliados e solicitações', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (189, 'seller', 'products.edit.affiliate_enrollments_hint', 'pt_BR', 'Todos os registros deste produto: pendentes, aprovados, recusados e revogados.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (190, 'seller', 'products.edit.affiliate_status_pending', 'pt_BR', 'Pendente', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (191, 'seller', 'products.edit.affiliate_status_approved', 'pt_BR', 'Aprovado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (192, 'seller', 'products.edit.affiliate_status_rejected', 'pt_BR', 'Recusado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (193, 'seller', 'products.edit.affiliate_status_revoked', 'pt_BR', 'Revogado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (194, 'seller', 'products.edit.affiliate_user_fallback', 'pt_BR', 'Usuário :id', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (195, 'seller', 'products.edit.affiliate_copy_link', 'pt_BR', 'Copiar link', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (196, 'seller', 'products.edit.affiliate_approve', 'pt_BR', 'Aprovar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (197, 'seller', 'products.edit.affiliate_reject', 'pt_BR', 'Recusar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (198, 'seller', 'products.edit.affiliate_revoke', 'pt_BR', 'Revogar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (199, 'seller', 'products.edit.affiliate_empty', 'pt_BR', 'Nenhum afiliado ou solicitação ainda.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (200, 'seller', 'products.showcase.title', 'pt_BR', 'Vitrine', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (201, 'seller', 'products.showcase.subtitle', 'pt_BR', 'Produtos abertos a afiliados. Ordene por mais vendidos (quentes) ou explore por categoria.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (202, 'seller', 'products.showcase.your_product_badge', 'pt_BR', 'Seu produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (203, 'seller', 'products.showcase.own_product_hint', 'pt_BR', 'Este é o seu produto. Use a edição para gerenciar afiliados.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (204, 'seller', 'products.showcase.edit_affiliate_settings', 'pt_BR', 'Abrir configurações de afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (205, 'seller', 'products.showcase.search', 'pt_BR', 'Pesquisar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (206, 'seller', 'products.showcase.category_all', 'pt_BR', 'Todas as categorias', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (207, 'seller', 'products.showcase.sort_hot', 'pt_BR', 'Mais quentes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (208, 'seller', 'products.showcase.sort_name', 'pt_BR', 'Nome', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (209, 'seller', 'products.showcase.sort_price_asc', 'pt_BR', 'Menor preço', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (210, 'seller', 'products.showcase.sort_price_desc', 'pt_BR', 'Maior preço', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (211, 'seller', 'products.showcase.section_hot', 'pt_BR', 'Mais quentes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (274, 'seller', 'products.interval.weekly', 'pt_BR', 'Semanal', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (212, 'seller', 'products.showcase.you_receive', 'pt_BR', 'Você recebe até', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (213, 'seller', 'products.showcase.empty', 'pt_BR', 'Nenhum produto na vitrine com estes filtros.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (214, 'seller', 'products.showcase.affiliate_page', 'pt_BR', 'Página de afiliados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (215, 'seller', 'products.showcase.support', 'pt_BR', 'Suporte', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (216, 'seller', 'products.showcase.order_bump', 'pt_BR', 'Inclui order bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (217, 'seller', 'products.showcase.your_link', 'pt_BR', 'Seu link de afiliação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (218, 'seller', 'products.showcase.request', 'pt_BR', 'Solicitar afiliação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (219, 'seller', 'products.showcase.pending', 'pt_BR', 'Aguardando aprovação do produtor.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (220, 'seller', 'common.copy', 'pt_BR', 'Copiar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (221, 'seller', 'products.edit.tab_order_bump', 'pt_BR', 'Order Bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (222, 'seller', 'products.edit.tab_upsell_downsell', 'pt_BR', 'Upsell / Downsell', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (223, 'seller', 'products.edit.tab_checkout', 'pt_BR', 'Checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (224, 'seller', 'products.edit.tab_member_builder', 'pt_BR', 'Member Builder', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (225, 'seller', 'products.edit.basic_info', 'pt_BR', 'Informações básicas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (226, 'seller', 'products.edit.basic_info_hint', 'pt_BR', 'Nome, identificador e imagem do produto.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (227, 'seller', 'products.edit.product_name', 'pt_BR', 'Nome do produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (228, 'seller', 'products.edit.slug_url', 'pt_BR', 'Slug (URL)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (229, 'seller', 'products.edit.slug_hint', 'pt_BR', 'Usado em URLs e área de membros. Apenas letras minúsculas, números e hífens.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (230, 'seller', 'products.edit.product_image', 'pt_BR', 'Imagem do produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (231, 'seller', 'products.edit.change_image', 'pt_BR', 'Trocar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (232, 'seller', 'products.edit.pricing_billing', 'pt_BR', 'Preço e cobrança', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (233, 'seller', 'products.edit.pricing_billing_hint', 'pt_BR', 'Defina como o produto será cobrado e o valor base.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (234, 'seller', 'products.edit.base_price_brl', 'pt_BR', 'Preço base (BRL)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (235, 'seller', 'products.edit.recurrence', 'pt_BR', 'Recorrência', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (236, 'seller', 'products.edit.extra_offers', 'pt_BR', 'Ofertas extras', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (237, 'seller', 'products.edit.subscription_plans', 'pt_BR', 'Planos de assinatura', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (238, 'seller', 'products.edit.extra_offers_hint', 'pt_BR', 'Múltiplas ofertas (preços). Cada uma tem seu próprio link de checkout.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (239, 'seller', 'products.edit.subscription_plans_hint', 'pt_BR', 'Cadastre os planos (preço e periodicidade). Cada plano tem seu próprio link.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (240, 'seller', 'products.edit.no_offer', 'pt_BR', 'Nenhuma oferta. Adicione abaixo ou use apenas o preço base.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (241, 'seller', 'products.edit.edit_offer', 'pt_BR', 'Editar oferta', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (242, 'seller', 'products.edit.new_offer', 'pt_BR', 'Nova oferta', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (243, 'seller', 'products.edit.add_offer', 'pt_BR', 'Adicionar oferta', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (244, 'seller', 'products.edit.no_plan', 'pt_BR', 'Nenhum plano. Adicione abaixo.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (245, 'seller', 'products.edit.edit_plan', 'pt_BR', 'Editar plano', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (246, 'seller', 'products.edit.new_plan', 'pt_BR', 'Novo plano', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (247, 'seller', 'products.edit.add_plan', 'pt_BR', 'Adicionar plano', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (248, 'seller', 'products.edit.save_changes', 'pt_BR', 'Salvar alterações', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (249, 'seller', 'products.edit.conversion_pixels', 'pt_BR', 'Pixels de conversão', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (250, 'seller', 'products.edit.conversion_pixels_hint', 'pt_BR', 'Configure pixels para rastrear conversões no checkout, upsell e downsell.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (251, 'seller', 'products.edit.add_pixel', 'pt_BR', 'Adicionar pixel', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (252, 'seller', 'products.edit.no_pixels', 'pt_BR', 'Nenhum pixel. Clique em «Adicionar pixel» ou desative a integração.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (253, 'seller', 'products.edit.add_conversion', 'pt_BR', 'Adicionar conversão', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (254, 'seller', 'products.edit.no_conversion', 'pt_BR', 'Nenhuma conversão. Clique em «Adicionar conversão» ou desative a integração.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (255, 'seller', 'products.edit.add_property', 'pt_BR', 'Adicionar propriedade', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (256, 'seller', 'products.edit.no_property', 'pt_BR', 'Nenhuma propriedade. Clique em «Adicionar propriedade» ou desative a integração.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (257, 'seller', 'products.edit.custom_scripts', 'pt_BR', 'Scripts personalizados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (258, 'seller', 'products.edit.no_custom_script', 'pt_BR', 'Nenhum script adicionado. Clique em "Adicionar pixel" para incluir um código de rastreamento personalizado.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (259, 'seller', 'products.edit.access_email_template', 'pt_BR', 'Template do e-mail de acesso', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (260, 'seller', 'products.edit.access_email_template_hint', 'pt_BR', 'Personalize o e-mail enviado ao cliente após a compra. Use os placeholders; eles serão substituídos pelos dados reais no envio.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (261, 'seller', 'products.edit.email_logo', 'pt_BR', 'Logo do e-mail', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (262, 'seller', 'products.edit.click_to_change', 'pt_BR', 'Clique para trocar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (263, 'seller', 'products.edit.click_to_upload', 'pt_BR', 'Clique para enviar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (264, 'seller', 'products.edit.sender_name_optional', 'pt_BR', 'Nome do remetente (opcional)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (265, 'seller', 'products.edit.sender_name_hint', 'pt_BR', 'Se vazio, usa o nome das Configurações gerais.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (266, 'seller', 'products.edit.email_subject', 'pt_BR', 'Assunto do e-mail', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (267, 'seller', 'products.edit.email_body_html', 'pt_BR', 'Corpo do e-mail (HTML)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (268, 'seller', 'products.edit.email_preview', 'pt_BR', 'Preview do e-mail', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (269, 'seller', 'products.edit.email_preview_hint', 'pt_BR', 'Como o e-mail será exibido para o cliente.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (270, 'seller', 'products.edit.order_bump_hint', 'pt_BR', 'Ofereça outros produtos no checkout para o cliente comprar junto. Escolha o produto, personalize título, descrição e preço.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (271, 'seller', 'products.edit.add_order_bump', 'pt_BR', 'Adicionar order bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (272, 'seller', 'products.edit.no_order_bump', 'pt_BR', 'Nenhum order bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (273, 'seller', 'products.edit.no_order_bump_hint', 'pt_BR', 'Adicione produtos que aparecerão no checkout como oferta especial para comprar junto.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (275, 'seller', 'products.interval.monthly', 'pt_BR', 'Mensal', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (276, 'seller', 'products.interval.quarterly', 'pt_BR', 'Trimestral', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (277, 'seller', 'products.interval.semi_annual', 'pt_BR', 'Semestral', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (278, 'seller', 'products.interval.annual', 'pt_BR', 'Anual', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (279, 'seller', 'products.interval.lifetime', 'pt_BR', 'Vitalício', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (280, 'seller', 'checkout_builder.edit_checkout', 'pt_BR', 'Editar checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (281, 'seller', 'checkout_builder.tab_general', 'pt_BR', 'Geral', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (282, 'seller', 'checkout_builder.tab_features', 'pt_BR', 'Recursos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (283, 'seller', 'checkout_builder.tab_template', 'pt_BR', 'Template', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (284, 'seller', 'checkout_builder.tab_social', 'pt_BR', 'Social', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (285, 'seller', 'checkout_builder.price_discount', 'pt_BR', 'Preço / Desconto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (286, 'seller', 'checkout_builder.form_fields', 'pt_BR', 'Campos do formulário', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (287, 'seller', 'sales.subtitle', 'pt_BR', 'Acompanhe pedidos, status de pagamento e desempenho comercial.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (288, 'seller', 'products.subtitle', 'pt_BR', 'Gerencie seus produtos, ofertas e acessos de checkout.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (289, 'seller', 'reports.subtitle', 'pt_BR', 'Analise resultados, receita e indicadores do seu negócio.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (290, 'seller', 'finance.subtitle', 'pt_BR', 'Saldos, extrato e dados para recebimento.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (291, 'seller', 'team.title', 'pt_BR', 'Usuários', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (292, 'seller', 'team.subtitle', 'pt_BR', 'Gerencie equipe e permissões.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (293, 'seller', 'settings.languages.tab', 'pt_BR', 'Idiomas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (294, 'seller', 'settings.languages.title', 'pt_BR', 'Idiomas da plataforma', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (295, 'seller', 'settings.languages.subtitle', 'pt_BR', 'Gerencie os idiomas e traduções do painel do infoprodutor.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (296, 'seller', 'settings.languages.add', 'pt_BR', 'Adicionar idioma', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (297, 'seller', 'settings.languages.default', 'pt_BR', 'Padrão', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (298, 'seller', 'settings.languages.active', 'pt_BR', 'Ativo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (299, 'seller', 'settings.languages.search', 'pt_BR', 'Buscar chave de tradução...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (300, 'seller', 'settings.languages.save', 'pt_BR', 'Salvar traduções', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (301, 'seller', 'settings.languages.import_missing', 'pt_BR', 'Importar chaves faltantes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (302, 'seller', 'common.image', 'pt_BR', 'Imagem', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (303, 'seller', 'common.description', 'pt_BR', 'Descrição', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (304, 'seller', 'common.active', 'pt_BR', 'Ativo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (305, 'seller', 'common.inactive', 'pt_BR', 'Inativo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (306, 'seller', 'common.edit', 'pt_BR', 'Editar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (307, 'seller', 'common.delete', 'pt_BR', 'Excluir', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (308, 'seller', 'common.loading', 'pt_BR', 'Carregando...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (309, 'seller', 'common.error', 'pt_BR', 'Erro', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (310, 'seller', 'common.send', 'pt_BR', 'Enviar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (311, 'seller', 'common.sending', 'pt_BR', 'Enviando...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (312, 'seller', 'common.saving', 'pt_BR', 'Salvando...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (313, 'seller', 'common.back', 'pt_BR', 'Voltar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (314, 'seller', 'common.open_menu', 'pt_BR', 'Abrir menu', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (315, 'seller', 'common.pagination', 'pt_BR', 'Paginação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (316, 'seller', 'common.date', 'pt_BR', 'Data', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (317, 'seller', 'common.from', 'pt_BR', 'De', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (318, 'seller', 'common.to', 'pt_BR', 'Até', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (319, 'seller', 'common.optional', 'pt_BR', 'opcional', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (320, 'seller', 'common.test', 'pt_BR', 'Testar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (321, 'seller', 'common.delete_question', 'pt_BR', 'Excluir?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (322, 'seller', 'common.deleting', 'pt_BR', 'Excluindo...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (323, 'seller', 'common.coming_soon', 'pt_BR', 'Em breve', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (324, 'seller', 'common.back_to_list', 'pt_BR', 'Voltar à lista', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (325, 'seller', 'common.leave_blank_keep', 'pt_BR', 'Deixe em branco para manter', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (326, 'seller', 'common.leave_blank_keep_current', 'pt_BR', 'Deixe em branco para manter a atual', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (327, 'seller', 'common.all', 'pt_BR', 'Todos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (328, 'seller', 'common.yes', 'pt_BR', 'Sim', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (329, 'seller', 'common.no', 'pt_BR', 'Não', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (330, 'seller', 'common.import', 'pt_BR', 'Importar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (331, 'seller', 'sales.filter.approved', 'pt_BR', 'Aprovadas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (332, 'seller', 'sales.filter.all_female', 'pt_BR', 'Todas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (333, 'seller', 'sales.period.all', 'pt_BR', 'Todo período', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (334, 'seller', 'sales.period.last_7_days', 'pt_BR', 'Últimos 7 dias', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (335, 'seller', 'sales.period.last_30_days', 'pt_BR', 'Últimos 30 dias', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (336, 'seller', 'sales.period.this_month', 'pt_BR', 'Este mês', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (337, 'seller', 'sales.period.last_month', 'pt_BR', 'Mês passado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (338, 'seller', 'sales.period.custom', 'pt_BR', 'Personalizado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (339, 'seller', 'sales.payment_method.all', 'pt_BR', 'Todos métodos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (340, 'seller', 'sales.payment_method.card', 'pt_BR', 'Cartão', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (341, 'seller', 'sales.status', 'pt_BR', 'Status', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (342, 'seller', 'sales.status.all', 'pt_BR', 'Todos status', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (343, 'seller', 'sales.status.paid', 'pt_BR', 'Pago', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (344, 'seller', 'sales.status.pending', 'pt_BR', 'Pendente', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (345, 'seller', 'sales.status.cancelled', 'pt_BR', 'Cancelado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (346, 'seller', 'sales.status.refunded', 'pt_BR', 'Reembolsado', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (347, 'seller', 'sales.metrics.found_sales', 'pt_BR', 'Vendas encontradas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (348, 'seller', 'sales.metrics.net_amount', 'pt_BR', 'Valor líquido', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (349, 'seller', 'sales.metrics.pix_sales', 'pt_BR', 'Vendas no PIX', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (350, 'seller', 'sales.metrics.card_sales', 'pt_BR', 'Vendas no cartão', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (351, 'seller', 'sales.export.csv', 'pt_BR', 'Exportar CSV', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (352, 'seller', 'sales.export.xls', 'pt_BR', 'Exportar XLS', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (353, 'seller', 'sales.search_placeholder', 'pt_BR', 'Buscar por cliente, e-mail, pedido, produto...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (354, 'seller', 'sales.clear_search', 'pt_BR', 'Limpar busca', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (355, 'seller', 'sales.clear_filters', 'pt_BR', 'Limpar filtros', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (356, 'seller', 'sales.products.all', 'pt_BR', 'Todos produtos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (357, 'seller', 'sales.offer', 'pt_BR', 'Oferta', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (358, 'seller', 'sales.offers.all', 'pt_BR', 'Todas ofertas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (359, 'seller', 'sales.method', 'pt_BR', 'Método', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (360, 'seller', 'sales.show_advanced_filters', 'pt_BR', 'Mostrar filtros avançados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (361, 'seller', 'sales.hide_advanced_filters', 'pt_BR', 'Ocultar filtros avançados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (362, 'seller', 'sales.customer', 'pt_BR', 'Cliente', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (363, 'seller', 'sales.empty', 'pt_BR', 'Nenhuma venda encontrada.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (364, 'seller', 'sales.actions', 'pt_BR', 'Ações da venda', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (365, 'seller', 'sales.details', 'pt_BR', 'Detalhes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (366, 'seller', 'sales.resend_purchase_email', 'pt_BR', 'Reenviar e-mail de compra', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (367, 'seller', 'sales.resend_unavailable_pending', 'pt_BR', 'Indisponível para pagamentos pendentes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (368, 'seller', 'sales.toast.email_resent_success', 'pt_BR', 'E-mail de compra reenviado com sucesso.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (369, 'seller', 'sales.toast.email_resent_fail', 'pt_BR', 'Não foi possível reenviar o e-mail.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (370, 'seller', 'sales.toast.email_resent_error', 'pt_BR', 'Erro ao reenviar e-mail. Tente novamente.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (371, 'seller', 'products.create.new_product', 'pt_BR', 'Novo produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (372, 'seller', 'products.create.create_product', 'pt_BR', 'Criar produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (373, 'seller', 'products.create.choose_delivery_type', 'pt_BR', 'Escolha o tipo de entrega do produto.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (374, 'seller', 'products.create.back_to_type', 'pt_BR', '← Voltar ao tipo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (375, 'seller', 'products.create.name_placeholder', 'pt_BR', 'Ex: Curso de Desenvolvimento Web', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (376, 'seller', 'products.create.billing_type', 'pt_BR', 'Tipo de cobrança', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (377, 'seller', 'products.create.description_placeholder', 'pt_BR', 'Breve descrição do produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (378, 'seller', 'products.create.deliverable_link', 'pt_BR', 'Link do entregável', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (379, 'seller', 'products.create.deliverable_link_hint', 'pt_BR', 'Enviado por e-mail após a compra.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (380, 'seller', 'products.create.price_brl', 'pt_BR', 'Preço (BRL)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (381, 'seller', 'products.create.image_hint', 'pt_BR', 'Exibida em formato quadrado (1:1). Recomendado enviar imagem quadrada.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (382, 'seller', 'products.create.active_product', 'pt_BR', 'Produto ativo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (383, 'seller', 'products.empty', 'pt_BR', 'Nenhum produto cadastrado.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (384, 'seller', 'integrations.new', 'pt_BR', 'Nova integração', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (385, 'seller', 'integrations.edit', 'pt_BR', 'Editar integração', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (386, 'seller', 'integrations.empty', 'pt_BR', 'Nenhuma integração configurada. Clique em "Nova integração" para começar.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (387, 'seller', 'integrations.error_name', 'pt_BR', 'Informe o nome da integração.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (388, 'seller', 'integrations.error_api_key', 'pt_BR', 'Informe a chave de API.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (389, 'seller', 'integrations.error_api_key_create', 'pt_BR', 'Informe a chave de API ao criar uma integração.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (390, 'seller', 'integrations.error_save', 'pt_BR', 'Erro ao salvar integração.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (391, 'seller', 'integrations.error_delete', 'pt_BR', 'Erro ao excluir integração.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (392, 'seller', 'integrations.all_products', 'pt_BR', 'Todos os produtos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (393, 'seller', 'integrations.key_configured', 'pt_BR', 'Chave configurada', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (394, 'seller', 'integrations.key_not_configured', 'pt_BR', 'Chave não configurada', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (395, 'seller', 'integrations.integration_name', 'pt_BR', 'Nome da integração', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (396, 'seller', 'integrations.api_key', 'pt_BR', 'Chave de API', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (397, 'seller', 'integrations.api_key_placeholder', 'pt_BR', 'Digite a chave', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (398, 'seller', 'integrations.active_integration', 'pt_BR', 'Integração ativa', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (399, 'seller', 'integrations.assigned_products', 'pt_BR', 'Produtos atribuídos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (400, 'seller', 'integrations.assigned_products_hint', 'pt_BR', 'Selecione os produtos para os quais esta integração enviará eventos. Deixe vazio para todos os produtos.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (401, 'seller', 'integrations.configure_in_product', 'pt_BR', 'Configurar no produto', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (402, 'seller', 'integrations.optional_leave_all', 'pt_BR', 'opcional - deixe vazio para todos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (403, 'seller', 'integrations.webhook.title', 'pt_BR', 'Webhooks', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (404, 'seller', 'integrations.webhook.new', 'pt_BR', 'Novo webhook', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (405, 'seller', 'integrations.webhook.configured', 'pt_BR', 'Webhooks configurados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (406, 'seller', 'integrations.webhook.events_count', 'pt_BR', 'evento(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (407, 'seller', 'integrations.webhook.products_count', 'pt_BR', 'produto(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (408, 'seller', 'integrations.webhook.last_deliveries', 'pt_BR', 'Últimos envios', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (409, 'seller', 'integrations.webhook.no_deliveries', 'pt_BR', 'Nenhum envio registrado.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (410, 'seller', 'integrations.webhook.empty', 'pt_BR', 'Nenhum webhook configurado. Clique em "Novo webhook" para criar.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (411, 'seller', 'integrations.webhook.edit', 'pt_BR', 'Editar webhook', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (412, 'seller', 'integrations.webhook.bearer_token', 'pt_BR', 'Bearer token', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (413, 'seller', 'integrations.webhook.auth_token', 'pt_BR', 'Token de autenticação', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (414, 'seller', 'integrations.webhook.token_security_hint', 'pt_BR', 'Por segurança, o valor do token salvo não é exibido neste campo.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (415, 'seller', 'integrations.webhook.token_already_saved', 'pt_BR', 'Token já está salvo. Deixe em branco para manter.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (416, 'seller', 'integrations.webhook.events', 'pt_BR', 'Eventos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (417, 'seller', 'integrations.webhook.send_test_event', 'pt_BR', 'Enviar evento de teste', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (418, 'seller', 'integrations.webhook.event', 'pt_BR', 'Evento', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (419, 'seller', 'integrations.webhook.trigger_test', 'pt_BR', 'Disparar evento de teste', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (420, 'seller', 'integrations.webhook.error_name', 'pt_BR', 'Informe o nome do webhook.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (421, 'seller', 'integrations.webhook.error_url', 'pt_BR', 'Informe a URL do webhook.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (422, 'seller', 'integrations.webhook.error_event', 'pt_BR', 'Selecione pelo menos um evento.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (423, 'seller', 'integrations.webhook.test_success', 'pt_BR', 'Evento enviado com sucesso!', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (424, 'seller', 'integrations.webhook.test_fail', 'pt_BR', 'Falha ao enviar.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (425, 'seller', 'integrations.webhook.test_error', 'pt_BR', 'Erro ao disparar evento de teste.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (426, 'seller', 'integrations.cademi.base_url', 'pt_BR', 'Base URL', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (427, 'seller', 'integrations.cademi.postback_token', 'pt_BR', 'Token de Postback', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (428, 'seller', 'integrations.cademi.error_base_url', 'pt_BR', 'Informe a Base URL (ex.: https://seu-subdominio.cademi.com.br).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (429, 'seller', 'integrations.cademi.error_postback_token', 'pt_BR', 'Informe o Token de Postback.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (430, 'seller', 'integrations.cademi.delete_confirm', 'pt_BR', 'Deseja realmente excluir esta integração Cademí?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (431, 'seller', 'integrations.spedy.environment', 'pt_BR', 'Ambiente', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (432, 'seller', 'integrations.spedy.production', 'pt_BR', 'Produção', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (433, 'seller', 'integrations.spedy.sandbox', 'pt_BR', 'Sandbox (testes)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (434, 'seller', 'integrations.spedy.delete_confirm', 'pt_BR', 'Deseja realmente excluir esta integração Spedy? A emissão automática de notas será desativada para os produtos vinculados.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (435, 'seller', 'integrations.utmify.delete_confirm', 'pt_BR', 'Deseja realmente excluir esta integração UTMfy? Os eventos deixarão de ser enviados.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (436, 'seller', 'reports.total_revenue', 'pt_BR', 'Receita total', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (437, 'seller', 'reports.abandoned_sales', 'pt_BR', 'Vendas abandonadas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (438, 'seller', 'reports.rate', 'pt_BR', 'Taxa', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (439, 'seller', 'reports.conversion', 'pt_BR', 'conversão', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (440, 'seller', 'subscriptions.active', 'pt_BR', 'Assinaturas ativas', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (441, 'seller', 'subscriptions.plan', 'pt_BR', 'Plano', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (442, 'seller', 'subscriptions.renews_on', 'pt_BR', 'Renova em', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (443, 'seller', 'subscriptions.product_plan', 'pt_BR', 'Produto / Plano', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (444, 'seller', 'subscriptions.list_hint', 'pt_BR', 'Lista de assinaturas ativas. Os lembretes de renovação são enviados por e-mail antes do vencimento.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (445, 'seller', 'subscriptions.empty', 'pt_BR', 'Nenhuma assinatura ainda', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (446, 'seller', 'subscriptions.empty_hint', 'pt_BR', 'Os produtos configurados como "Assinatura" com planos aparecerão aqui quando houver assinantes ativos.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (447, 'seller', 'subscriptions.status.active', 'pt_BR', 'Ativa', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (448, 'seller', 'subscriptions.status.past_due', 'pt_BR', 'Em atraso', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (449, 'seller', 'subscriptions.status.cancelled', 'pt_BR', 'Cancelada', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (450, 'seller', 'coupons.new', 'pt_BR', 'Novo cupom', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (451, 'seller', 'coupons.code', 'pt_BR', 'Código', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (452, 'seller', 'coupons.type', 'pt_BR', 'Tipo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (453, 'seller', 'coupons.value', 'pt_BR', 'Valor', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (454, 'seller', 'coupons.uses', 'pt_BR', 'Usos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (455, 'seller', 'coupons.validity', 'pt_BR', 'Validade', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (456, 'seller', 'coupons.type_percent', 'pt_BR', 'Percentual', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (457, 'seller', 'coupons.type_fixed', 'pt_BR', 'Fixo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (458, 'seller', 'coupons.edit', 'pt_BR', 'Editar cupom', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (459, 'seller', 'coupons.delete', 'pt_BR', 'Excluir cupom', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (460, 'seller', 'coupons.empty', 'pt_BR', 'Nenhum cupom ainda.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (461, 'seller', 'coupons.create_first', 'pt_BR', 'Criar primeiro cupom', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (462, 'seller', 'coupons.delete_title', 'pt_BR', 'Excluir cupom?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (463, 'seller', 'coupons.delete_confirm', 'pt_BR', 'Tem certeza que deseja excluir o cupom', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (464, 'seller', 'students.filter', 'pt_BR', 'Filtrar alunos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (465, 'seller', 'students.total', 'pt_BR', 'Total de alunos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (466, 'seller', 'students.total_enrollments', 'pt_BR', 'Total de inscrições', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (467, 'seller', 'students.products_with_students', 'pt_BR', 'Produtos com alunos', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (468, 'seller', 'students.new_30_days', 'pt_BR', 'Novos 30 dias', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (469, 'seller', 'students.search_placeholder', 'pt_BR', 'Buscar aluno por nome ou e-mail...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (470, 'seller', 'students.remove_filter', 'pt_BR', 'Remover filtro', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (471, 'seller', 'students.new_student', 'pt_BR', 'Novo aluno', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (472, 'seller', 'students.empty', 'pt_BR', 'Nenhum aluno com acesso ainda.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (473, 'seller', 'students.name_placeholder', 'pt_BR', 'Nome do aluno', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (474, 'seller', 'students.send_access_email_create', 'pt_BR', 'Enviar e-mail de acesso ao criar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (475, 'seller', 'students.products_access_optional', 'pt_BR', 'Produtos com acesso (opcional)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (476, 'seller', 'students.no_products_available', 'pt_BR', 'Nenhum produto disponível', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (477, 'seller', 'students.register', 'pt_BR', 'Cadastrar', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (478, 'seller', 'students.new.required_fields', 'pt_BR', 'Preencha nome, e-mail e senha.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (479, 'seller', 'students.new.success', 'pt_BR', 'Aluno cadastrado com sucesso.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (480, 'seller', 'students.new.error', 'pt_BR', 'Erro ao cadastrar. Tente novamente.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (481, 'seller', 'students.import.title', 'pt_BR', 'Importar alunos em massa', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (482, 'seller', 'students.import.hint', 'pt_BR', 'Envie um arquivo CSV com as colunas: nome, email, senha (opcional). Use ; ou , como separador.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (483, 'seller', 'students.import.download_example', 'pt_BR', 'Baixar CSV de exemplo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (484, 'seller', 'students.import.csv_file', 'pt_BR', 'Arquivo CSV', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (485, 'seller', 'students.import.send_access_email', 'pt_BR', 'Enviar e-mail de acesso aos importados', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (486, 'seller', 'students.import.products_required', 'pt_BR', 'Produtos para dar acesso (obrigatório)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (487, 'seller', 'students.import.select_csv', 'pt_BR', 'Selecione um arquivo CSV.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (488, 'seller', 'students.import.select_product', 'pt_BR', 'Selecione ao menos um produto para dar acesso.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (489, 'seller', 'students.import.done', 'pt_BR', 'Importação concluída.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (490, 'seller', 'students.import.error', 'pt_BR', 'Erro na importação. Verifique o formato do CSV.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (491, 'seller', 'common.irreversible_action', 'pt_BR', 'Esta ação não pode ser desfeita.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (635, 'seller', 'team.edit_role', 'es', 'Editar role', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (711, 'seller', 'common.copy', 'es', 'Copiar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (1134, 'seller', 'team.user', 'en', 'User', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (983, 'seller', 'header.language', 'en', 'Language', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (984, 'seller', 'header.notifications', 'en', 'Notifications', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (985, 'seller', 'sidebar.dashboard', 'en', 'Dashboard', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (986, 'seller', 'sidebar.sales', 'en', 'Sales', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (987, 'seller', 'sidebar.products', 'en', 'Products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (988, 'seller', 'sidebar.affiliate_showcase', 'en', 'Showcase', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (989, 'seller', 'sidebar.coupons', 'en', 'Coupons', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (990, 'seller', 'sidebar.students', 'en', 'Students', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (991, 'seller', 'sidebar.affiliates_menu', 'en', 'Affiliates', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (992, 'seller', 'affiliates.my_affiliates_title', 'en', 'My affiliates', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (993, 'seller', 'affiliates.my_affiliates_subtitle', 'en', 'Manage requests and affiliate enrollments across all your products.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (994, 'seller', 'affiliates.filter_status', 'en', 'Status', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (995, 'seller', 'affiliates.filter_all', 'en', 'All', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (996, 'seller', 'affiliates.filter_pending', 'en', 'Pending', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (997, 'seller', 'affiliates.filter_active', 'en', 'Active', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (998, 'seller', 'affiliates.filter_blocked', 'en', 'Blocked (rejected/revoked)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (999, 'seller', 'affiliates.filter_rejected', 'en', 'Rejected', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1000, 'seller', 'affiliates.filter_revoked', 'en', 'Revoked', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1001, 'seller', 'affiliates.filter_product', 'en', 'Product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1002, 'seller', 'affiliates.all_products', 'en', 'All products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1003, 'seller', 'affiliates.search_affiliate', 'en', 'Search affiliate', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1004, 'seller', 'affiliates.search_placeholder', 'en', 'Name or email', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1005, 'seller', 'affiliates.col_affiliate', 'en', 'Affiliate', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1006, 'seller', 'affiliates.col_product', 'en', 'Product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1007, 'seller', 'affiliates.col_status', 'en', 'Status', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1008, 'seller', 'affiliates.col_actions', 'en', 'Actions', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1009, 'seller', 'affiliates.status_approved', 'en', 'Active', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1010, 'seller', 'affiliates.status_pending', 'en', 'Pending', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1011, 'seller', 'affiliates.status_rejected', 'en', 'Rejected', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1012, 'seller', 'affiliates.status_revoked', 'en', 'Revoked', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1013, 'seller', 'affiliates.action_approve', 'en', 'Approve', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1014, 'seller', 'affiliates.action_reject', 'en', 'Reject', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1015, 'seller', 'affiliates.action_revoke', 'en', 'Block / revoke', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1016, 'seller', 'affiliates.empty', 'en', 'No enrollments match the current filters.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1017, 'seller', 'sidebar.reports', 'en', 'Reports', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1018, 'seller', 'sidebar.integrations', 'en', 'Integrations', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1019, 'seller', 'sidebar.team', 'en', 'Team', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1020, 'seller', 'sidebar.finance', 'en', 'Finance', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1021, 'seller', 'dashboard.title', 'en', 'Dashboard', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1022, 'seller', 'dashboard.subtitle', 'en', 'Performance overview, sales, and period metrics.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1023, 'seller', 'dashboard.period', 'en', 'Period', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1024, 'seller', 'dashboard.hide_values', 'en', 'Hide values', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1025, 'seller', 'dashboard.show_values', 'en', 'Show values', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1026, 'seller', 'dashboard.total_sales', 'en', 'Total sales', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1027, 'seller', 'dashboard.pending_sales', 'en', 'Pending sales', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1028, 'seller', 'dashboard.sales_count', 'en', 'Sales count', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1029, 'seller', 'dashboard.avg_ticket', 'en', 'Average ticket', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1030, 'seller', 'dashboard.payment_methods', 'en', 'Payment methods', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1031, 'seller', 'dashboard.no_payments', 'en', 'No payments in this period', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1032, 'seller', 'dashboard.conversion_rate', 'en', 'Overall conversion rate', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1033, 'seller', 'dashboard.cart_abandonment', 'en', 'Cart abandonment', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1034, 'seller', 'dashboard.refunds', 'en', 'Refunds', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1035, 'seller', 'dashboard.orders_count', 'en', 'order(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1036, 'seller', 'dashboard.products', 'en', 'Products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1037, 'seller', 'dashboard.sales_performance', 'en', 'Sales performance', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1038, 'seller', 'dashboard.no_sales_data', 'en', 'No sales data in this period', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1039, 'seller', 'period.today', 'en', 'Today', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1040, 'seller', 'period.yesterday', 'en', 'Yesterday', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1041, 'seller', 'period.7days', 'en', '7 days', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1042, 'seller', 'period.month', 'en', 'Month', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1043, 'seller', 'period.year', 'en', 'Year', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1044, 'seller', 'period.total', 'en', 'Total', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1045, 'seller', 'sales.tab_sales', 'en', 'Sales', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1046, 'seller', 'sales.tab_subscriptions', 'en', 'Subscriptions', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1047, 'seller', 'products.tab_products', 'en', 'Products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1048, 'seller', 'products.tab_coupons', 'en', 'Coupons', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1049, 'seller', 'products.tab_students', 'en', 'Students', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1050, 'seller', 'products.tab_coproduction', 'en', 'Co-production', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1051, 'seller', 'products.tab_showcase', 'en', 'Showcase', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1052, 'seller', 'products.tab_affiliates', 'en', 'Affiliates', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1053, 'seller', 'products.affiliates_page_title', 'en', 'Affiliates', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1054, 'seller', 'products.affiliates_page_subtitle', 'en', 'Products you are an approved affiliate for. Use your exclusive link and configure your conversion pixels.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1055, 'seller', 'products.affiliate_badge', 'en', 'Affiliate', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1056, 'seller', 'products.affiliate_status_pending', 'en', 'Pending', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1057, 'seller', 'products.affiliate_status_approved', 'en', 'Approved', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1058, 'seller', 'products.affiliate_panel', 'en', 'Affiliate panel', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1059, 'seller', 'products.affiliate_open_checkout', 'en', 'Open checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1060, 'seller', 'products.affiliate_no_link', 'en', 'Link unavailable (set product checkout or wait for approval).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1061, 'seller', 'products.affiliates_empty', 'en', 'No affiliate products yet.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1062, 'seller', 'products.affiliate_panel_title', 'en', 'Affiliate panel', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1063, 'seller', 'products.affiliate_panel_subtitle', 'en', 'Your affiliate link and pixels used on sales via your ref.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1064, 'seller', 'products.affiliate_link_section', 'en', 'Affiliate link', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1065, 'seller', 'products.affiliate_copy_link', 'en', 'Copy link', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1066, 'seller', 'products.affiliate_pix_hint', 'en', 'Set up your PIX key to receive commissions under Finance.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1067, 'seller', 'products.affiliate_pix_finance_link', 'en', 'Configure payout PIX', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1068, 'seller', 'products.affiliate_pixels_only_hint', 'en', 'When the sale comes through your link (?ref=), only these pixels are used on checkout and thank-you pages — not the seller’s.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1069, 'seller', 'products.coproduction_page_title', 'en', 'Co-production', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1070, 'seller', 'products.coproduction_page_subtitle', 'en', 'Products where you are a co-producer and invitations awaiting your approval.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1071, 'seller', 'products.coproduction_section_pending', 'en', 'Pending approval', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1072, 'seller', 'products.coproduction_section_active', 'en', 'Active co-productions', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1073, 'seller', 'products.coproduction_by', 'en', 'Producer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1074, 'seller', 'products.coproduction_accept', 'en', 'Accept', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1075, 'seller', 'products.coproduction_details', 'en', 'Details', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1076, 'seller', 'products.coproduction_empty_pending', 'en', 'No pending invitations.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1077, 'seller', 'products.coproduction_empty_active', 'en', 'No active co-productions yet.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1078, 'seller', 'products.coproduction_until', 'en', 'until', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1079, 'seller', 'products.coproduction_view_checkout', 'en', 'View checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1080, 'seller', 'integrations.title', 'en', 'Apps', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1081, 'seller', 'integrations.subtitle', 'en', 'Connect your platform with external systems through webhooks and other integrations. Payment gateways are configured in the platform panel (operator).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1082, 'seller', 'integrations.webhook.description', 'en', 'Send platform events to your URL. Configure which events you want to receive and use a Bearer token for authentication.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1083, 'seller', 'integrations.utmify.description', 'en', 'Track sales and send events to UTMfy. It only requires the API key.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1084, 'seller', 'integrations.spedy.description', 'en', 'Automatic invoice issuance. Send sales to Spedy and issue NF-e/NFS-e.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1085, 'seller', 'integrations.cademi.description', 'en', 'External members area. After purchase, sync the student and grant access in Cademí.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1086, 'seller', 'users.title', 'en', 'Users', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1087, 'seller', 'users.subtitle', 'en', 'Master account and platform infoproducers.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1088, 'seller', 'users.tab_infoproducers', 'en', 'Infoproducers', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1089, 'seller', 'users.tab_team', 'en', 'Team', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1090, 'seller', 'users.new_infoproducer', 'en', 'New infoproducer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1091, 'seller', 'users.edit_user', 'en', 'Edit user', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1092, 'seller', 'users.delete_user', 'en', 'Delete user', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1093, 'seller', 'users.empty', 'en', 'No users registered.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1094, 'seller', 'finance.request_withdrawal', 'en', 'Request withdrawal', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1095, 'seller', 'finance.available_balance', 'en', 'Available balance', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1096, 'seller', 'finance.ready_for_withdrawal', 'en', 'Ready for withdrawal', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1097, 'seller', 'finance.pending_receive', 'en', 'To receive', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1098, 'seller', 'finance.settling', 'en', 'Settling', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1099, 'seller', 'finance.by_method', 'en', 'By method', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1100, 'seller', 'finance.my_fees_and_payout', 'en', 'My fees and payout time', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1101, 'seller', 'finance.by_payment_method', 'en', 'By payment method', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1102, 'seller', 'finance.fee', 'en', 'Fee', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1103, 'seller', 'finance.payout_deadline', 'en', 'Payout deadline', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1104, 'seller', 'finance.statement', 'en', 'Statement', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1105, 'seller', 'finance.bank_details', 'en', 'Bank details', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1106, 'seller', 'finance.no_withdrawals', 'en', 'No withdrawals yet', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1107, 'seller', 'finance.no_withdrawals_hint', 'en', 'Your requested withdrawals will appear here.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1108, 'seller', 'finance.withdrawals', 'en', 'Withdrawals', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1109, 'seller', 'common.view', 'en', 'View', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1110, 'seller', 'common.hide', 'en', 'Hide', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1111, 'seller', 'common.close', 'en', 'Close', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1112, 'seller', 'common.save', 'en', 'Save', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1113, 'seller', 'common.cancel', 'en', 'Cancel', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1114, 'seller', 'common.name', 'en', 'Name', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1115, 'seller', 'common.email', 'en', 'Email', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1116, 'seller', 'common.password', 'en', 'Password', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1117, 'seller', 'common.confirm_password', 'en', 'Confirm password', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1118, 'seller', 'team.roles', 'en', 'Roles', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1119, 'seller', 'team.members', 'en', 'Members', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1120, 'seller', 'team.logs', 'en', 'Logs', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1121, 'seller', 'team.new_role', 'en', 'New role', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1122, 'seller', 'team.new_member', 'en', 'New member', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1123, 'seller', 'team.clear_logs', 'en', 'Clear logs', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1124, 'seller', 'team.permissions', 'en', 'Permissions', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1125, 'seller', 'team.products_count', 'en', 'product(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1126, 'seller', 'team.edit_role', 'en', 'Edit role', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1127, 'seller', 'team.remove_role', 'en', 'Remove role', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1128, 'seller', 'team.no_roles', 'en', 'No roles created.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1129, 'seller', 'team.no_role', 'en', 'No role', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1130, 'seller', 'team.edit_member', 'en', 'Edit member', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1131, 'seller', 'team.remove_member', 'en', 'Remove member', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1132, 'seller', 'team.no_members', 'en', 'No members registered.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1133, 'seller', 'team.when', 'en', 'When', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1135, 'seller', 'team.action', 'en', 'Action', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1136, 'seller', 'team.no_logs', 'en', 'No logs registered yet.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1137, 'seller', 'team.role_name', 'en', 'Role name', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1138, 'seller', 'team.allowed_products', 'en', 'Allowed products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1139, 'seller', 'team.allowed_products_hint', 'en', 'Affects all product modules (Dashboard, Sales, Products, etc.).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1140, 'seller', 'team.role', 'en', 'Role', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1141, 'seller', 'team.new_password_optional', 'en', 'New password (optional)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1142, 'seller', 'team.send_access_email', 'en', 'Send access email with login and password', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1143, 'seller', 'team.send_access_email_hint', 'en', 'The email will be sent to the address above.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1144, 'seller', 'team.confirm_delete_role', 'en', 'Remove role "{name}"?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1145, 'seller', 'team.confirm_delete_member', 'en', 'Remove "{name}" from team?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1146, 'seller', 'team.confirm_clear_logs', 'en', 'Clear all audit logs for this tenant?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1147, 'seller', 'team.permission_email_marketing', 'en', 'Email Marketing', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1148, 'seller', 'team.permission_api_payments', 'en', 'Payments API', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1149, 'seller', 'team.permission_settings', 'en', 'Settings', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1150, 'seller', 'team.permission_manage_team', 'en', 'Manage team', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1151, 'seller', 'products.edit.custom_script', 'en', 'Custom script', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1152, 'seller', 'products.edit.tab_general', 'en', 'General', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1153, 'seller', 'products.edit.tab_settings', 'en', 'Settings', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1154, 'seller', 'products.edit.tab_email', 'en', 'Email', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1155, 'seller', 'products.edit.tab_links', 'en', 'Links', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1156, 'seller', 'products.edit.tab_coproduction', 'en', 'Co-production', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1157, 'seller', 'products.edit.coproduction_title', 'en', 'Invite co-producer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1158, 'seller', 'products.edit.coproduction_help', 'en', 'The invitee must be an infoproducer. They will receive an email to accept. Commissions are on gross sale amounts; platform fees apply to each party''s wallet.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1159, 'seller', 'products.edit.tab_affiliates', 'en', 'Affiliates', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1160, 'seller', 'products.edit.affiliate_title', 'en', 'Affiliate program', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1161, 'seller', 'products.edit.affiliate_help', 'en', 'Commissions on gross sale amounts; platform fees apply per wallet. Co-production (affiliate sales) + affiliate must not exceed 100%.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1162, 'seller', 'products.edit.affiliate_enable', 'en', 'Enable affiliate program for this product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1163, 'seller', 'products.edit.affiliate_commission', 'en', 'Affiliate commission (%)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1164, 'seller', 'products.edit.affiliate_manual', 'en', 'Manually approve affiliate requests', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1165, 'seller', 'products.edit.affiliate_showcase', 'en', 'Show in showcase', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1166, 'seller', 'products.edit.affiliate_page_url', 'en', 'Affiliate page URL', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1167, 'seller', 'products.edit.affiliate_support_email', 'en', 'Support email', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1168, 'seller', 'products.edit.affiliate_showcase_desc', 'en', 'Description (showcase)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1169, 'seller', 'products.edit.affiliate_checkout_hint', 'en', 'Base checkout URL (add ?ref= after approving an affiliate)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1170, 'seller', 'products.edit.affiliate_enrollments', 'en', 'Affiliates and requests', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1171, 'seller', 'products.edit.affiliate_enrollments_hint', 'en', 'All records for this product: pending, approved, rejected, and revoked.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1172, 'seller', 'products.edit.affiliate_status_pending', 'en', 'Pending', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1173, 'seller', 'products.edit.affiliate_status_approved', 'en', 'Approved', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1174, 'seller', 'products.edit.affiliate_status_rejected', 'en', 'Rejected', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1175, 'seller', 'products.edit.affiliate_status_revoked', 'en', 'Revoked', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1176, 'seller', 'products.edit.affiliate_user_fallback', 'en', 'User :id', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1177, 'seller', 'products.edit.affiliate_copy_link', 'en', 'Copy link', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1178, 'seller', 'products.edit.affiliate_approve', 'en', 'Approve', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1179, 'seller', 'products.edit.affiliate_reject', 'en', 'Reject', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1180, 'seller', 'products.edit.affiliate_revoke', 'en', 'Revoke', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1181, 'seller', 'products.edit.affiliate_empty', 'en', 'No affiliates or requests yet.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1182, 'seller', 'products.showcase.title', 'en', 'Showcase', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1183, 'seller', 'products.showcase.subtitle', 'en', 'Products open to affiliates. Sort by best sellers or filter by category.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1184, 'seller', 'products.showcase.your_product_badge', 'en', 'Your product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1185, 'seller', 'products.showcase.own_product_hint', 'en', 'This is your product. Manage affiliates in the product editor.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1186, 'seller', 'products.showcase.edit_affiliate_settings', 'en', 'Open affiliate settings', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1187, 'seller', 'products.showcase.search', 'en', 'Search', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1188, 'seller', 'products.showcase.category_all', 'en', 'All categories', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1189, 'seller', 'products.showcase.sort_hot', 'en', 'Hottest', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1190, 'seller', 'products.showcase.sort_name', 'en', 'Name', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1191, 'seller', 'products.showcase.sort_price_asc', 'en', 'Lowest price', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1192, 'seller', 'products.showcase.sort_price_desc', 'en', 'Highest price', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1193, 'seller', 'products.showcase.section_hot', 'en', 'Hottest', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1194, 'seller', 'products.showcase.you_receive', 'en', 'You earn up to', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1195, 'seller', 'products.showcase.empty', 'en', 'No products match these filters.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1196, 'seller', 'products.showcase.affiliate_page', 'en', 'Affiliate page', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1197, 'seller', 'products.showcase.support', 'en', 'Support', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1198, 'seller', 'products.showcase.order_bump', 'en', 'Includes order bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1199, 'seller', 'products.showcase.your_link', 'en', 'Your affiliate link', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1200, 'seller', 'products.showcase.request', 'en', 'Request affiliation', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1201, 'seller', 'products.showcase.pending', 'en', 'Waiting for producer approval.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1202, 'seller', 'common.copy', 'en', 'Copy', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1203, 'seller', 'products.edit.tab_order_bump', 'en', 'Order Bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1204, 'seller', 'products.edit.tab_upsell_downsell', 'en', 'Upsell / Downsell', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1205, 'seller', 'products.edit.tab_checkout', 'en', 'Checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1206, 'seller', 'products.edit.tab_member_builder', 'en', 'Member Builder', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1207, 'seller', 'products.edit.basic_info', 'en', 'Basic information', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1208, 'seller', 'products.edit.basic_info_hint', 'en', 'Product name, identifier, and image.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1209, 'seller', 'products.edit.product_name', 'en', 'Product name', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1210, 'seller', 'products.edit.slug_url', 'en', 'Slug (URL)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1211, 'seller', 'products.edit.slug_hint', 'en', 'Used in URLs and members area. Lowercase letters, numbers, and hyphens only.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1212, 'seller', 'products.edit.product_image', 'en', 'Product image', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1213, 'seller', 'products.edit.change_image', 'en', 'Change', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1214, 'seller', 'products.edit.pricing_billing', 'en', 'Pricing and billing', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1215, 'seller', 'products.edit.pricing_billing_hint', 'en', 'Define how the product will be charged and the base amount.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1216, 'seller', 'products.edit.base_price_brl', 'en', 'Base price (BRL)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1217, 'seller', 'products.edit.recurrence', 'en', 'Recurrence', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1218, 'seller', 'products.edit.extra_offers', 'en', 'Extra offers', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1219, 'seller', 'products.edit.subscription_plans', 'en', 'Subscription plans', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1220, 'seller', 'products.edit.extra_offers_hint', 'en', 'Multiple offers (prices). Each one has its own checkout link.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1221, 'seller', 'products.edit.subscription_plans_hint', 'en', 'Create plans (price and interval). Each plan has its own checkout link.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1222, 'seller', 'products.edit.no_offer', 'en', 'No offer. Add one below or use only the base price.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1223, 'seller', 'products.edit.edit_offer', 'en', 'Edit offer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1224, 'seller', 'products.edit.new_offer', 'en', 'New offer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1225, 'seller', 'products.edit.add_offer', 'en', 'Add offer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1226, 'seller', 'products.edit.no_plan', 'en', 'No plan. Add one below.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1227, 'seller', 'products.edit.edit_plan', 'en', 'Edit plan', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1228, 'seller', 'products.edit.new_plan', 'en', 'New plan', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1229, 'seller', 'products.edit.add_plan', 'en', 'Add plan', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1230, 'seller', 'products.edit.save_changes', 'en', 'Save changes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1231, 'seller', 'products.edit.conversion_pixels', 'en', 'Conversion pixels', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1232, 'seller', 'products.edit.conversion_pixels_hint', 'en', 'Set up pixels to track conversions on checkout, upsell, and downsell.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1233, 'seller', 'products.edit.add_pixel', 'en', 'Add pixel', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1234, 'seller', 'products.edit.no_pixels', 'en', 'No pixel. Click "Add pixel" or disable the integration.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1235, 'seller', 'products.edit.add_conversion', 'en', 'Add conversion', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1236, 'seller', 'products.edit.no_conversion', 'en', 'No conversion. Click "Add conversion" or disable the integration.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1237, 'seller', 'products.edit.add_property', 'en', 'Add property', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1238, 'seller', 'products.edit.no_property', 'en', 'No property. Click "Add property" or disable the integration.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1239, 'seller', 'products.edit.custom_scripts', 'en', 'Custom scripts', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1240, 'seller', 'products.edit.no_custom_script', 'en', 'No script added. Click "Add pixel" to include a custom tracking code.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1241, 'seller', 'products.edit.access_email_template', 'en', 'Access email template', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1242, 'seller', 'products.edit.access_email_template_hint', 'en', 'Customize the email sent to the customer after purchase. Placeholders are replaced with real data.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1243, 'seller', 'products.edit.email_logo', 'en', 'Email logo', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1244, 'seller', 'products.edit.click_to_change', 'en', 'Click to change', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1245, 'seller', 'products.edit.click_to_upload', 'en', 'Click to upload', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1246, 'seller', 'products.edit.sender_name_optional', 'en', 'Sender name (optional)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1247, 'seller', 'products.edit.sender_name_hint', 'en', 'If empty, uses the general settings name.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1248, 'seller', 'products.edit.email_subject', 'en', 'Email subject', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1249, 'seller', 'products.edit.email_body_html', 'en', 'Email body (HTML)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1250, 'seller', 'products.edit.email_preview', 'en', 'Email preview', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1251, 'seller', 'products.edit.email_preview_hint', 'en', 'How the email will be shown to the customer.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1252, 'seller', 'products.edit.order_bump_hint', 'en', 'Offer additional products on checkout so the customer can buy together. Choose product, title, description, and price.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1253, 'seller', 'products.edit.add_order_bump', 'en', 'Add order bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1254, 'seller', 'products.edit.no_order_bump', 'en', 'No order bump', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1255, 'seller', 'products.edit.no_order_bump_hint', 'en', 'Add products that will appear on checkout as a special offer to buy together.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1256, 'seller', 'products.interval.weekly', 'en', 'Weekly', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1257, 'seller', 'products.interval.monthly', 'en', 'Monthly', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1258, 'seller', 'products.interval.quarterly', 'en', 'Quarterly', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1259, 'seller', 'products.interval.semi_annual', 'en', 'Semi-annual', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1260, 'seller', 'products.interval.annual', 'en', 'Annual', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1261, 'seller', 'products.interval.lifetime', 'en', 'Lifetime', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1262, 'seller', 'checkout_builder.edit_checkout', 'en', 'Edit checkout', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1263, 'seller', 'checkout_builder.tab_general', 'en', 'General', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1264, 'seller', 'checkout_builder.tab_features', 'en', 'Features', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1265, 'seller', 'checkout_builder.tab_template', 'en', 'Template', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1266, 'seller', 'checkout_builder.tab_social', 'en', 'Social', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1267, 'seller', 'checkout_builder.price_discount', 'en', 'Price / Discount', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1268, 'seller', 'checkout_builder.form_fields', 'en', 'Form fields', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1269, 'seller', 'sales.subtitle', 'en', 'Track orders, payment status, and commercial performance.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1270, 'seller', 'products.subtitle', 'en', 'Manage your products, offers, and checkout access.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1271, 'seller', 'reports.subtitle', 'en', 'Analyze results, revenue, and business indicators.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1272, 'seller', 'finance.subtitle', 'en', 'Balances, statement, and payout details.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1273, 'seller', 'team.title', 'en', 'Users', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1274, 'seller', 'team.subtitle', 'en', 'Manage team and permissions.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1275, 'seller', 'settings.languages.tab', 'en', 'Languages', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1276, 'seller', 'settings.languages.title', 'en', 'Platform languages', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1277, 'seller', 'settings.languages.subtitle', 'en', 'Manage infoproducer panel languages and translations.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1278, 'seller', 'settings.languages.add', 'en', 'Add language', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1279, 'seller', 'settings.languages.default', 'en', 'Default', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1280, 'seller', 'settings.languages.active', 'en', 'Active', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1281, 'seller', 'settings.languages.search', 'en', 'Search translation key...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1282, 'seller', 'settings.languages.save', 'en', 'Save translations', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1283, 'seller', 'settings.languages.import_missing', 'en', 'Import missing keys', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1284, 'seller', 'common.image', 'en', 'Image', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1285, 'seller', 'common.description', 'en', 'Description', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1286, 'seller', 'common.active', 'en', 'Active', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1287, 'seller', 'common.inactive', 'en', 'Inactive', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1288, 'seller', 'common.edit', 'en', 'Edit', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1289, 'seller', 'common.delete', 'en', 'Delete', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1290, 'seller', 'common.loading', 'en', 'Loading...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1291, 'seller', 'common.error', 'en', 'Error', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1292, 'seller', 'common.send', 'en', 'Send', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1293, 'seller', 'common.sending', 'en', 'Sending...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1294, 'seller', 'common.saving', 'en', 'Saving...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1295, 'seller', 'common.back', 'en', 'Back', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1296, 'seller', 'common.open_menu', 'en', 'Open menu', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1297, 'seller', 'common.pagination', 'en', 'Pagination', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1298, 'seller', 'common.date', 'en', 'Date', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1299, 'seller', 'common.from', 'en', 'From', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1300, 'seller', 'common.to', 'en', 'To', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1301, 'seller', 'common.optional', 'en', 'optional', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1302, 'seller', 'common.test', 'en', 'Test', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1303, 'seller', 'common.delete_question', 'en', 'Delete?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1304, 'seller', 'common.deleting', 'en', 'Deleting...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1305, 'seller', 'common.coming_soon', 'en', 'Coming soon', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1306, 'seller', 'common.back_to_list', 'en', 'Back to list', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1307, 'seller', 'common.leave_blank_keep', 'en', 'Leave blank to keep', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1308, 'seller', 'common.leave_blank_keep_current', 'en', 'Leave blank to keep current', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1309, 'seller', 'common.all', 'en', 'All', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1310, 'seller', 'common.yes', 'en', 'Yes', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1311, 'seller', 'common.no', 'en', 'No', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1312, 'seller', 'common.import', 'en', 'Import', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1313, 'seller', 'sales.filter.approved', 'en', 'Approved', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1314, 'seller', 'sales.filter.all_female', 'en', 'All', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1315, 'seller', 'sales.period.all', 'en', 'All period', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1316, 'seller', 'sales.period.last_7_days', 'en', 'Last 7 days', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1317, 'seller', 'sales.period.last_30_days', 'en', 'Last 30 days', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1318, 'seller', 'sales.period.this_month', 'en', 'This month', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1319, 'seller', 'sales.period.last_month', 'en', 'Last month', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1320, 'seller', 'sales.period.custom', 'en', 'Custom', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1321, 'seller', 'sales.payment_method.all', 'en', 'All methods', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1322, 'seller', 'sales.payment_method.card', 'en', 'Card', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1323, 'seller', 'sales.status', 'en', 'Status', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1324, 'seller', 'sales.status.all', 'en', 'All statuses', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1325, 'seller', 'sales.status.paid', 'en', 'Paid', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1326, 'seller', 'sales.status.pending', 'en', 'Pending', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1327, 'seller', 'sales.status.cancelled', 'en', 'Cancelled', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1328, 'seller', 'sales.status.refunded', 'en', 'Refunded', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1329, 'seller', 'sales.metrics.found_sales', 'en', 'Sales found', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1330, 'seller', 'sales.metrics.net_amount', 'en', 'Net amount', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1331, 'seller', 'sales.metrics.pix_sales', 'en', 'PIX sales', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1332, 'seller', 'sales.metrics.card_sales', 'en', 'Card sales', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1333, 'seller', 'sales.export.csv', 'en', 'Export CSV', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1334, 'seller', 'sales.export.xls', 'en', 'Export XLS', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1335, 'seller', 'sales.search_placeholder', 'en', 'Search by customer, email, order, product...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1336, 'seller', 'sales.clear_search', 'en', 'Clear search', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1337, 'seller', 'sales.clear_filters', 'en', 'Clear filters', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1338, 'seller', 'sales.products.all', 'en', 'All products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1339, 'seller', 'sales.offer', 'en', 'Offer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1340, 'seller', 'sales.offers.all', 'en', 'All offers', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1341, 'seller', 'sales.method', 'en', 'Method', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1342, 'seller', 'sales.show_advanced_filters', 'en', 'Show advanced filters', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1343, 'seller', 'sales.hide_advanced_filters', 'en', 'Hide advanced filters', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1344, 'seller', 'sales.customer', 'en', 'Customer', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1345, 'seller', 'sales.empty', 'en', 'No sales found.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1346, 'seller', 'sales.actions', 'en', 'Sale actions', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1347, 'seller', 'sales.details', 'en', 'Details', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1348, 'seller', 'sales.resend_purchase_email', 'en', 'Resend purchase email', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1349, 'seller', 'sales.resend_unavailable_pending', 'en', 'Unavailable for pending payments', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1350, 'seller', 'sales.toast.email_resent_success', 'en', 'Purchase email resent successfully.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1351, 'seller', 'sales.toast.email_resent_fail', 'en', 'Could not resend the email.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1352, 'seller', 'sales.toast.email_resent_error', 'en', 'Error resending email. Please try again.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1353, 'seller', 'products.create.new_product', 'en', 'New product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1354, 'seller', 'products.create.create_product', 'en', 'Create product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1355, 'seller', 'products.create.choose_delivery_type', 'en', 'Choose the product delivery type.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1356, 'seller', 'products.create.back_to_type', 'en', '← Back to type', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1357, 'seller', 'products.create.name_placeholder', 'en', 'Ex: Web Development Course', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1358, 'seller', 'products.create.billing_type', 'en', 'Billing type', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1359, 'seller', 'products.create.description_placeholder', 'en', 'Brief product description', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1360, 'seller', 'products.create.deliverable_link', 'en', 'Deliverable link', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1361, 'seller', 'products.create.deliverable_link_hint', 'en', 'Sent by email after purchase.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1362, 'seller', 'products.create.price_brl', 'en', 'Price (BRL)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1363, 'seller', 'products.create.image_hint', 'en', 'Displayed in square format (1:1). We recommend uploading a square image.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1364, 'seller', 'products.create.active_product', 'en', 'Active product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1365, 'seller', 'products.empty', 'en', 'No products registered.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1366, 'seller', 'integrations.new', 'en', 'New integration', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1367, 'seller', 'integrations.edit', 'en', 'Edit integration', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1368, 'seller', 'integrations.empty', 'en', 'No integration configured. Click "New integration" to start.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1369, 'seller', 'integrations.error_name', 'en', 'Enter the integration name.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1370, 'seller', 'integrations.error_api_key', 'en', 'Enter the API key.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1371, 'seller', 'integrations.error_api_key_create', 'en', 'Enter the API key when creating an integration.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1372, 'seller', 'integrations.error_save', 'en', 'Error saving integration.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1373, 'seller', 'integrations.error_delete', 'en', 'Error deleting integration.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1374, 'seller', 'integrations.all_products', 'en', 'All products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1375, 'seller', 'integrations.key_configured', 'en', 'Key configured', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1376, 'seller', 'integrations.key_not_configured', 'en', 'Key not configured', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1377, 'seller', 'integrations.integration_name', 'en', 'Integration name', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1378, 'seller', 'integrations.api_key', 'en', 'API key', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1379, 'seller', 'integrations.api_key_placeholder', 'en', 'Enter the key', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1380, 'seller', 'integrations.active_integration', 'en', 'Active integration', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1381, 'seller', 'integrations.assigned_products', 'en', 'Assigned products', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1382, 'seller', 'integrations.assigned_products_hint', 'en', 'Select products for which this integration will send events. Leave empty for all products.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1383, 'seller', 'integrations.configure_in_product', 'en', 'Configure in product', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1384, 'seller', 'integrations.optional_leave_all', 'en', 'optional - leave empty for all', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1385, 'seller', 'integrations.webhook.title', 'en', 'Webhooks', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1386, 'seller', 'integrations.webhook.new', 'en', 'New webhook', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1387, 'seller', 'integrations.webhook.configured', 'en', 'Configured webhooks', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1388, 'seller', 'integrations.webhook.events_count', 'en', 'event(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1389, 'seller', 'integrations.webhook.products_count', 'en', 'product(s)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1390, 'seller', 'integrations.webhook.last_deliveries', 'en', 'Last deliveries', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1391, 'seller', 'integrations.webhook.no_deliveries', 'en', 'No deliveries recorded.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1392, 'seller', 'integrations.webhook.empty', 'en', 'No webhook configured. Click "New webhook" to create one.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1393, 'seller', 'integrations.webhook.edit', 'en', 'Edit webhook', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1394, 'seller', 'integrations.webhook.bearer_token', 'en', 'Bearer token', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1395, 'seller', 'integrations.webhook.auth_token', 'en', 'Authentication token', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1396, 'seller', 'integrations.webhook.token_security_hint', 'en', 'For security reasons, the saved token value is not displayed in this field.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1397, 'seller', 'integrations.webhook.token_already_saved', 'en', 'Token is already saved. Leave blank to keep.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1398, 'seller', 'integrations.webhook.events', 'en', 'Events', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1399, 'seller', 'integrations.webhook.send_test_event', 'en', 'Send test event', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1400, 'seller', 'integrations.webhook.event', 'en', 'Event', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1401, 'seller', 'integrations.webhook.trigger_test', 'en', 'Trigger test event', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1402, 'seller', 'integrations.webhook.error_name', 'en', 'Enter the webhook name.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1403, 'seller', 'integrations.webhook.error_url', 'en', 'Enter the webhook URL.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1404, 'seller', 'integrations.webhook.error_event', 'en', 'Select at least one event.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1405, 'seller', 'integrations.webhook.test_success', 'en', 'Event sent successfully!', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1406, 'seller', 'integrations.webhook.test_fail', 'en', 'Failed to send.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1407, 'seller', 'integrations.webhook.test_error', 'en', 'Error triggering test event.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1408, 'seller', 'integrations.cademi.base_url', 'en', 'Base URL', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1409, 'seller', 'integrations.cademi.postback_token', 'en', 'Postback token', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1410, 'seller', 'integrations.cademi.error_base_url', 'en', 'Enter Base URL (e.g.: https://your-subdomain.cademi.com.br).', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1411, 'seller', 'integrations.cademi.error_postback_token', 'en', 'Enter the postback token.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1412, 'seller', 'integrations.cademi.delete_confirm', 'en', 'Are you sure you want to delete this Cademí integration?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1413, 'seller', 'integrations.spedy.environment', 'en', 'Environment', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1414, 'seller', 'integrations.spedy.production', 'en', 'Production', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1415, 'seller', 'integrations.spedy.sandbox', 'en', 'Sandbox (tests)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1416, 'seller', 'integrations.spedy.delete_confirm', 'en', 'Are you sure you want to delete this Spedy integration? Automatic invoice issuing will be disabled for linked products.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1417, 'seller', 'integrations.utmify.delete_confirm', 'en', 'Are you sure you want to delete this UTMfy integration? Events will stop being sent.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1418, 'seller', 'reports.total_revenue', 'en', 'Total revenue', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1419, 'seller', 'reports.abandoned_sales', 'en', 'Abandoned sales', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1420, 'seller', 'reports.rate', 'en', 'Rate', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1421, 'seller', 'reports.conversion', 'en', 'conversion', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1422, 'seller', 'subscriptions.active', 'en', 'Active subscriptions', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1423, 'seller', 'subscriptions.plan', 'en', 'Plan', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1424, 'seller', 'subscriptions.renews_on', 'en', 'Renews on', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1425, 'seller', 'subscriptions.product_plan', 'en', 'Product / Plan', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1426, 'seller', 'subscriptions.list_hint', 'en', 'List of active subscriptions. Renewal reminders are sent by email before due date.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1427, 'seller', 'subscriptions.empty', 'en', 'No subscriptions yet', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1428, 'seller', 'subscriptions.empty_hint', 'en', 'Products configured as "Subscription" with plans will appear here when there are active subscribers.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1429, 'seller', 'subscriptions.status.active', 'en', 'Active', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1430, 'seller', 'subscriptions.status.past_due', 'en', 'Past due', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1431, 'seller', 'subscriptions.status.cancelled', 'en', 'Cancelled', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1432, 'seller', 'coupons.new', 'en', 'New coupon', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1433, 'seller', 'coupons.code', 'en', 'Code', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1434, 'seller', 'coupons.type', 'en', 'Type', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1435, 'seller', 'coupons.value', 'en', 'Value', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1436, 'seller', 'coupons.uses', 'en', 'Uses', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1437, 'seller', 'coupons.validity', 'en', 'Validity', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1438, 'seller', 'coupons.type_percent', 'en', 'Percentage', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1439, 'seller', 'coupons.type_fixed', 'en', 'Fixed', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1440, 'seller', 'coupons.edit', 'en', 'Edit coupon', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1441, 'seller', 'coupons.delete', 'en', 'Delete coupon', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1442, 'seller', 'coupons.empty', 'en', 'No coupons yet.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1443, 'seller', 'coupons.create_first', 'en', 'Create first coupon', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1444, 'seller', 'coupons.delete_title', 'en', 'Delete coupon?', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1445, 'seller', 'coupons.delete_confirm', 'en', 'Are you sure you want to delete coupon', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1446, 'seller', 'students.filter', 'en', 'Filter students', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1447, 'seller', 'students.total', 'en', 'Total students', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1448, 'seller', 'students.total_enrollments', 'en', 'Total enrollments', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1449, 'seller', 'students.products_with_students', 'en', 'Products with students', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1450, 'seller', 'students.new_30_days', 'en', 'New (30 days)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1451, 'seller', 'students.search_placeholder', 'en', 'Search student by name or email...', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1452, 'seller', 'students.remove_filter', 'en', 'Remove filter', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1453, 'seller', 'students.new_student', 'en', 'New student', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1454, 'seller', 'students.empty', 'en', 'No students with access yet.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1455, 'seller', 'students.name_placeholder', 'en', 'Student name', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1456, 'seller', 'students.send_access_email_create', 'en', 'Send access email on create', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1457, 'seller', 'students.products_access_optional', 'en', 'Products with access (optional)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1458, 'seller', 'students.no_products_available', 'en', 'No products available', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1459, 'seller', 'students.register', 'en', 'Register', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1460, 'seller', 'students.new.required_fields', 'en', 'Fill in name, email and password.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1461, 'seller', 'students.new.success', 'en', 'Student registered successfully.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1462, 'seller', 'students.new.error', 'en', 'Error registering student. Try again.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1463, 'seller', 'students.import.title', 'en', 'Import students in bulk', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1464, 'seller', 'students.import.hint', 'en', 'Upload a CSV file with columns: name, email, password (optional). Use ; or , as separator.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1465, 'seller', 'students.import.download_example', 'en', 'Download sample CSV', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1466, 'seller', 'students.import.csv_file', 'en', 'CSV file', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1467, 'seller', 'students.import.send_access_email', 'en', 'Send access email to imported students', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1468, 'seller', 'students.import.products_required', 'en', 'Products to grant access (required)', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1469, 'seller', 'students.import.select_csv', 'en', 'Select a CSV file.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1470, 'seller', 'students.import.select_product', 'en', 'Select at least one product to grant access.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1471, 'seller', 'students.import.done', 'en', 'Import finished.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1472, 'seller', 'students.import.error', 'en', 'Import error. Check CSV format.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (1473, 'seller', 'common.irreversible_action', 'en', 'This action cannot be undone.', '2026-04-30 14:12:04', '2026-04-30 14:12:04');
INSERT INTO public.platform_translations VALUES (492, 'seller', 'header.language', 'es', 'Idioma', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (493, 'seller', 'header.notifications', 'es', 'Notificaciones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (494, 'seller', 'sidebar.dashboard', 'es', 'Panel', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (495, 'seller', 'sidebar.sales', 'es', 'Ventas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (496, 'seller', 'sidebar.products', 'es', 'Productos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (497, 'seller', 'sidebar.affiliate_showcase', 'es', 'Vitrina', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (498, 'seller', 'sidebar.coupons', 'es', 'Cupones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (499, 'seller', 'sidebar.students', 'es', 'Alumnos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (500, 'seller', 'sidebar.affiliates_menu', 'es', 'Afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (501, 'seller', 'affiliates.my_affiliates_title', 'es', 'Mis afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (502, 'seller', 'affiliates.my_affiliates_subtitle', 'es', 'Gestiona solicitudes y afiliaciones de todos tus productos.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (503, 'seller', 'affiliates.filter_status', 'es', 'Estado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (504, 'seller', 'affiliates.filter_all', 'es', 'Todos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (505, 'seller', 'affiliates.filter_pending', 'es', 'Pendientes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (506, 'seller', 'affiliates.filter_active', 'es', 'Activos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (507, 'seller', 'affiliates.filter_blocked', 'es', 'Bloqueados (rechazados/revocados)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (508, 'seller', 'affiliates.filter_rejected', 'es', 'Rechazados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (509, 'seller', 'affiliates.filter_revoked', 'es', 'Revocados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (510, 'seller', 'affiliates.filter_product', 'es', 'Producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (511, 'seller', 'affiliates.all_products', 'es', 'Todos los productos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (512, 'seller', 'affiliates.search_affiliate', 'es', 'Buscar afiliado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (513, 'seller', 'affiliates.search_placeholder', 'es', 'Nombre o correo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (514, 'seller', 'affiliates.col_affiliate', 'es', 'Afiliado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (515, 'seller', 'affiliates.col_product', 'es', 'Producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (516, 'seller', 'affiliates.col_status', 'es', 'Estado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (517, 'seller', 'affiliates.col_actions', 'es', 'Acciones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (518, 'seller', 'affiliates.status_approved', 'es', 'Activo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (519, 'seller', 'affiliates.status_pending', 'es', 'Pendiente', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (520, 'seller', 'affiliates.status_rejected', 'es', 'Rechazado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (521, 'seller', 'affiliates.status_revoked', 'es', 'Revocado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (522, 'seller', 'affiliates.action_approve', 'es', 'Aprobar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (523, 'seller', 'affiliates.action_reject', 'es', 'Rechazar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (524, 'seller', 'affiliates.action_revoke', 'es', 'Bloquear / revocar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (525, 'seller', 'affiliates.empty', 'es', 'No hay afiliaciones con los filtros actuales.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (526, 'seller', 'sidebar.reports', 'es', 'Informes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (527, 'seller', 'sidebar.integrations', 'es', 'Integraciones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (528, 'seller', 'sidebar.team', 'es', 'Equipo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (529, 'seller', 'sidebar.finance', 'es', 'Finanzas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (530, 'seller', 'dashboard.title', 'es', 'Panel', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (531, 'seller', 'dashboard.subtitle', 'es', 'Resumen de rendimiento, ventas y métricas del período.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (532, 'seller', 'dashboard.period', 'es', 'Per�odo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (533, 'seller', 'dashboard.hide_values', 'es', 'Ocultar valores', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (534, 'seller', 'dashboard.show_values', 'es', 'Mostrar valores', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (535, 'seller', 'dashboard.total_sales', 'es', 'Ventas totales', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (536, 'seller', 'dashboard.pending_sales', 'es', 'Ventas pendientes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (537, 'seller', 'dashboard.sales_count', 'es', 'Cantidad de ventas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (538, 'seller', 'dashboard.avg_ticket', 'es', 'Ticket medio', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (539, 'seller', 'dashboard.payment_methods', 'es', 'Métodos de pago', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (540, 'seller', 'dashboard.no_payments', 'es', 'Ningún pago en este período', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (541, 'seller', 'dashboard.conversion_rate', 'es', 'Tasa de conversión general', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (542, 'seller', 'dashboard.cart_abandonment', 'es', 'Abandono de carrito', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (543, 'seller', 'dashboard.refunds', 'es', 'Reembolsos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (544, 'seller', 'dashboard.orders_count', 'es', 'pedido(s)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (545, 'seller', 'dashboard.products', 'es', 'Productos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (546, 'seller', 'dashboard.sales_performance', 'es', 'Desempeño de ventas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (547, 'seller', 'dashboard.no_sales_data', 'es', 'No hay datos de ventas en este período', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (548, 'seller', 'period.today', 'es', 'Hoy', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (549, 'seller', 'period.yesterday', 'es', 'Ayer', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (550, 'seller', 'period.7days', 'es', '7 días', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (551, 'seller', 'period.month', 'es', 'Mes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (552, 'seller', 'period.year', 'es', 'Año', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (553, 'seller', 'period.total', 'es', 'Total', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (554, 'seller', 'sales.tab_sales', 'es', 'Ventas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (555, 'seller', 'sales.tab_subscriptions', 'es', 'Suscripciones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (556, 'seller', 'products.tab_products', 'es', 'Productos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (557, 'seller', 'products.tab_coupons', 'es', 'Cupones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (558, 'seller', 'products.tab_students', 'es', 'Alumnos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (559, 'seller', 'products.tab_coproduction', 'es', 'Coproducción', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (560, 'seller', 'products.tab_showcase', 'es', 'Vitrina', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (561, 'seller', 'products.tab_affiliates', 'es', 'Afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (562, 'seller', 'products.affiliates_page_title', 'es', 'Afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (563, 'seller', 'products.affiliates_page_subtitle', 'es', 'Productos en los que eres afiliado aprobado. Usa tu enlace exclusivo y configura tus píxeles de conversión.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (564, 'seller', 'products.affiliate_badge', 'es', 'Afiliado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (565, 'seller', 'products.affiliate_status_pending', 'es', 'Pendiente', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (566, 'seller', 'products.affiliate_status_approved', 'es', 'Aprobado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (567, 'seller', 'products.affiliate_panel', 'es', 'Panel del afiliado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (568, 'seller', 'products.affiliate_open_checkout', 'es', 'Abrir checkout', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (569, 'seller', 'products.affiliate_no_link', 'es', 'Enlace no disponible (configura el checkout del producto o espera la aprobación).', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (570, 'seller', 'products.affiliates_empty', 'es', 'Aún no tienes productos como afiliado.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (571, 'seller', 'products.affiliate_panel_title', 'es', 'Panel del afiliado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (572, 'seller', 'products.affiliate_panel_subtitle', 'es', 'Tu enlace de afiliación y píxeles usados en ventas con tu ref.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (573, 'seller', 'products.affiliate_link_section', 'es', 'Enlace de afiliación', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (574, 'seller', 'products.affiliate_copy_link', 'es', 'Copiar enlace', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (575, 'seller', 'products.affiliate_pix_hint', 'es', 'Configura tu clave PIX para recibir comisiones en Finanzas.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (576, 'seller', 'products.affiliate_pix_finance_link', 'es', 'Configurar PIX de retiro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (577, 'seller', 'products.affiliate_pixels_only_hint', 'es', 'Cuando la venta venga por tu enlace (?ref=), solo se usarán estos píxeles en el checkout y gracias — no los del productor.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (578, 'seller', 'products.coproduction_page_title', 'es', 'Coproducción', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (579, 'seller', 'products.coproduction_page_subtitle', 'es', 'Productos en los que eres coproductor e invitaciones pendientes de tu aprobación.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (580, 'seller', 'products.coproduction_section_pending', 'es', 'Pendientes de aprobación', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (581, 'seller', 'products.coproduction_section_active', 'es', 'Coproducciones activas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (582, 'seller', 'products.coproduction_by', 'es', 'Productor', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (583, 'seller', 'products.coproduction_accept', 'es', 'Aceptar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (584, 'seller', 'products.coproduction_details', 'es', 'Detalles', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (585, 'seller', 'products.coproduction_empty_pending', 'es', 'No hay invitaciones pendientes.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (586, 'seller', 'products.coproduction_empty_active', 'es', 'Aún no hay coproducciones activas.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (587, 'seller', 'products.coproduction_until', 'es', 'hasta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (588, 'seller', 'products.coproduction_view_checkout', 'es', 'Ver checkout', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (589, 'seller', 'integrations.title', 'es', 'Apps', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (590, 'seller', 'integrations.subtitle', 'es', 'Conecta tu plataforma con sistemas externos mediante webhooks y otras integraciones. Los gateways de pago se configuran en el panel de la plataforma (operador).', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (591, 'seller', 'integrations.webhook.description', 'es', 'Env�a eventos de la plataforma a tu URL. Configura qu� eventos quieres recibir y usa token Bearer para autenticaci�n.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (592, 'seller', 'integrations.utmify.description', 'es', 'Track sales and send events to UTMfy. It only requires the Clave API.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (593, 'seller', 'integrations.spedy.description', 'es', 'Emisi�n autom�tica de facturas. Env�a ventas a Spedy y emite NF-e/NFS-e.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (594, 'seller', 'integrations.cademi.description', 'es', '�rea de miembros externa. Tras la compra, sincroniza al alumno y otorga acceso en Cadem�.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (595, 'seller', 'users.title', 'es', 'Usuarios', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (596, 'seller', 'users.subtitle', 'es', 'Cuenta master e infoproductores de la plataforma.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (597, 'seller', 'users.tab_infoproducers', 'es', 'Infoproductores', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (598, 'seller', 'users.tab_team', 'es', 'Equipo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (599, 'seller', 'users.new_infoproducer', 'es', 'Nuevo infoproductor', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (600, 'seller', 'users.edit_user', 'es', 'Editar user', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (601, 'seller', 'users.delete_user', 'es', 'Eliminar user', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (602, 'seller', 'users.empty', 'es', 'No hay usuarios registrados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (603, 'seller', 'finance.request_withdrawal', 'es', 'Solicitar retiro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (604, 'seller', 'finance.available_balance', 'es', 'Saldo disponible', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (605, 'seller', 'finance.ready_for_withdrawal', 'es', 'Listo para retiro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (606, 'seller', 'finance.pending_receive', 'es', 'Por recibir', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (607, 'seller', 'finance.settling', 'es', 'En liquidaci�n', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (608, 'seller', 'finance.by_method', 'es', 'Por m�todo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (609, 'seller', 'finance.my_fees_and_payout', 'es', 'Mis tarifas y plazo de retiro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (610, 'seller', 'finance.by_payment_method', 'es', 'Por m�todo de pago', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (611, 'seller', 'finance.fee', 'es', 'Tarifa', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (612, 'seller', 'finance.payout_deadline', 'es', 'Plazo de retiro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (613, 'seller', 'finance.statement', 'es', 'Extracto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (614, 'seller', 'finance.bank_details', 'es', 'Datos bancarios', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (615, 'seller', 'finance.no_withdrawals', 'es', 'A�n no hay retiros', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (616, 'seller', 'finance.no_withdrawals_hint', 'es', 'Tus retiros solicitados aparecer�n aqu�.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (617, 'seller', 'finance.withdrawals', 'es', 'Retiros', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (618, 'seller', 'common.view', 'es', 'Ver', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (619, 'seller', 'common.hide', 'es', 'Ocultar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (620, 'seller', 'common.close', 'es', 'Cerrar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (621, 'seller', 'common.save', 'es', 'Guardar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (622, 'seller', 'common.cancel', 'es', 'Cancelar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (623, 'seller', 'common.name', 'es', 'Nombre', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (624, 'seller', 'common.email', 'es', 'Correo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (625, 'seller', 'common.password', 'es', 'Contraseña', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (626, 'seller', 'common.confirm_password', 'es', 'Confirmar contraseña', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (627, 'seller', 'team.roles', 'es', 'Roles', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (628, 'seller', 'team.members', 'es', 'Miembros', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (629, 'seller', 'team.logs', 'es', 'Registros', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (630, 'seller', 'team.new_role', 'es', 'Nuevo rol', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (631, 'seller', 'team.new_member', 'es', 'Nuevo miembro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (632, 'seller', 'team.clear_logs', 'es', 'Limpiar registros', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (633, 'seller', 'team.permissions', 'es', 'Permisos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (634, 'seller', 'team.products_count', 'es', 'producto(s)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (636, 'seller', 'team.remove_role', 'es', 'Eliminar rol', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (637, 'seller', 'team.no_roles', 'es', 'No hay roles creados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (638, 'seller', 'team.no_role', 'es', 'Sin rol', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (639, 'seller', 'team.edit_member', 'es', 'Editar member', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (640, 'seller', 'team.remove_member', 'es', 'Eliminar miembro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (641, 'seller', 'team.no_members', 'es', 'No hay miembros registrados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (642, 'seller', 'team.when', 'es', 'Cuándo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (643, 'seller', 'team.user', 'es', 'Usuario', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (644, 'seller', 'team.action', 'es', 'Acción', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (645, 'seller', 'team.no_logs', 'es', 'A�n no hay registros.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (646, 'seller', 'team.role_name', 'es', 'Nombre del rol', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (647, 'seller', 'team.allowed_products', 'es', 'Productos permitidos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (648, 'seller', 'team.allowed_products_hint', 'es', 'Affects all product modules (Panel, Ventas, Productos, etc.).', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (649, 'seller', 'team.role', 'es', 'Rol', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (650, 'seller', 'team.new_password_optional', 'es', 'Nueva contrase�a (opcional)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (651, 'seller', 'team.send_access_email', 'es', 'Enviar correo de acceso con usuario y contrase�a', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (652, 'seller', 'team.send_access_email_hint', 'es', 'El correo se enviar� a la direcci�n indicada arriba.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (653, 'seller', 'team.confirm_delete_role', 'es', '�Eliminar el rol "{name}"?', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (654, 'seller', 'team.confirm_delete_member', 'es', '�Eliminar a "{name}" del equipo?', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (655, 'seller', 'team.confirm_clear_logs', 'es', '�Limpiar todos los registros de auditor�a de este tenant?', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (656, 'seller', 'team.permission_email_marketing', 'es', 'Email Marketing', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (657, 'seller', 'team.permission_api_payments', 'es', 'API de Pagos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (658, 'seller', 'team.permission_settings', 'es', 'Configuración', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (659, 'seller', 'team.permission_manage_team', 'es', 'Gestionar equipo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (660, 'seller', 'products.edit.custom_script', 'es', 'Personalizado script', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (661, 'seller', 'products.edit.tab_general', 'es', 'General', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (662, 'seller', 'products.edit.tab_settings', 'es', 'Configuración', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (663, 'seller', 'products.edit.tab_email', 'es', 'Correo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (664, 'seller', 'products.edit.tab_links', 'es', 'Enlaces', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (665, 'seller', 'products.edit.tab_coproduction', 'es', 'Coproducci�n', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (666, 'seller', 'products.edit.coproduction_title', 'es', 'Invitar coproductor', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (667, 'seller', 'products.edit.coproduction_help', 'es', 'El invitado debe ser infoproductor. Recibirá un correo para aceptar. Las comisiones son sobre el valor bruto; las tarifas de la plataforma se aplican en la billetera de cada parte.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (668, 'seller', 'products.edit.tab_affiliates', 'es', 'Afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (669, 'seller', 'products.edit.affiliate_title', 'es', 'Programa de afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (670, 'seller', 'products.edit.affiliate_help', 'es', 'Comisiones sobre el valor bruto; las tarifas se aplican en la billetera de cada parte.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (671, 'seller', 'products.edit.affiliate_enable', 'es', 'Activar afiliación para este producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (672, 'seller', 'products.edit.affiliate_commission', 'es', 'Comisión del afiliado (%)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (673, 'seller', 'products.edit.affiliate_manual', 'es', 'Aprobar afiliaciones manualmente', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (674, 'seller', 'products.edit.affiliate_showcase', 'es', 'Mostrar en la vitrina', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (675, 'seller', 'products.edit.affiliate_page_url', 'es', 'Enlace de la página de afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (676, 'seller', 'products.edit.affiliate_support_email', 'es', 'Correo de soporte', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (677, 'seller', 'products.edit.affiliate_showcase_desc', 'es', 'Descripción (vitrina)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (678, 'seller', 'products.edit.affiliate_checkout_hint', 'es', 'Enlace base del checkout (añade ?ref= tras aprobar un afiliado)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (679, 'seller', 'products.edit.affiliate_enrollments', 'es', 'Afiliados y solicitudes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (680, 'seller', 'products.edit.affiliate_enrollments_hint', 'es', 'Todos los registros de este producto: pendientes, aprobados, rechazados y revocados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (681, 'seller', 'products.edit.affiliate_status_pending', 'es', 'Pendiente', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (682, 'seller', 'products.edit.affiliate_status_approved', 'es', 'Aprobado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (683, 'seller', 'products.edit.affiliate_status_rejected', 'es', 'Rechazado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (684, 'seller', 'products.edit.affiliate_status_revoked', 'es', 'Revocado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (685, 'seller', 'products.edit.affiliate_user_fallback', 'es', 'Usuario :id', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (686, 'seller', 'products.edit.affiliate_copy_link', 'es', 'Copiar enlace', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (687, 'seller', 'products.edit.affiliate_approve', 'es', 'Aprobar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (688, 'seller', 'products.edit.affiliate_reject', 'es', 'Rechazar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (689, 'seller', 'products.edit.affiliate_revoke', 'es', 'Revocar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (690, 'seller', 'products.edit.affiliate_empty', 'es', 'Ningún afiliado o solicitud aún.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (691, 'seller', 'products.showcase.title', 'es', 'Vitrina', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (692, 'seller', 'products.showcase.subtitle', 'es', 'Productos abiertos a afiliados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (693, 'seller', 'products.showcase.your_product_badge', 'es', 'Tu producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (694, 'seller', 'products.showcase.own_product_hint', 'es', 'Este es tu producto. Gestiona afiliados en la edición del producto.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (695, 'seller', 'products.showcase.edit_affiliate_settings', 'es', 'Abrir configuración de afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (696, 'seller', 'products.showcase.search', 'es', 'Buscar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (697, 'seller', 'products.showcase.category_all', 'es', 'Todas las categorías', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (698, 'seller', 'products.showcase.sort_hot', 'es', 'Más vendidos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (699, 'seller', 'products.showcase.sort_name', 'es', 'Nombre', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (700, 'seller', 'products.showcase.sort_price_asc', 'es', 'Menor precio', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (701, 'seller', 'products.showcase.sort_price_desc', 'es', 'Mayor precio', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (702, 'seller', 'products.showcase.section_hot', 'es', 'Más vendidos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (703, 'seller', 'products.showcase.you_receive', 'es', 'Recibes hasta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (704, 'seller', 'products.showcase.empty', 'es', 'Ningún producto con estos filtros.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (705, 'seller', 'products.showcase.affiliate_page', 'es', 'Página de afiliados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (706, 'seller', 'products.showcase.support', 'es', 'Soporte', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (707, 'seller', 'products.showcase.order_bump', 'es', 'Incluye order bump', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (708, 'seller', 'products.showcase.your_link', 'es', 'Tu enlace de afiliado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (709, 'seller', 'products.showcase.request', 'es', 'Solicitar afiliación', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (710, 'seller', 'products.showcase.pending', 'es', 'Esperando aprobación del productor.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (712, 'seller', 'products.edit.tab_order_bump', 'es', 'Order Bump', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (713, 'seller', 'products.edit.tab_upsell_downsell', 'es', 'Upsell / Downsell', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (714, 'seller', 'products.edit.tab_checkout', 'es', 'Checkout', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (715, 'seller', 'products.edit.tab_member_builder', 'es', 'Member Builder', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (716, 'seller', 'products.edit.basic_info', 'es', 'Informaci�n b�sica', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (717, 'seller', 'products.edit.basic_info_hint', 'es', 'Nombre, identificador e imagen del producto.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (718, 'seller', 'products.edit.product_name', 'es', 'Nombre del producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (719, 'seller', 'products.edit.slug_url', 'es', 'Slug (URL)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (720, 'seller', 'products.edit.slug_hint', 'es', 'Usado en URLs y �rea de miembros. Solo letras min�sculas, n�meros y guiones.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (721, 'seller', 'products.edit.product_image', 'es', 'Imagen del producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (722, 'seller', 'products.edit.change_image', 'es', 'Cambiar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (723, 'seller', 'products.edit.pricing_billing', 'es', 'Precio y cobro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (724, 'seller', 'products.edit.pricing_billing_hint', 'es', 'Define c�mo se cobrar� el producto y el valor base.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (725, 'seller', 'products.edit.base_price_brl', 'es', 'Precio base (BRL)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (726, 'seller', 'products.edit.recurrence', 'es', 'Recurrencia', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (727, 'seller', 'products.edit.extra_offers', 'es', 'Ofertas extra', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (728, 'seller', 'products.edit.subscription_plans', 'es', 'Planes de suscripci�n', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (729, 'seller', 'products.edit.extra_offers_hint', 'es', 'M�ltiples ofertas (precios). Cada una tiene su propio enlace de checkout.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (730, 'seller', 'products.edit.subscription_plans_hint', 'es', 'Crea planes (precio y periodicidad). Cada plan tiene su propio enlace de checkout.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (731, 'seller', 'products.edit.no_offer', 'es', 'No hay ofertas. Agrega una abajo o usa solo el precio base.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (732, 'seller', 'products.edit.edit_offer', 'es', 'Editar offer', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (733, 'seller', 'products.edit.new_offer', 'es', 'Nueva oferta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (734, 'seller', 'products.edit.add_offer', 'es', 'Agregar oferta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (735, 'seller', 'products.edit.no_plan', 'es', 'No hay plan. Agrega uno abajo.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (736, 'seller', 'products.edit.edit_plan', 'es', 'Editar plan', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (737, 'seller', 'products.edit.new_plan', 'es', 'Nuevo plan', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (738, 'seller', 'products.edit.add_plan', 'es', 'Agregar plan', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (739, 'seller', 'products.edit.save_changes', 'es', 'Guardar changes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (740, 'seller', 'products.edit.conversion_pixels', 'es', 'P�xeles de conversi�n', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (741, 'seller', 'products.edit.conversion_pixels_hint', 'es', 'Set up pixels to track conversións on checkout, upsell, and downsell.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (742, 'seller', 'products.edit.add_pixel', 'es', 'Agregar p�xel', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (743, 'seller', 'products.edit.no_pixels', 'es', 'Sin p�xeles. Haz clic en "Agregar p�xel" o desactiva la integraci�n.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (744, 'seller', 'products.edit.add_conversion', 'es', 'Add conversión', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (745, 'seller', 'products.edit.no_conversion', 'es', 'No conversión. Click "Add conversión" or disable the integration.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (746, 'seller', 'products.edit.add_property', 'es', 'Agregar propiedad', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (747, 'seller', 'products.edit.no_property', 'es', 'Sin propiedades. Haz clic en "Agregar propiedad" o desactiva la integraci�n.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (748, 'seller', 'products.edit.custom_scripts', 'es', 'Personalizado scripts', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (749, 'seller', 'products.edit.no_custom_script', 'es', 'No hay scripts agregados. Haz clic en "Agregar p�xel" para incluir un c�digo personalizado.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (750, 'seller', 'products.edit.access_email_template', 'es', 'Plantilla de correo de acceso', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (751, 'seller', 'products.edit.access_email_template_hint', 'es', 'Personalizadoize the email sent to the customer after purchase. Placeholders are replaced with real data.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (752, 'seller', 'products.edit.email_logo', 'es', 'Logo del correo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (753, 'seller', 'products.edit.click_to_change', 'es', 'Haz clic para cambiar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (754, 'seller', 'products.edit.click_to_upload', 'es', 'Haz clic para subir', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (755, 'seller', 'products.edit.sender_name_optional', 'es', 'Nombre del remitente (opcional)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (756, 'seller', 'products.edit.sender_name_hint', 'es', 'Si est� vac�o, usa el nombre de Configuraci�n general.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (757, 'seller', 'products.edit.email_subject', 'es', 'Asunto del correo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (758, 'seller', 'products.edit.email_body_html', 'es', 'Cuerpo del correo (HTML)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (759, 'seller', 'products.edit.email_preview', 'es', 'Vista previa del correo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (760, 'seller', 'products.edit.email_preview_hint', 'es', 'C�mo se mostrar� el correo al cliente.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (761, 'seller', 'products.edit.order_bump_hint', 'es', 'Oferta additional products on checkout so the customer can buy together. Choose product, title, description, and price.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (762, 'seller', 'products.edit.add_order_bump', 'es', 'Agregar order bump', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (763, 'seller', 'products.edit.no_order_bump', 'es', 'Sin order bump', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (764, 'seller', 'products.edit.no_order_bump_hint', 'es', 'Agrega productos que aparecer�n en checkout como oferta especial para comprar juntos.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (765, 'seller', 'products.interval.weekly', 'es', 'Semanal', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (766, 'seller', 'products.interval.monthly', 'es', 'Mensual', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (767, 'seller', 'products.interval.quarterly', 'es', 'Trimestral', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (768, 'seller', 'products.interval.semi_annual', 'es', 'Semestral', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (769, 'seller', 'products.interval.annual', 'es', 'Anual', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (770, 'seller', 'products.interval.lifetime', 'es', 'Vitalicio', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (771, 'seller', 'checkout_builder.edit_checkout', 'es', 'Editar checkout', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (772, 'seller', 'checkout_builder.tab_general', 'es', 'General', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (773, 'seller', 'checkout_builder.tab_features', 'es', 'Recursos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (774, 'seller', 'checkout_builder.tab_template', 'es', 'Plantilla', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (775, 'seller', 'checkout_builder.tab_social', 'es', 'Social', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (776, 'seller', 'checkout_builder.price_discount', 'es', 'Precio / Descuento', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (777, 'seller', 'checkout_builder.form_fields', 'es', 'Campos del formulario', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (778, 'seller', 'sales.subtitle', 'es', 'Sigue pedidos, estado de pagos y desempeño comercial.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (779, 'seller', 'products.subtitle', 'es', 'Gestiona tus productos, ofertas y accesos de checkout.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (780, 'seller', 'reports.subtitle', 'es', 'Analiza resultados, ingresos e indicadores del negocio.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (781, 'seller', 'finance.subtitle', 'es', 'Saldos, extracto y datos de cobro.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (782, 'seller', 'team.title', 'es', 'Usuarios', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (783, 'seller', 'team.subtitle', 'es', 'Gestiona equipo y permisos.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (784, 'seller', 'settings.languages.tab', 'es', 'Idiomas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (785, 'seller', 'settings.languages.title', 'es', 'Idiomas de la plataforma', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (786, 'seller', 'settings.languages.subtitle', 'es', 'Gestiona idiomas y traducciones del panel de infoproductor.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (787, 'seller', 'settings.languages.add', 'es', 'Agregar idioma', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (788, 'seller', 'settings.languages.default', 'es', 'Predeterminado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (789, 'seller', 'settings.languages.active', 'es', 'Activo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (790, 'seller', 'settings.languages.search', 'es', 'Buscar clave de traducción...', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (791, 'seller', 'settings.languages.save', 'es', 'Guardar traducciones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (792, 'seller', 'settings.languages.import_missing', 'es', 'Importar claves faltantes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (793, 'seller', 'common.image', 'es', 'Imagen', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (794, 'seller', 'common.description', 'es', 'Descripci�n', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (795, 'seller', 'common.active', 'es', 'Activo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (796, 'seller', 'common.inactive', 'es', 'Inactivo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (797, 'seller', 'common.edit', 'es', 'Editar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (798, 'seller', 'common.delete', 'es', 'Eliminar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (799, 'seller', 'common.loading', 'es', 'Cargando...', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (800, 'seller', 'common.error', 'es', 'Error', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (801, 'seller', 'common.send', 'es', 'Enviar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (802, 'seller', 'common.sending', 'es', 'Enviando...', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (803, 'seller', 'common.saving', 'es', 'Guardando...', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (804, 'seller', 'common.back', 'es', 'Volver', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (805, 'seller', 'common.open_menu', 'es', 'Abrir menú', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (806, 'seller', 'common.pagination', 'es', 'Paginación', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (807, 'seller', 'common.date', 'es', 'Fecha', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (808, 'seller', 'common.from', 'es', 'Desde', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (809, 'seller', 'common.to', 'es', 'Hasta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (810, 'seller', 'common.optional', 'es', 'opcional', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (811, 'seller', 'common.test', 'es', 'Probar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (812, 'seller', 'common.delete_question', 'es', '¿Eliminar?', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (813, 'seller', 'common.deleting', 'es', 'Eliminando...', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (814, 'seller', 'common.coming_soon', 'es', 'Próximamente', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (815, 'seller', 'common.back_to_list', 'es', 'Volver a la lista', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (816, 'seller', 'common.leave_blank_keep', 'es', 'Dejar en blanco para conservar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (817, 'seller', 'common.leave_blank_keep_current', 'es', 'Dejar en blanco para conservar el actual', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (818, 'seller', 'common.all', 'es', 'Todos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (819, 'seller', 'common.yes', 'es', 'Sí', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (820, 'seller', 'common.no', 'es', 'No', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (821, 'seller', 'common.import', 'es', 'Importar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (822, 'seller', 'sales.filter.approved', 'es', 'Aprobadas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (823, 'seller', 'sales.filter.all_female', 'es', 'Todos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (824, 'seller', 'sales.period.all', 'es', 'Todo el período', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (825, 'seller', 'sales.period.last_7_days', 'es', 'Last 7 días', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (826, 'seller', 'sales.period.last_30_days', 'es', 'Últimos 30 días', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (827, 'seller', 'sales.period.this_month', 'es', 'Este mes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (828, 'seller', 'sales.period.last_month', 'es', 'Mes pasado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (829, 'seller', 'sales.period.custom', 'es', 'Personalizado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (830, 'seller', 'sales.payment_method.all', 'es', 'Todos los métodos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (831, 'seller', 'sales.payment_method.card', 'es', 'Tarjeta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (832, 'seller', 'sales.status', 'es', 'Estado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (833, 'seller', 'sales.status.all', 'es', 'Todos los estados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (834, 'seller', 'sales.status.paid', 'es', 'Pagado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (835, 'seller', 'sales.status.pending', 'es', 'Pendiente', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (836, 'seller', 'sales.status.cancelled', 'es', 'Cancelado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (837, 'seller', 'sales.status.refunded', 'es', 'Reembolsado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (838, 'seller', 'sales.metrics.found_sales', 'es', 'Ventas encontradas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (839, 'seller', 'sales.metrics.net_amount', 'es', 'Valor neto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (840, 'seller', 'sales.metrics.pix_sales', 'es', 'Ventas en PIX', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (841, 'seller', 'sales.metrics.card_sales', 'es', 'Ventas con tarjeta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (842, 'seller', 'sales.export.csv', 'es', 'Exportar CSV', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (843, 'seller', 'sales.export.xls', 'es', 'Exportar XLS', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (844, 'seller', 'sales.search_placeholder', 'es', 'Buscar por cliente, correo, pedido, producto...', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (845, 'seller', 'sales.clear_search', 'es', 'Limpiar búsqueda', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (846, 'seller', 'sales.clear_filters', 'es', 'Limpiar filtros', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (847, 'seller', 'sales.products.all', 'es', 'Todos los productos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (848, 'seller', 'sales.offer', 'es', 'Oferta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (849, 'seller', 'sales.offers.all', 'es', 'Todas las ofertas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (850, 'seller', 'sales.method', 'es', 'Método', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (851, 'seller', 'sales.show_advanced_filters', 'es', 'Mostrar filtros avanzados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (852, 'seller', 'sales.hide_advanced_filters', 'es', 'Ocultar filtros avanzados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (853, 'seller', 'sales.customer', 'es', 'Personalizadoer', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (854, 'seller', 'sales.empty', 'es', 'No se encontraron ventas.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (855, 'seller', 'sales.actions', 'es', 'Acciones de venta', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (856, 'seller', 'sales.details', 'es', 'Detalles', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (857, 'seller', 'sales.resend_purchase_email', 'es', 'Reenviar correo de compra', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (858, 'seller', 'sales.resend_unavailable_pending', 'es', 'No disponible para pagos pendientes', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (859, 'seller', 'sales.toast.email_resent_success', 'es', 'Correo de compra reenviado con éxito.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (860, 'seller', 'sales.toast.email_resent_fail', 'es', 'No se pudo reenviar el correo.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (861, 'seller', 'sales.toast.email_resent_error', 'es', 'Error al reenviar el correo. Intenta nuevamente.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (862, 'seller', 'products.create.new_product', 'es', 'Nuevo producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (863, 'seller', 'products.create.create_product', 'es', 'Crear producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (864, 'seller', 'products.create.choose_delivery_type', 'es', 'Elige el tipo de entrega del producto.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (865, 'seller', 'products.create.back_to_type', 'es', '← Volver to type', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (866, 'seller', 'products.create.name_placeholder', 'es', 'Ej: Curso de Desarrollo Web', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (867, 'seller', 'products.create.billing_type', 'es', 'Tipo de cobro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (868, 'seller', 'products.create.description_placeholder', 'es', 'Breve descripción del producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (869, 'seller', 'products.create.deliverable_link', 'es', 'Enlace de entrega', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (870, 'seller', 'products.create.deliverable_link_hint', 'es', 'Enviado por correo tras la compra.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (871, 'seller', 'products.create.price_brl', 'es', 'Precio (BRL)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (872, 'seller', 'products.create.image_hint', 'es', 'Se muestra en formato cuadrado (1:1). Recomendamos subir una imagen cuadrada.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (873, 'seller', 'products.create.active_product', 'es', 'Producto activo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (874, 'seller', 'products.empty', 'es', 'No hay productos registrados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (875, 'seller', 'integrations.new', 'es', 'Nueva integración', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (876, 'seller', 'integrations.edit', 'es', 'Editar integración', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (877, 'seller', 'integrations.empty', 'es', 'No integration configured. Click "Nueva integración" to start.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (878, 'seller', 'integrations.error_name', 'es', 'Ingresa el nombre de la integraci�n.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (879, 'seller', 'integrations.error_api_key', 'es', 'Enter the Clave API.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (880, 'seller', 'integrations.error_api_key_create', 'es', 'Enter the Clave API when creating an integration.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (881, 'seller', 'integrations.error_save', 'es', 'Error al guardar la integración.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (882, 'seller', 'integrations.error_delete', 'es', 'Error al eliminar la integración.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (883, 'seller', 'integrations.all_products', 'es', 'Todos los productos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (884, 'seller', 'integrations.key_configured', 'es', 'Clave configurada', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (885, 'seller', 'integrations.key_not_configured', 'es', 'Clave no configurada', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (886, 'seller', 'integrations.integration_name', 'es', 'Nombre de la integración', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (887, 'seller', 'integrations.api_key', 'es', 'Clave API', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (888, 'seller', 'integrations.api_key_placeholder', 'es', 'Ingresa la clave', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (889, 'seller', 'integrations.active_integration', 'es', 'Activo integration', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (890, 'seller', 'integrations.assigned_products', 'es', 'Productos asignados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (891, 'seller', 'integrations.assigned_products_hint', 'es', 'Selecciona productos para los que esta integraci�n enviar� eventos. D�jalo vac�o para todos.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (892, 'seller', 'integrations.configure_in_product', 'es', 'Configurar en producto', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (893, 'seller', 'integrations.optional_leave_all', 'es', 'opcional - dejar vac�o para todos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (894, 'seller', 'integrations.webhook.title', 'es', 'Webhooks', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (895, 'seller', 'integrations.webhook.new', 'es', 'Nuevo webhook', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (896, 'seller', 'integrations.webhook.configured', 'es', 'Webhooks configurados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (897, 'seller', 'integrations.webhook.events_count', 'es', 'evento(s)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (898, 'seller', 'integrations.webhook.products_count', 'es', 'producto(s)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (899, 'seller', 'integrations.webhook.last_deliveries', 'es', '�ltimos env�os', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (900, 'seller', 'integrations.webhook.no_deliveries', 'es', 'No hay env�os registrados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (901, 'seller', 'integrations.webhook.empty', 'es', 'No hay webhook configurado. Haz clic en "Nuevo webhook" para crear uno.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (902, 'seller', 'integrations.webhook.edit', 'es', 'Editar webhook', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (903, 'seller', 'integrations.webhook.bearer_token', 'es', 'Token Bearer', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (904, 'seller', 'integrations.webhook.auth_token', 'es', 'Token de autenticaci�n', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (905, 'seller', 'integrations.webhook.token_security_hint', 'es', 'Por seguridad, el valor del token guardado no se muestra en este campo.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (906, 'seller', 'integrations.webhook.token_already_saved', 'es', 'El token ya est� guardado. Deja en blanco para mantenerlo.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (907, 'seller', 'integrations.webhook.events', 'es', 'Eventoos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (908, 'seller', 'integrations.webhook.send_test_event', 'es', 'Enviar evento de prueba', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (909, 'seller', 'integrations.webhook.event', 'es', 'Evento', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (910, 'seller', 'integrations.webhook.trigger_test', 'es', 'Disparar evento de prueba', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (911, 'seller', 'integrations.webhook.error_name', 'es', 'Ingresa el nombre del webhook.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (912, 'seller', 'integrations.webhook.error_url', 'es', 'Ingresa la URL del webhook.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (913, 'seller', 'integrations.webhook.error_event', 'es', 'Selecciona al menos un evento.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (914, 'seller', 'integrations.webhook.test_success', 'es', 'Evento sent successfully!', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (915, 'seller', 'integrations.webhook.test_fail', 'es', 'Fall� el env�o.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (916, 'seller', 'integrations.webhook.test_error', 'es', 'Error al disparar evento de prueba.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (917, 'seller', 'integrations.cademi.base_url', 'es', 'URL base', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (918, 'seller', 'integrations.cademi.postback_token', 'es', 'Token de postback', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (919, 'seller', 'integrations.cademi.error_base_url', 'es', 'Ingresa la URL base (ej.: https://tu-subdominio.cademi.com.br).', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (920, 'seller', 'integrations.cademi.error_postback_token', 'es', 'Ingresa el token de postback.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (921, 'seller', 'integrations.cademi.delete_confirm', 'es', '�Seguro que deseas eliminar esta integraci�n Cadem�?', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (922, 'seller', 'integrations.spedy.environment', 'es', 'Entorno', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (923, 'seller', 'integrations.spedy.production', 'es', 'Producción', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (924, 'seller', 'integrations.spedy.sandbox', 'es', 'Sandbox (pruebas)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (925, 'seller', 'integrations.spedy.delete_confirm', 'es', '�Seguro que deseas eliminar esta integraci�n Spedy? La emisi�n autom�tica de facturas se desactivar� para productos vinculados.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (926, 'seller', 'integrations.utmify.delete_confirm', 'es', 'Are you sure you want to delete this UTMfy integration? Eventoos will stop being sent.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (927, 'seller', 'reports.total_revenue', 'es', 'Ingresos totales', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (928, 'seller', 'reports.abandoned_sales', 'es', 'Ventas abandonadas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (929, 'seller', 'reports.rate', 'es', 'Tasa', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (930, 'seller', 'reports.conversion', 'es', 'conversión', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (931, 'seller', 'subscriptions.active', 'es', 'Suscripciones activas', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (932, 'seller', 'subscriptions.plan', 'es', 'Plan', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (933, 'seller', 'subscriptions.renews_on', 'es', 'Renueva en', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (934, 'seller', 'subscriptions.product_plan', 'es', 'Producto / Plan', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (935, 'seller', 'subscriptions.list_hint', 'es', 'Lista de suscripciones activas. Los recordatorios de renovaci�n se env�an por correo antes del vencimiento.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (936, 'seller', 'subscriptions.empty', 'es', 'Aún no hay suscripciones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (937, 'seller', 'subscriptions.empty_hint', 'es', 'Productos configured as "Subscription" with plans will appear here when there are active subscribers.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (938, 'seller', 'subscriptions.status.active', 'es', 'Activo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (939, 'seller', 'subscriptions.status.past_due', 'es', 'En atraso', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (940, 'seller', 'subscriptions.status.cancelled', 'es', 'Cancelado', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (941, 'seller', 'coupons.new', 'es', 'Nuevo cupón', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (942, 'seller', 'coupons.code', 'es', 'Código', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (943, 'seller', 'coupons.type', 'es', 'Tipo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (944, 'seller', 'coupons.value', 'es', 'Valor', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (945, 'seller', 'coupons.uses', 'es', 'Usos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (946, 'seller', 'coupons.validity', 'es', 'Validez', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (947, 'seller', 'coupons.type_percent', 'es', 'Porcentaje', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (948, 'seller', 'coupons.type_fixed', 'es', 'Fijo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (949, 'seller', 'coupons.edit', 'es', 'Editar cupón', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (950, 'seller', 'coupons.delete', 'es', 'Eliminar cupón', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (951, 'seller', 'coupons.empty', 'es', 'Aún no hay cupones.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (952, 'seller', 'coupons.create_first', 'es', 'Crear primer cupón', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (953, 'seller', 'coupons.delete_title', 'es', 'Eliminar cupón?', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (954, 'seller', 'coupons.delete_confirm', 'es', '�Seguro que deseas eliminar el cup�n', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (955, 'seller', 'students.filter', 'es', 'Filtrar alumnos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (956, 'seller', 'students.total', 'es', 'Total de alumnos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (957, 'seller', 'students.total_enrollments', 'es', 'Total de inscripciones', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (958, 'seller', 'students.products_with_students', 'es', 'Productos con alumnos', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (959, 'seller', 'students.new_30_days', 'es', 'Nuevos (30 días)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (960, 'seller', 'students.search_placeholder', 'es', 'Buscar alumno por nombre o correo...', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (961, 'seller', 'students.remove_filter', 'es', 'Quitar filtro', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (962, 'seller', 'students.new_student', 'es', 'Nuevo alumno', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (963, 'seller', 'students.empty', 'es', 'Aún no hay alumnos con acceso.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (964, 'seller', 'students.name_placeholder', 'es', 'Nombre del alumno', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (965, 'seller', 'students.send_access_email_create', 'es', 'Enviar correo de acceso al crear', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (966, 'seller', 'students.products_access_optional', 'es', 'Productos with access (optional)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (967, 'seller', 'students.no_products_available', 'es', 'No hay productos disponibles', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (968, 'seller', 'students.register', 'es', 'Registrar', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (969, 'seller', 'students.new.required_fields', 'es', 'Completa nombre, correo y contrase�a.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (970, 'seller', 'students.new.success', 'es', 'Alumno registrado con �xito.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (971, 'seller', 'students.new.error', 'es', 'Error al registrar alumno. Intenta nuevamente.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (972, 'seller', 'students.import.title', 'es', 'Importar alumnos en lote', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (973, 'seller', 'students.import.hint', 'es', 'Upload a Archivo CSV with columns: name, email, password (optional). Use ; or , as separator.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (974, 'seller', 'students.import.download_example', 'es', 'Descargar CSV de ejemplo', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (975, 'seller', 'students.import.csv_file', 'es', 'Archivo CSV', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (976, 'seller', 'students.import.send_access_email', 'es', 'Enviar correo de acceso a los importados', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (977, 'seller', 'students.import.products_required', 'es', 'Productos to grant access (required)', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (978, 'seller', 'students.import.select_csv', 'es', 'Select a Archivo CSV.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (979, 'seller', 'students.import.select_product', 'es', 'Selecciona al menos un producto para dar acceso.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (980, 'seller', 'students.import.done', 'es', 'Importación finalizada.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (981, 'seller', 'students.import.error', 'es', 'Error de importaci�n. Revisa el formato del CSV.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');
INSERT INTO public.platform_translations VALUES (982, 'seller', 'common.irreversible_action', 'es', 'Esta acción no se puede deshacer.', '2026-04-30 14:37:55', '2026-04-30 14:37:55');


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_affiliate_enrollments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_coproducers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_offers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_order_bumps; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_user; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.product_user VALUES (1, 5, '2026-04-30 18:05:03', '2026-04-30 18:05:03', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');
INSERT INTO public.product_user VALUES (2, 6, '2026-04-30 18:22:05', '2026-04-30 18:22:05', '45d8e4f6-1be9-4499-a71e-a57e2309cd62');


--
-- Data for Name: product_webhook; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.products VALUES (4, 'Curso de desenvolvimento C#', 'curso-de-desenvolvimento-c', 'básico', 'area_membros', 2.50, true, '2026-04-30 16:02:42', '2026-04-30 18:56:36', 'products/3jFdDKzV9ABvydaHJmv3KBG4auBy2kbiUmfvhocG.jpg', 'BRL', 'one_time', 'oenmpop', '{"summary":{"previous_price":null,"discount_text":null,"show_description":true},"appearance":{"background_color":"#E3E3E3","primary_color":"#0ea5e9","banners":[],"side_banners":[],"order_bump_color":"#F59E0B"},"timer":{"enabled":false,"text":"Esta oferta expira em:","minutes":15,"background_color":"#000000","text_color":"#FFFFFF","sticky":true},"sales_notification":{"enabled":false,"title":"acabou de comprar","names_per_line":1,"names":null,"product_label":"Curso de desenvolvimento C#","display_seconds":5,"interval_seconds":10},"template":"original","youtube_url":null,"redirect_after_purchase":"https:\/\/web.winfy.com.br\/checkout\/obrigado","back_redirect":{"enabled":true,"url":"https:\/\/web.winfy.com.br\/"},"customer_fields":{"name":true,"cpf":true,"phone":true,"coupon":false},"card_installments":{"enabled":false,"max":1},"payment_methods_enabled":{"pix":true,"card":true,"boleto":false,"pix_auto":false},"stripe_link_enabled":true,"deliverable_link":"","seo":{"title":null,"description":null,"og_image":null,"favicon":null},"support_button":{"enabled":true,"text":"Suporte","icon":"whatsapp","position":"bottom-right","url":null,"color":"#25D366"},"footer":{"enabled":false,"logo_url":null,"support_email":null,"text":null},"exit_popup":{"enabled":false,"triggers":{"back_button":true,"tab_switch":true,"mouse_leave_top":false,"timer_seconds":null},"coupon_id":null,"image":null,"frequency_per_session":1,"title":"Espere! Temos um desconto para voc\u00ea","description":"Use o cupom abaixo na pr\u00f3xima etapa","button_accept":"Quero o desconto","button_decline":"N\u00e3o, obrigado"},"reviews":[],"upsell":{"enabled":false,"products":[],"page":{"headline":"Quer levar isso tamb\u00e9m?","subheadline":"Uma oferta exclusiva preparada para voc\u00ea","body_text":null,"hero_image":null,"hero_video_url":null,"background_color":"#f3f4f6","background_image":null,"show_product_just_bought":true},"appearance":{"title":"Quer levar isso tamb\u00e9m?","subtitle":"Uma oferta exclusiva preparada para voc\u00ea","primary_color":"#0ea5e9","button_accept":"Sim, quero aproveitar","button_decline":"N\u00e3o, obrigado"}},"downsell":{"enabled":false,"product_id":null,"product_offer_id":null,"page":{"headline":"\u00daltima chance com desconto","subheadline":"Uma oferta que n\u00e3o pode ficar de fora","body_text":null,"hero_image":null,"hero_video_url":null,"background_color":"#f3f4f6","background_image":null,"show_product_just_bought":true},"appearance":{"title":"\u00daltima chance com desconto","subtitle":"Uma oferta que n\u00e3o pode ficar de fora","primary_color":"#0ea5e9","button_accept":"Aceitar oferta","button_decline":"N\u00e3o, obrigado"}},"email_template":{"logo_url":null,"from_name":null,"subject":"Seu acesso a {nome_produto}","body_html":"<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"max-width:600px;margin:0 auto;font-family:''Segoe UI'',Tahoma,sans-serif;background:#f8fafc;padding:32px 24px;\"><tr><td style=\"background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.08);\"><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"><tr><td style=\"padding:32px 32px 24px;text-align:center;border-bottom:1px solid #e2e8f0;\"><h1 style=\"margin:0;font-size:22px;font-weight:600;color:#0f172a;\">Ol\u00e1, {nome_cliente}!<\/h1><\/td><\/tr><tr><td style=\"padding:28px 32px;\"><p style=\"margin:0 0 16px;font-size:16px;line-height:1.6;color:#334155;\">Obrigado por adquirir <strong>{nome_produto}<\/strong>.<\/p><p style=\"margin:0 0 24px;font-size:16px;line-height:1.6;color:#334155;\">Clique no bot\u00e3o abaixo para acessar seu conte\u00fado agora:<\/p><p style=\"margin:0 0 24px;text-align:center;\"><a href=\"{link_acesso}\" style=\"display:inline-block;padding:14px 32px;background:#0ea5e9;color:#ffffff;text-decoration:none;font-weight:600;font-size:16px;border-radius:8px;\">Acessar agora<\/a><\/p><p style=\"margin:0 0 24px;font-size:14px;line-height:1.5;color:#64748b;\">Ou copie e cole no navegador:<br\/><a href=\"{link_acesso}\" style=\"color:#0ea5e9;word-break:break-all;\">{link_acesso}<\/a><\/p><div style=\"margin:28px 0 0;padding:20px;background:#fffbeb;border:1px solid #f59e0b;border-radius:8px;\"><p style=\"margin:0 0 10px;font-size:14px;line-height:1.5;color:#92400e;\"><strong>Guarde seus dados de acesso<\/strong><\/p><p style=\"margin:0 0 16px;font-size:14px;line-height:1.5;color:#78350f;\">O bot\u00e3o acima entra automaticamente na sua conta. Se voc\u00ea sair ou usar outro aparelho, fa\u00e7a login na \u00e1rea de membros com:<\/p><p style=\"margin:0 0 10px;font-size:14px;color:#0f172a;\"><strong>E-mail:<\/strong> {email_cliente}<\/p><p style=\"margin:0;font-size:15px;color:#0f172a;font-family:Consolas,''Courier New'',monospace;font-weight:600;letter-spacing:0.02em;word-break:break-all;\"><strong>Senha:<\/strong> {senha}<\/p><\/div><\/td><\/tr><tr><td style=\"padding:20px 32px;background:#f1f5f9;border-radius:0 0 12px 12px;\"><p style=\"margin:0;font-size:13px;color:#64748b;\">Qualquer d\u00favida, responda este e-mail.<\/p><\/td><\/tr><\/table><\/td><\/tr><\/table>"},"youtube_position":"top"}', '{"theme":{"primary":"#0ea5e9","background":"#18181b","sidebar_bg":"#27272a","text":"#f8fafc","accent":"#38bdf8"},"hero":{"image_url":null,"image_url_desktop":null,"image_url_mobile":null,"title":null,"subtitle":null,"overlay":true},"header":{"logo_url":null},"logos":{"logo_light":null,"logo_dark":null,"favicon":null},"sidebar":{"collapsible":true,"items":[{"title":"In\u00edcio","icon":"home","link":"\/","open_external":false}]},"login":{"logo":null,"background_image":null,"background_color":"#18181b","primary_color":"#0ea5e9","title":"\u00c1rea de Membros","subtitle":"Entre com seu e-mail e senha","password_mode":"auto","default_password":null,"login_without_password":false},"pwa":{"name":null,"short_name":null,"theme_color":"#0ea5e9","push_enabled":false},"certificate":{"enabled":true,"title":null,"completion_percent":100,"template_url":null,"signature_text":"Jader Brand\u00e3o","font_family":"sans-serif","duration_text":"40","platform_name":"Winfy","primary_color":null,"background_image_url":null,"background_overlay_enabled":false,"background_overlay_color":"#000000","background_overlay_opacity":50,"text_color":null,"title_color":null,"signature_font_family":"Dancing Script","print_format":"A4"},"comments_enabled":true,"comments_require_approval":true,"gamification":{"enabled":false,"achievements":[]},"community_enabled":false,"community_users_can_delete_own_posts":true}', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"meta":{"enabled":false,"entries":[]},"tiktok":{"enabled":false,"entries":[]},"google_ads":{"enabled":false,"entries":[]},"google_analytics":{"enabled":false,"entries":[]},"custom_script":[]}', false, 0.00, true, false, NULL, NULL, NULL, 7);


--
-- Data for Name: refund_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sales_achievements; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sales_achievements VALUES (1, 'filhote', 'Filhote', 10000.00, 'https://cdn.getfy.cloud/conquistas/10k.png', 1, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');
INSERT INTO public.sales_achievements VALUES (2, 'jacare-cacador', 'Jacaré Caçador', 50000.00, 'https://cdn.getfy.cloud/conquistas/50k.png', 2, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');
INSERT INTO public.sales_achievements VALUES (3, 'predador', 'Predador', 100000.00, 'https://cdn.getfy.cloud/conquistas/100K.png', 3, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');
INSERT INTO public.sales_achievements VALUES (4, 'alpha-pantano', 'Alpha do Pântano', 500000.00, 'https://cdn.getfy.cloud/conquistas/500K.png', 4, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');
INSERT INTO public.sales_achievements VALUES (5, 'rei-pantano', 'Rei do Pântano', 1000000.00, 'https://cdn.getfy.cloud/conquistas/1M.png', 5, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');
INSERT INTO public.sales_achievements VALUES (6, 'lenda-getfy', 'Lenda da gatewayLab', 5000000.00, 'https://cdn.getfy.cloud/conquistas/5M.png', 6, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');
INSERT INTO public.sales_achievements VALUES (7, 'imperador-predador', 'Imperador Predador', 10000000.00, 'https://cdn.getfy.cloud/conquistas/10M.png', 7, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');
INSERT INTO public.sales_achievements VALUES (8, 'jacare-supremo', 'Jacaré Supremo', 25000000.00, 'https://cdn.getfy.cloud/conquistas/25M.png', 8, true, '2026-04-30 14:11:55', '2026-04-30 14:11:55');


--
-- Data for Name: saved_payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.settings VALUES (1, NULL, 'smtp_password', 'eyJpdiI6IkN0TktkVjEyQVR4akVLUmtsQi9FYmc9PSIsInZhbHVlIjoiNm9ZcFlSNDVPQnR4L3E3SVNvU3UxbzFnUjkvTnowc1R5QnhpQkYrRFBwWT0iLCJtYWMiOiIzY2NkYjY2ZmM0ZWYxMjJmMGJjMTQ4OTJmNzRiN2ZjMWVkOWM1OTQzMmUwMzQ2MDI2OTFjN2RlMjE5MzBkMjJmIiwidGFnIjoiIn0=', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (3, NULL, 'mail_from_address', 'noreply@getfy.com', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (4, NULL, 'mail_from_name', 'winfy', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (5, NULL, 'reply_to', '', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (6, NULL, 'smtp_host', 'smtp.kinghost.net', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (7, NULL, 'smtp_port', '587', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (8, NULL, 'smtp_username', 'contato@winfy.com.br', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (9, NULL, 'smtp_encryption', 'tls', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (10, NULL, 'hostinger_smtp_username', '', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (11, NULL, 'hostinger_mail_from_address', '', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (12, NULL, 'hostinger_mail_from_name', '', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (13, NULL, 'hostinger_reply_to', '', '2026-04-30 14:54:16', '2026-04-30 14:54:16');
INSERT INTO public.settings VALUES (17, NULL, 'checkout_translations', '{"pt_BR":{"checkout.seus_dados":"Seus dados","checkout.name":"Nome","checkout.email":"E-mail","checkout.phone":"Telefone","checkout.cpf":"CPF","checkout.coupon_label":"Cupom de desconto","checkout.coupon_placeholder":"C\u00f3digo do cupom","checkout.submit_button":"Concluir compra","checkout.processing":"Processando\u2026","checkout.name_placeholder":"Como quer ser chamado","checkout.email_placeholder":"seu@email.com","checkout.phone_placeholder_br":"(11) 99999-9999","checkout.phone_placeholder_other":"N\u00famero","checkout.cpf_placeholder":"000.000.000-00","checkout.country_code_label":"C\u00f3digo do pa\u00eds","checkout.summary_title":"Resumo da compra","checkout.discount_coupon":"Desconto (cupom)","checkout.total":"Total","checkout.secure_purchase":"Compra 100% segura","checkout.voce_pode_gostar":"Voc\u00ea pode gostar","checkout.voce_pode_gostar_subtitle":"Adicione estes itens \u00e0 sua compra","checkout.deselect_all":"Desmarcar todos","checkout.oferta_especial":"Oferta especial","checkout.total_a_pagar":"Total a pagar","checkout.ver_mais":"Ver mais","checkout.ver_menos":"Ver menos","checkout.timer_text":"Esta oferta expira em:","checkout.validating_coupon":"Validando cupom\u2026","checkout.forma_pagamento":"Forma de pagamento","checkout.gerar_pix":"Gerar PIX","checkout.gerar_pix_auto":"Gerar PIX Autom\u00e1tico","checkout.pix_auto":"PIX autom\u00e1tico","checkout.gerar_boleto":"Gerar boleto","checkout.corrija_erros":"Corrija os erros abaixo antes de continuar.","checkout.preencher_dados_gerar_pix":"Preencha seus dados acima e clique em \"Gerar PIX\".","checkout.preencher_dados_gerar_boleto":"Preencha seus dados acima e clique em \"Gerar boleto\".","checkout.preencher_e_gerar_pix":"Preencha nome, e-mail e CPF (se solicitado) e clique em \"Gerar PIX\" abaixo.","checkout.preencher_e_gerar_boleto":"Preencha nome, e-mail e CPF (se solicitado) e clique em \"Gerar boleto\" abaixo.","checkout.editar_dados":"Editar dados","checkout.dados_cartao":"Dados do cart\u00e3o","checkout.card_holder":"Nome no cart\u00e3o","checkout.card_holder_placeholder":"Como est\u00e1 impresso no cart\u00e3o","checkout.card_number":"N\u00famero do cart\u00e3o","checkout.card_number_placeholder":"0000 0000 0000 0000","checkout.card_exp":"Validade (MM\/AA)","checkout.card_exp_placeholder":"MM\/AAAA","checkout.card_cvv":"CVV","checkout.card_cvv_placeholder":"123","checkout.card_cvv_help":"3 ou 4 d\u00edgitos no verso do cart\u00e3o","checkout.pagar_cartao":"Pagar com cart\u00e3o","checkout.card_not_configured":"Pagamento por cart\u00e3o n\u00e3o est\u00e1 configurado.","checkout.card_fill_all":"Preencha todos os dados do cart\u00e3o corretamente.","checkout.installments":"N\u00famero de parcelas","checkout.endereco_boleto":"Endere\u00e7o para o boleto","checkout.endereco_boleto_cep":"CEP","checkout.endereco_boleto_buscar":"Buscar","checkout.endereco_boleto_numero":"N\u00famero","exit_popup.title":"Espere! Temos um desconto para voc\u00ea","exit_popup.description":"Use o cupom abaixo na pr\u00f3xima etapa","exit_popup.button_accept":"Quero o desconto","exit_popup.button_decline":"N\u00e3o, obrigado","exit_popup.close":"Fechar","exit_popup.coupon_label":"Seu cupom"},"en":{"checkout.seus_dados":"Your details","checkout.name":"Name","checkout.email":"Email","checkout.phone":"Phone","checkout.cpf":"Tax ID","checkout.coupon_label":"Discount coupon","checkout.coupon_placeholder":"Coupon code","checkout.submit_button":"Complete purchase","checkout.processing":"Processing\u2026","checkout.name_placeholder":"How you want to be called","checkout.email_placeholder":"your@email.com","checkout.phone_placeholder_br":"(11) 99999-9999","checkout.phone_placeholder_other":"Number","checkout.cpf_placeholder":"000.000.000-00","checkout.country_code_label":"Country code","checkout.summary_title":"Order summary","checkout.discount_coupon":"Discount (coupon)","checkout.total":"Total","checkout.secure_purchase":"100% secure purchase","checkout.voce_pode_gostar":"You may also like","checkout.voce_pode_gostar_subtitle":"Add these items to your order","checkout.deselect_all":"Deselect all","checkout.oferta_especial":"Special offer","checkout.total_a_pagar":"Total to pay","checkout.ver_mais":"See more","checkout.ver_menos":"See less","checkout.timer_text":"This offer expires in:","checkout.validating_coupon":"Validating coupon\u2026","checkout.forma_pagamento":"Payment method","checkout.gerar_pix":"Generate PIX","checkout.gerar_pix_auto":"Generate PIX (auto renewal)","checkout.pix_auto":"Automatic PIX","checkout.gerar_boleto":"Generate bank slip","checkout.corrija_erros":"Please fix the errors below before continuing.","checkout.preencher_dados_gerar_pix":"Fill in your details above and click \"Generate PIX\".","checkout.preencher_dados_gerar_boleto":"Fill in your details above and click \"Generate bank slip\".","checkout.preencher_e_gerar_pix":"Fill in name, email and CPF (if required) and click \"Generate PIX\" below.","checkout.preencher_e_gerar_boleto":"Fill in name, email and CPF (if required) and click \"Generate bank slip\" below.","checkout.editar_dados":"Edit details","checkout.dados_cartao":"Card details","checkout.card_holder":"Name on card","checkout.card_holder_placeholder":"As shown on card","checkout.card_number":"Card number","checkout.card_number_placeholder":"0000 0000 0000 0000","checkout.card_exp":"Expiry (MM\/YY)","checkout.card_exp_placeholder":"MM\/YYYY","checkout.card_cvv":"CVV","checkout.card_cvv_placeholder":"123","checkout.card_cvv_help":"3 or 4 digits on the back of the card","checkout.pagar_cartao":"Pay with card","checkout.card_not_configured":"Card payment is not configured.","checkout.card_fill_all":"Please fill in all card details correctly.","checkout.installments":"Number of installments","checkout.endereco_boleto":"Address for bank slip","checkout.endereco_boleto_cep":"ZIP code","checkout.endereco_boleto_buscar":"Search","checkout.endereco_boleto_numero":"Number","exit_popup.title":"Wait! We have a discount for you","exit_popup.description":"Use the coupon below in the next step","exit_popup.button_accept":"I want the discount","exit_popup.button_decline":"No, thanks","exit_popup.close":"Close","exit_popup.coupon_label":"Your coupon"},"es":{"checkout.seus_dados":"Tus datos","checkout.name":"Nombre","checkout.email":"Correo electr\u00f3nico","checkout.phone":"Tel\u00e9fono","checkout.cpf":"Documento","checkout.coupon_label":"Cup\u00f3n de descuento","checkout.coupon_placeholder":"C\u00f3digo del cup\u00f3n","checkout.submit_button":"Completar compra","checkout.processing":"Procesando\u2026","checkout.name_placeholder":"C\u00f3mo quieres que te llamen","checkout.email_placeholder":"tu@email.com","checkout.phone_placeholder_br":"(11) 99999-9999","checkout.phone_placeholder_other":"N\u00famero","checkout.cpf_placeholder":"000.000.000-00","checkout.country_code_label":"C\u00f3digo de pa\u00eds","checkout.summary_title":"Resumen del pedido","checkout.discount_coupon":"Descuento (cup\u00f3n)","checkout.total":"Total","checkout.secure_purchase":"Compra 100% segura","checkout.voce_pode_gostar":"Tambi\u00e9n te puede gustar","checkout.voce_pode_gostar_subtitle":"A\u00f1ade estos productos a tu compra","checkout.deselect_all":"Desmarcar todos","checkout.oferta_especial":"Oferta especial","checkout.total_a_pagar":"Total a pagar","checkout.ver_mais":"Ver m\u00e1s","checkout.ver_menos":"Ver menos","checkout.timer_text":"Esta oferta expira en:","checkout.validating_coupon":"Validando cup\u00f3n\u2026","checkout.forma_pagamento":"Forma de pago","checkout.gerar_pix":"Generar PIX","checkout.gerar_pix_auto":"Generar PIX (renovaci\u00f3n autom\u00e1tica)","checkout.pix_auto":"PIX autom\u00e1tico","checkout.gerar_boleto":"Generar boleto","checkout.corrija_erros":"Corrija los errores antes de continuar.","checkout.preencher_dados_gerar_pix":"Complete sus datos arriba y haga clic en \"Generar PIX\".","checkout.preencher_dados_gerar_boleto":"Complete sus datos arriba y haga clic en \"Generar boleto\".","checkout.preencher_e_gerar_pix":"Complete nombre, correo y CPF (si se solicita) y haga clic en \"Generar PIX\" abajo.","checkout.preencher_e_gerar_boleto":"Complete nombre, correo y CPF (si se solicita) y haga clic en \"Generar boleto\" abajo.","checkout.editar_dados":"Editar datos","checkout.dados_cartao":"Datos de la tarjeta","checkout.card_holder":"Nombre en la tarjeta","checkout.card_holder_placeholder":"Como aparece en la tarjeta","checkout.card_number":"N\u00famero de la tarjeta","checkout.card_number_placeholder":"0000 0000 0000 0000","checkout.card_exp":"Vencimiento (MM\/AA)","checkout.card_exp_placeholder":"MM\/AAAA","checkout.card_cvv":"CVV","checkout.card_cvv_placeholder":"123","checkout.card_cvv_help":"3 o 4 d\u00edgitos en el dorso de la tarjeta","checkout.pagar_cartao":"Pagar con tarjeta","checkout.card_not_configured":"El pago con tarjeta no est\u00e1 configurado.","checkout.card_fill_all":"Complete todos los datos de la tarjeta correctamente.","checkout.installments":"N\u00famero de cuotas","checkout.endereco_boleto":"Direcci\u00f3n para el boleto","checkout.endereco_boleto_cep":"C\u00f3digo postal","checkout.endereco_boleto_buscar":"Buscar","checkout.endereco_boleto_numero":"N\u00famero","exit_popup.title":"\u00a1Espera! Tenemos un descuento para ti","exit_popup.description":"Usa el cup\u00f3n abajo en el siguiente paso","exit_popup.button_accept":"Quiero el descuento","exit_popup.button_decline":"No, gracias","exit_popup.close":"Cerrar","exit_popup.coupon_label":"Tu cup\u00f3n"}}', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (18, NULL, 'storage_provider', 'local', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (19, NULL, 'storage_s3_key', '', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (20, NULL, 'storage_s3_bucket', '', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (21, NULL, 'storage_s3_region', 'us-east-1', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (22, NULL, 'storage_s3_endpoint', '', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (23, NULL, 'storage_s3_url', '', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (24, NULL, 'currencies', '[{"code":"BRL","symbol":"R$","label":"Real brasileiro","rate_to_brl":1},{"code":"USD","symbol":"US$","label":"D\u00f3lar americano","rate_to_brl":0.179999999999999993338661852249060757458209991455078125},{"code":"EUR","symbol":"\u20ac","label":"Euro","rate_to_brl":0.1600000000000000033306690738754696212708950042724609375}]', '2026-04-30 14:54:17', '2026-04-30 14:54:17');
INSERT INTO public.settings VALUES (14, NULL, 'sendgrid_mail_from_address', '', '2026-04-30 14:54:16', '2026-04-30 17:24:51');
INSERT INTO public.settings VALUES (15, NULL, 'sendgrid_mail_from_name', '', '2026-04-30 14:54:16', '2026-04-30 17:24:51');
INSERT INTO public.settings VALUES (2, NULL, 'email_provider', 'smtp', '2026-04-30 14:54:16', '2026-04-30 17:27:48');
INSERT INTO public.settings VALUES (16, NULL, 'kyc_notification_emails', 'contato@winfy.com.br', '2026-04-30 14:54:17', '2026-04-30 17:33:53');
INSERT INTO public.settings VALUES (25, NULL, 'merchant_fee_rules', '{"pix":{"percent":1.4899999999999999911182158029987476766109466552734375,"fixed":0},"card":{"percent":5.980000000000000426325641456060111522674560546875,"fixed":0},"boleto":{"percent":0,"fixed":4.4900000000000002131628207280300557613372802734375},"withdrawal":{"percent":0,"fixed":1.9899999999999999911182158029987476766109466552734375}}', '2026-04-30 18:27:40', '2026-04-30 18:27:40');


--
-- Data for Name: spedy_integration_product; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: spedy_integrations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.team_audit_logs VALUES (1, 4, 4, 'panel.produtos.store', NULL, NULL, '{"method":"POST","path":"\/produtos"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:02:42', '2026-04-30 16:02:42');
INSERT INTO public.team_audit_logs VALUES (2, 4, 4, 'panel.member-builder.sections.store', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/sections"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:03:52', '2026-04-30 16:03:52');
INSERT INTO public.team_audit_logs VALUES (3, 4, 4, 'panel.member-builder.sections.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/sections\/1"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:03:59', '2026-04-30 16:03:59');
INSERT INTO public.team_audit_logs VALUES (4, 4, 4, 'panel.member-builder.sections.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/sections\/1"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:04:18', '2026-04-30 16:04:18');
INSERT INTO public.team_audit_logs VALUES (5, 4, 4, 'panel.member-builder.modules.store', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/sections\/1\/modules"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:05:07', '2026-04-30 16:05:07');
INSERT INTO public.team_audit_logs VALUES (6, 4, 4, 'panel.member-builder.lessons.store', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/modules\/1\/lessons"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:11:24', '2026-04-30 16:11:24');
INSERT INTO public.team_audit_logs VALUES (7, 4, 4, 'panel.member-builder.lessons.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/lessons\/1"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:14:37', '2026-04-30 16:14:37');
INSERT INTO public.team_audit_logs VALUES (8, 4, 4, 'panel.member-builder.lessons.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/lessons\/1"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:17:28', '2026-04-30 16:17:28');
INSERT INTO public.team_audit_logs VALUES (9, 4, 4, 'panel.member-builder.lessons.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/lessons\/1"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:20:34', '2026-04-30 16:20:34');
INSERT INTO public.team_audit_logs VALUES (10, 4, 4, 'panel.member-builder.lessons.store', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/modules\/1\/lessons"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:21:24', '2026-04-30 16:21:24');
INSERT INTO public.team_audit_logs VALUES (11, 4, 4, 'panel.member-builder.turmas.store', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/turmas"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:23:12', '2026-04-30 16:23:12');
INSERT INTO public.team_audit_logs VALUES (12, 4, 4, 'panel.member-builder.turmas.destroy', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"DELETE","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/turmas\/2"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:23:19', '2026-04-30 16:23:19');
INSERT INTO public.team_audit_logs VALUES (13, 4, 4, 'panel.member-builder.config.update.post', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:26:11', '2026-04-30 16:26:11');
INSERT INTO public.team_audit_logs VALUES (14, 4, 4, 'panel.member-builder.config.update.post', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:27:49', '2026-04-30 16:27:49');
INSERT INTO public.team_audit_logs VALUES (15, 4, 4, 'panel.member-builder.lessons.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/lessons\/2"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:28:39', '2026-04-30 16:28:39');
INSERT INTO public.team_audit_logs VALUES (16, 4, 4, 'panel.member-builder.upload', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/upload"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:31:06', '2026-04-30 16:31:06');
INSERT INTO public.team_audit_logs VALUES (17, 4, 4, 'panel.member-builder.modules.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/modules\/1"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:31:07', '2026-04-30 16:31:07');
INSERT INTO public.team_audit_logs VALUES (18, 4, 4, 'panel.produtos.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:39:28', '2026-04-30 16:39:28');
INSERT INTO public.team_audit_logs VALUES (19, 4, 4, 'panel.member-builder.config.update.post', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 16:42:38', '2026-04-30 16:42:38');
INSERT INTO public.team_audit_logs VALUES (20, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '186.244.137.96', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:16:47', '2026-04-30 17:16:47');
INSERT INTO public.team_audit_logs VALUES (21, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '186.244.137.96', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:53:17', '2026-04-30 17:53:17');
INSERT INTO public.team_audit_logs VALUES (22, 4, 4, 'panel.produtos.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:54:14', '2026-04-30 17:54:14');
INSERT INTO public.team_audit_logs VALUES (23, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:58:05', '2026-04-30 17:58:05');
INSERT INTO public.team_audit_logs VALUES (24, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 17:59:34', '2026-04-30 17:59:34');
INSERT INTO public.team_audit_logs VALUES (25, 4, 4, 'panel.checkout.config.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/checkout-config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:00:25', '2026-04-30 18:00:25');
INSERT INTO public.team_audit_logs VALUES (26, 4, 4, 'panel.checkout.config.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/checkout-config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:01:00', '2026-04-30 18:01:00');
INSERT INTO public.team_audit_logs VALUES (27, 4, 4, 'panel.checkout.config.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/checkout-config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:13:42', '2026-04-30 18:13:42');
INSERT INTO public.team_audit_logs VALUES (28, 4, 4, 'panel.checkout.config.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/checkout-config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:15:15', '2026-04-30 18:15:15');
INSERT INTO public.team_audit_logs VALUES (29, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:20:08', '2026-04-30 18:20:08');
INSERT INTO public.team_audit_logs VALUES (30, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:29:03', '2026-04-30 18:29:03');
INSERT INTO public.team_audit_logs VALUES (31, 4, 4, 'panel.kyc.store', NULL, NULL, '{"method":"POST","path":"\/kyc"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:33:20', '2026-04-30 18:33:20');
INSERT INTO public.team_audit_logs VALUES (32, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '186.244.137.96', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:33:37', '2026-04-30 18:33:37');
INSERT INTO public.team_audit_logs VALUES (33, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:34:43', '2026-04-30 18:34:43');
INSERT INTO public.team_audit_logs VALUES (34, 4, 4, 'panel.financeiro.seller.saque', NULL, NULL, '{"method":"POST","path":"\/financeiro\/saque"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:35:11', '2026-04-30 18:35:11');
INSERT INTO public.team_audit_logs VALUES (35, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:36:08', '2026-04-30 18:36:08');
INSERT INTO public.team_audit_logs VALUES (36, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:44:31', '2026-04-30 18:44:31');
INSERT INTO public.team_audit_logs VALUES (37, 4, 4, 'panel.financeiro.seller.saque', NULL, NULL, '{"method":"POST","path":"\/financeiro\/saque"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:46:52', '2026-04-30 18:46:52');
INSERT INTO public.team_audit_logs VALUES (38, 4, 4, 'panel.financeiro.seller.saque', NULL, NULL, '{"method":"POST","path":"\/financeiro\/saque"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:47:02', '2026-04-30 18:47:02');
INSERT INTO public.team_audit_logs VALUES (39, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:47:42', '2026-04-30 18:47:42');
INSERT INTO public.team_audit_logs VALUES (40, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:55:05', '2026-04-30 18:55:05');
INSERT INTO public.team_audit_logs VALUES (41, 4, 4, 'panel.produtos.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62"}', '186.244.137.96', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:56:36', '2026-04-30 18:56:36');
INSERT INTO public.team_audit_logs VALUES (42, 4, 4, 'panel.member-builder.comments.update', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"PUT","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/comments\/1"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:56:56', '2026-04-30 18:56:56');
INSERT INTO public.team_audit_logs VALUES (43, 4, 4, 'panel.member-builder.config.update.post', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/config"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:57:49', '2026-04-30 18:57:49');
INSERT INTO public.team_audit_logs VALUES (44, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:d98e:ed68:c0be:ee7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-04-30 18:57:55', '2026-04-30 18:57:55');
INSERT INTO public.team_audit_logs VALUES (45, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:5465:85d8:28b5:badd', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36', '2026-04-30 21:21:58', '2026-04-30 21:21:58');
INSERT INTO public.team_audit_logs VALUES (46, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:5465:85d8:28b5:badd', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36', '2026-04-30 21:31:17', '2026-04-30 21:31:17');
INSERT INTO public.team_audit_logs VALUES (47, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:5465:85d8:28b5:badd', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36', '2026-04-30 21:31:37', '2026-04-30 21:31:37');
INSERT INTO public.team_audit_logs VALUES (48, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:5465:85d8:28b5:badd', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36', '2026-04-30 21:31:45', '2026-04-30 21:31:45');
INSERT INTO public.team_audit_logs VALUES (49, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:5465:85d8:28b5:badd', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36', '2026-04-30 21:36:27', '2026-04-30 21:36:27');
INSERT INTO public.team_audit_logs VALUES (50, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '186.244.137.96', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36', '2026-04-30 21:37:26', '2026-04-30 21:37:26');
INSERT INTO public.team_audit_logs VALUES (51, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:c132:f9fe:5f22:258c', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-01 14:42:47', '2026-05-01 14:42:47');
INSERT INTO public.team_audit_logs VALUES (52, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:c132:f9fe:5f22:258c', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '2026-05-01 14:43:21', '2026-05-01 14:43:21');
INSERT INTO public.team_audit_logs VALUES (53, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:ad25:b720:2252:bd31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 00:55:34', '2026-06-06 00:55:34');
INSERT INTO public.team_audit_logs VALUES (54, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:ad25:b720:2252:bd31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 00:57:12', '2026-06-06 00:57:12');
INSERT INTO public.team_audit_logs VALUES (55, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:ad25:b720:2252:bd31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 00:58:49', '2026-06-06 00:58:49');
INSERT INTO public.team_audit_logs VALUES (56, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:ad25:b720:2252:bd31', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:01:35', '2026-06-06 01:01:35');
INSERT INTO public.team_audit_logs VALUES (57, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:02:21', '2026-06-06 01:02:21');
INSERT INTO public.team_audit_logs VALUES (58, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:16:59', '2026-06-06 01:16:59');
INSERT INTO public.team_audit_logs VALUES (59, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:19:00', '2026-06-06 01:19:00');
INSERT INTO public.team_audit_logs VALUES (60, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:19:26', '2026-06-06 01:19:26');
INSERT INTO public.team_audit_logs VALUES (61, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:24:56', '2026-06-06 01:24:56');
INSERT INTO public.team_audit_logs VALUES (62, 4, 4, 'auth.logout', NULL, NULL, '{"method":"POST","path":"\/logout"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:26:48', '2026-06-06 01:26:48');
INSERT INTO public.team_audit_logs VALUES (63, 4, 4, 'auth.login', NULL, NULL, '{"method":"POST","path":"\/login"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:27:42', '2026-06-06 01:27:42');
INSERT INTO public.team_audit_logs VALUES (64, 4, 4, 'panel.api-applications.store', NULL, NULL, '{"method":"POST","path":"\/aplicacoes-api"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:30:33', '2026-06-06 01:30:33');
INSERT INTO public.team_audit_logs VALUES (65, 4, 4, 'panel.member-builder.lessons.store', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/modules\/1\/lessons"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:51:09', '2026-06-06 01:51:09');
INSERT INTO public.team_audit_logs VALUES (66, 4, 4, 'panel.member-builder.lessons.store', 'App\Models\Product', '45d8e4f6-1be9-4499-a71e-a57e2309cd62', '{"method":"POST","path":"\/produtos\/45d8e4f6-1be9-4499-a71e-a57e2309cd62\/member-builder\/modules\/1\/lessons"}', '2804:13c:60b:d00:3d56:da0b:5c4d:62b', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '2026-06-06 01:52:10', '2026-06-06 01:52:10');


--
-- Data for Name: team_role_product; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: team_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tenant_wallets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.tenant_wallets VALUES (1, 4, 0.00, 0.00, 'BRL', '2026-04-30 16:00:22', '2026-04-30 18:35:11', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, false, NULL, NULL, NULL);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users VALUES (7, 'ok', 'ok@ok.com', NULL, '$2y$12$Zlp7x3iZ20fac1F1CrwYw.iFxGILyPE0lHagdYR0HY9zic2B5wB/q', NULL, '2026-06-06 01:56:21', '2026-06-06 01:56:21', 'cliente', NULL, NULL, NULL, NULL, NULL, NULL, 'approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'not_submitted', NULL, NULL, NULL, NULL);
INSERT INTO public.users VALUES (3, 'Jader Brandao', 'jader.development@gmail.com', NULL, '$2y$12$KsAXopwB.4aWrQWPsrfExe8Gt1FD6GH/PyNFM32/3r3l363X/CSzu', 'hUqXSSMQI7nSkLmB56vntzGHGhCCzZI5HAjvbQQgWQNRqW8qykY537gbuaDi', '2026-04-30 15:31:02', '2026-06-06 01:18:54', 'platform_admin', NULL, NULL, NULL, NULL, NULL, NULL, 'approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'not_submitted', NULL, NULL, NULL, NULL);
INSERT INTO public.users VALUES (5, 'Contato Winfy', 'contato@winfy.com.br', NULL, '$2y$12$RE7C2cewtQ5XZ3WOwWkAK.1G5ORw10zUja6sWOrVirVxemDUQuf4C', NULL, '2026-04-30 18:03:59', '2026-04-30 18:03:59', 'cliente', NULL, NULL, NULL, NULL, NULL, NULL, 'approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'not_submitted', NULL, NULL, NULL, NULL);
INSERT INTO public.users VALUES (6, 'Jader Brandao', 'jaderbrandao@winfy.com.br', NULL, '$2y$12$5p47aptEvGr9Bo4jD.GmD.WkJT3O0rO/h8ri.tvTewv9nHALvCvW.', NULL, '2026-04-30 18:21:34', '2026-04-30 18:21:34', 'cliente', NULL, NULL, NULL, NULL, NULL, NULL, 'approved', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'not_submitted', NULL, NULL, NULL, NULL);
INSERT INTO public.users VALUES (4, 'Jader Brandao', 'jader_bs@hotmail.com', NULL, '$2y$12$yXkcn5f.OPQIr3A5dsj4JeBcu9T9GbjVgGCLIytWz0CVixW1bxSci', NULL, '2026-04-30 16:00:22', '2026-04-30 18:34:17', 'infoprodutor', 4, NULL, NULL, NULL, 'pf', '00316765376', 'approved', NULL, NULL, NULL, NULL, '1985-12-03', NULL, NULL, '22790671', 'Rua Silvia Pozzano', '2760', 'vp606', 'Recreio dos Bandeirantes', 'Rio de Janeiro', 'RJ', 'up_to_10k', 'approved', NULL, '2026-04-30 18:34:17', 3, '2026-04-30 16:00:22');


--
-- Data for Name: utmify_integration_product; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: utmify_integrations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.wallet_transactions VALUES (1, 4, 1, NULL, 'pix', 'credit_sale', 2.50, 0.00, 2.50, '{"coproduction":false,"coproduction_role":"seller","product_coproducer_id":null,"affiliate_enrollment_id":null,"payment_method":"pix","percent_applied":0,"fixed_applied":0}', '2026-04-30 18:05:03', '2026-04-30 18:05:03');
INSERT INTO public.wallet_transactions VALUES (2, 4, 2, NULL, 'pix', 'credit_sale', 2.50, 0.00, 2.50, '{"coproduction":false,"coproduction_role":"seller","product_coproducer_id":null,"affiliate_enrollment_id":null,"payment_method":"pix","percent_applied":0,"fixed_applied":0}', '2026-04-30 18:22:05', '2026-04-30 18:22:05');
INSERT INTO public.wallet_transactions VALUES (3, 4, NULL, 1, 'pix', 'withdrawal_request', 5.00, 1.99, 3.01, '{"phase":"request"}', '2026-04-30 18:35:11', '2026-04-30 18:35:11');


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: withdrawals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.withdrawals VALUES (1, 4, 4, 5.00, 'pending', NULL, 'BRL', '2026-04-30 18:35:11', '2026-04-30 18:35:11', NULL, NULL, NULL, false, 1.99, 3.01, 'pix');


--
-- Name: api_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_applications_id_seq', 1, true);


--
-- Name: api_checkout_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_checkout_sessions_id_seq', 1, true);


--
-- Name: branding_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.branding_settings_id_seq', 1, true);


--
-- Name: cademi_integration_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cademi_integration_product_id_seq', 1, false);


--
-- Name: cademi_integration_product_offer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cademi_integration_product_offer_id_seq', 1, false);


--
-- Name: cademi_integration_subscription_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cademi_integration_subscription_plan_id_seq', 1, false);


--
-- Name: cademi_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cademi_integrations_id_seq', 1, false);


--
-- Name: checkout_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.checkout_sessions_id_seq', 23, true);


--
-- Name: coupons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.coupons_id_seq', 1, false);


--
-- Name: email_campaign_sends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_campaign_sends_id_seq', 1, false);


--
-- Name: email_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_campaigns_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: gateway_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gateway_credentials_id_seq', 1, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 93, true);


--
-- Name: kyc_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kyc_documents_id_seq', 2, true);


--
-- Name: member_achievement_unlocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_achievement_unlocks_id_seq', 1, false);


--
-- Name: member_area_domains_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_area_domains_id_seq', 1, true);


--
-- Name: member_certificates_issued_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_certificates_issued_id_seq', 1, true);


--
-- Name: member_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_comments_id_seq', 3, true);


--
-- Name: member_community_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_community_pages_id_seq', 1, false);


--
-- Name: member_community_post_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_community_post_comments_id_seq', 1, false);


--
-- Name: member_community_post_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_community_post_likes_id_seq', 1, false);


--
-- Name: member_community_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_community_posts_id_seq', 1, false);


--
-- Name: member_internal_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_internal_products_id_seq', 1, false);


--
-- Name: member_lesson_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_lesson_progress_id_seq', 5, true);


--
-- Name: member_lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_lessons_id_seq', 4, true);


--
-- Name: member_modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_modules_id_seq', 1, true);


--
-- Name: member_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_notifications_id_seq', 1, false);


--
-- Name: member_push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_push_subscriptions_id_seq', 1, false);


--
-- Name: member_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_sections_id_seq', 1, true);


--
-- Name: member_turma_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_turma_user_id_seq', 1, false);


--
-- Name: member_turmas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_turmas_id_seq', 2, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 130, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 3, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orders_id_seq', 3, true);


--
-- Name: panel_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.panel_notifications_id_seq', 1, false);


--
-- Name: panel_push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.panel_push_subscriptions_id_seq', 1, false);


--
-- Name: platform_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_audit_logs_id_seq', 34, true);


--
-- Name: platform_languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_languages_id_seq', 3, true);


--
-- Name: platform_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.platform_translations_id_seq', 1473, true);


--
-- Name: product_affiliate_enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_affiliate_enrollments_id_seq', 1, false);


--
-- Name: product_coproducers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_coproducers_id_seq', 1, false);


--
-- Name: product_offers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_offers_id_seq', 1, false);


--
-- Name: product_order_bumps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_order_bumps_id_seq', 1, false);


--
-- Name: product_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_user_id_seq', 2, true);


--
-- Name: product_webhook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_webhook_id_seq', 1, false);


--
-- Name: refund_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.refund_requests_id_seq', 1, false);


--
-- Name: sales_achievements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_achievements_id_seq', 8, true);


--
-- Name: saved_payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.saved_payment_methods_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 25, true);


--
-- Name: spedy_integration_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spedy_integration_product_id_seq', 1, false);


--
-- Name: spedy_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spedy_integrations_id_seq', 1, false);


--
-- Name: subscription_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_plans_id_seq', 1, false);


--
-- Name: subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscriptions_id_seq', 1, false);


--
-- Name: team_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.team_audit_logs_id_seq', 66, true);


--
-- Name: team_role_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.team_role_product_id_seq', 1, false);


--
-- Name: team_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.team_roles_id_seq', 1, false);


--
-- Name: tenant_wallets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tenant_wallets_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: utmify_integration_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.utmify_integration_product_id_seq', 1, false);


--
-- Name: utmify_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.utmify_integrations_id_seq', 1, false);


--
-- Name: wallet_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wallet_transactions_id_seq', 3, true);


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhook_logs_id_seq', 1, false);


--
-- Name: webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_id_seq', 1, false);


--
-- Name: withdrawals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.withdrawals_id_seq', 1, true);


--
-- Name: api_applications api_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_applications
    ADD CONSTRAINT api_applications_pkey PRIMARY KEY (id);


--
-- Name: api_applications api_applications_tenant_id_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_applications
    ADD CONSTRAINT api_applications_tenant_id_slug_unique UNIQUE (tenant_id, slug);


--
-- Name: api_checkout_sessions api_checkout_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_checkout_sessions
    ADD CONSTRAINT api_checkout_sessions_pkey PRIMARY KEY (id);


--
-- Name: api_checkout_sessions api_checkout_sessions_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_checkout_sessions
    ADD CONSTRAINT api_checkout_sessions_session_token_unique UNIQUE (session_token);


--
-- Name: branding_settings branding_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_settings
    ADD CONSTRAINT branding_settings_pkey PRIMARY KEY (id);


--
-- Name: branding_settings branding_settings_tenant_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_settings
    ADD CONSTRAINT branding_settings_tenant_id_unique UNIQUE (tenant_id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: cademi_integration_product_offer cademi_int_offer_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product_offer
    ADD CONSTRAINT cademi_int_offer_unique UNIQUE (cademi_integration_id, product_offer_id);


--
-- Name: cademi_integration_subscription_plan cademi_int_plan_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_subscription_plan
    ADD CONSTRAINT cademi_int_plan_unique UNIQUE (cademi_integration_id, subscription_plan_id);


--
-- Name: cademi_integration_product cademi_int_product_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product
    ADD CONSTRAINT cademi_int_product_unique UNIQUE (cademi_integration_id, product_id);


--
-- Name: cademi_integration_product_offer cademi_integration_product_offer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product_offer
    ADD CONSTRAINT cademi_integration_product_offer_pkey PRIMARY KEY (id);


--
-- Name: cademi_integration_product cademi_integration_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product
    ADD CONSTRAINT cademi_integration_product_pkey PRIMARY KEY (id);


--
-- Name: cademi_integration_subscription_plan cademi_integration_subscription_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_subscription_plan
    ADD CONSTRAINT cademi_integration_subscription_plan_pkey PRIMARY KEY (id);


--
-- Name: cademi_integrations cademi_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integrations
    ADD CONSTRAINT cademi_integrations_pkey PRIMARY KEY (id);


--
-- Name: checkout_sessions checkout_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_sessions
    ADD CONSTRAINT checkout_sessions_pkey PRIMARY KEY (id);


--
-- Name: checkout_sessions checkout_sessions_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_sessions
    ADD CONSTRAINT checkout_sessions_session_token_unique UNIQUE (session_token);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_tenant_id_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_tenant_id_code_unique UNIQUE (tenant_id, code);


--
-- Name: email_campaign_sends email_campaign_sends_email_campaign_id_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaign_sends
    ADD CONSTRAINT email_campaign_sends_email_campaign_id_email_unique UNIQUE (email_campaign_id, email);


--
-- Name: email_campaign_sends email_campaign_sends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaign_sends
    ADD CONSTRAINT email_campaign_sends_pkey PRIMARY KEY (id);


--
-- Name: email_campaigns email_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaigns
    ADD CONSTRAINT email_campaigns_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: gateway_credentials gateway_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_credentials
    ADD CONSTRAINT gateway_credentials_pkey PRIMARY KEY (id);


--
-- Name: gateway_credentials gateway_credentials_tenant_id_gateway_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_credentials
    ADD CONSTRAINT gateway_credentials_tenant_id_gateway_slug_unique UNIQUE (tenant_id, gateway_slug);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: kyc_documents kyc_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_pkey PRIMARY KEY (id);


--
-- Name: kyc_documents kyc_documents_public_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_public_token_unique UNIQUE (public_token);


--
-- Name: member_community_post_likes mc_post_likes_post_user_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_likes
    ADD CONSTRAINT mc_post_likes_post_user_unique UNIQUE (member_community_post_id, user_id);


--
-- Name: member_achievement_unlocks member_achievement_unlocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_achievement_unlocks
    ADD CONSTRAINT member_achievement_unlocks_pkey PRIMARY KEY (id);


--
-- Name: member_area_domains member_area_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_area_domains
    ADD CONSTRAINT member_area_domains_pkey PRIMARY KEY (id);


--
-- Name: member_certificates_issued member_certificates_issued_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_certificates_issued
    ADD CONSTRAINT member_certificates_issued_pkey PRIMARY KEY (id);


--
-- Name: member_comments member_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_comments
    ADD CONSTRAINT member_comments_pkey PRIMARY KEY (id);


--
-- Name: member_community_pages member_community_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_pages
    ADD CONSTRAINT member_community_pages_pkey PRIMARY KEY (id);


--
-- Name: member_community_post_comments member_community_post_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_comments
    ADD CONSTRAINT member_community_post_comments_pkey PRIMARY KEY (id);


--
-- Name: member_community_post_likes member_community_post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_likes
    ADD CONSTRAINT member_community_post_likes_pkey PRIMARY KEY (id);


--
-- Name: member_community_posts member_community_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_posts
    ADD CONSTRAINT member_community_posts_pkey PRIMARY KEY (id);


--
-- Name: member_internal_products member_internal_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_internal_products
    ADD CONSTRAINT member_internal_products_pkey PRIMARY KEY (id);


--
-- Name: member_lesson_progress member_lesson_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lesson_progress
    ADD CONSTRAINT member_lesson_progress_pkey PRIMARY KEY (id);


--
-- Name: member_lesson_progress member_lesson_progress_user_id_member_lesson_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lesson_progress
    ADD CONSTRAINT member_lesson_progress_user_id_member_lesson_id_unique UNIQUE (user_id, member_lesson_id);


--
-- Name: member_lessons member_lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lessons
    ADD CONSTRAINT member_lessons_pkey PRIMARY KEY (id);


--
-- Name: member_modules member_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_modules
    ADD CONSTRAINT member_modules_pkey PRIMARY KEY (id);


--
-- Name: member_notifications member_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_notifications
    ADD CONSTRAINT member_notifications_pkey PRIMARY KEY (id);


--
-- Name: member_push_subscriptions member_push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_push_subscriptions
    ADD CONSTRAINT member_push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: member_sections member_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_sections
    ADD CONSTRAINT member_sections_pkey PRIMARY KEY (id);


--
-- Name: member_turma_user member_turma_user_member_turma_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turma_user
    ADD CONSTRAINT member_turma_user_member_turma_id_user_id_unique UNIQUE (member_turma_id, user_id);


--
-- Name: member_turma_user member_turma_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turma_user
    ADD CONSTRAINT member_turma_user_pkey PRIMARY KEY (id);


--
-- Name: member_turmas member_turmas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turmas
    ADD CONSTRAINT member_turmas_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_public_reference_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_public_reference_unique UNIQUE (public_reference);


--
-- Name: panel_notifications panel_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.panel_notifications
    ADD CONSTRAINT panel_notifications_pkey PRIMARY KEY (id);


--
-- Name: panel_push_subscriptions panel_push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.panel_push_subscriptions
    ADD CONSTRAINT panel_push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: platform_audit_logs platform_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: platform_languages platform_languages_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_languages
    ADD CONSTRAINT platform_languages_code_unique UNIQUE (code);


--
-- Name: platform_languages platform_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_languages
    ADD CONSTRAINT platform_languages_pkey PRIMARY KEY (id);


--
-- Name: platform_translations platform_translations_group_key_locale_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_translations
    ADD CONSTRAINT platform_translations_group_key_locale_unique UNIQUE ("group", key, locale);


--
-- Name: platform_translations platform_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_translations
    ADD CONSTRAINT platform_translations_pkey PRIMARY KEY (id);


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (slug);


--
-- Name: product_affiliate_enrollments product_affiliate_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_affiliate_enrollments
    ADD CONSTRAINT product_affiliate_enrollments_pkey PRIMARY KEY (id);


--
-- Name: product_affiliate_enrollments product_affiliate_enrollments_product_id_affiliate_user_id_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_affiliate_enrollments
    ADD CONSTRAINT product_affiliate_enrollments_product_id_affiliate_user_id_uniq UNIQUE (product_id, affiliate_user_id);


--
-- Name: product_affiliate_enrollments product_affiliate_enrollments_public_ref_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_affiliate_enrollments
    ADD CONSTRAINT product_affiliate_enrollments_public_ref_unique UNIQUE (public_ref);


--
-- Name: product_coproducers product_coproducers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_coproducers
    ADD CONSTRAINT product_coproducers_pkey PRIMARY KEY (id);


--
-- Name: product_coproducers product_coproducers_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_coproducers
    ADD CONSTRAINT product_coproducers_token_unique UNIQUE (token);


--
-- Name: product_offers product_offers_checkout_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_offers
    ADD CONSTRAINT product_offers_checkout_slug_unique UNIQUE (checkout_slug);


--
-- Name: product_offers product_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_offers
    ADD CONSTRAINT product_offers_pkey PRIMARY KEY (id);


--
-- Name: product_order_bumps product_order_bumps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_order_bumps
    ADD CONSTRAINT product_order_bumps_pkey PRIMARY KEY (id);


--
-- Name: product_user product_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_user
    ADD CONSTRAINT product_user_pkey PRIMARY KEY (id);


--
-- Name: product_webhook product_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_webhook
    ADD CONSTRAINT product_webhook_pkey PRIMARY KEY (id);


--
-- Name: product_webhook product_webhook_product_id_webhook_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_webhook
    ADD CONSTRAINT product_webhook_product_id_webhook_id_unique UNIQUE (product_id, webhook_id);


--
-- Name: products products_checkout_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_checkout_slug_unique UNIQUE (checkout_slug);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_tenant_id_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_tenant_id_slug_unique UNIQUE (tenant_id, slug);


--
-- Name: refund_requests refund_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_requests
    ADD CONSTRAINT refund_requests_pkey PRIMARY KEY (id);


--
-- Name: sales_achievements sales_achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_achievements
    ADD CONSTRAINT sales_achievements_pkey PRIMARY KEY (id);


--
-- Name: sales_achievements sales_achievements_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_achievements
    ADD CONSTRAINT sales_achievements_slug_unique UNIQUE (slug);


--
-- Name: saved_payment_methods saved_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_payment_methods
    ADD CONSTRAINT saved_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_tenant_id_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_tenant_id_key_unique UNIQUE (tenant_id, key);


--
-- Name: spedy_integration_product spedy_int_product_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spedy_integration_product
    ADD CONSTRAINT spedy_int_product_unique UNIQUE (spedy_integration_id, product_id);


--
-- Name: spedy_integration_product spedy_integration_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spedy_integration_product
    ADD CONSTRAINT spedy_integration_product_pkey PRIMARY KEY (id);


--
-- Name: spedy_integrations spedy_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spedy_integrations
    ADD CONSTRAINT spedy_integrations_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_checkout_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_checkout_slug_unique UNIQUE (checkout_slug);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_renewal_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_renewal_token_unique UNIQUE (renewal_token);


--
-- Name: team_audit_logs team_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_audit_logs
    ADD CONSTRAINT team_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: team_role_product team_role_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_role_product
    ADD CONSTRAINT team_role_product_pkey PRIMARY KEY (id);


--
-- Name: team_role_product team_role_product_team_role_id_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_role_product
    ADD CONSTRAINT team_role_product_team_role_id_product_id_unique UNIQUE (team_role_id, product_id);


--
-- Name: team_roles team_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_roles
    ADD CONSTRAINT team_roles_pkey PRIMARY KEY (id);


--
-- Name: team_roles team_roles_tenant_id_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_roles
    ADD CONSTRAINT team_roles_tenant_id_name_unique UNIQUE (tenant_id, name);


--
-- Name: tenant_wallets tenant_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_wallets
    ADD CONSTRAINT tenant_wallets_pkey PRIMARY KEY (id);


--
-- Name: tenant_wallets tenant_wallets_tenant_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_wallets
    ADD CONSTRAINT tenant_wallets_tenant_id_unique UNIQUE (tenant_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: utmify_integration_product utmify_int_product_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utmify_integration_product
    ADD CONSTRAINT utmify_int_product_unique UNIQUE (utmify_integration_id, product_id);


--
-- Name: utmify_integration_product utmify_integration_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utmify_integration_product
    ADD CONSTRAINT utmify_integration_product_pkey PRIMARY KEY (id);


--
-- Name: utmify_integrations utmify_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utmify_integrations
    ADD CONSTRAINT utmify_integrations_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: withdrawals withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_pkey PRIMARY KEY (id);


--
-- Name: api_applications_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX api_applications_slug_index ON public.api_applications USING btree (slug);


--
-- Name: api_applications_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX api_applications_tenant_id_index ON public.api_applications USING btree (tenant_id);


--
-- Name: api_checkout_sessions_api_application_id_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX api_checkout_sessions_api_application_id_expires_at_index ON public.api_checkout_sessions USING btree (api_application_id, expires_at);


--
-- Name: api_checkout_sessions_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX api_checkout_sessions_tenant_id_index ON public.api_checkout_sessions USING btree (tenant_id);


--
-- Name: cache_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);


--
-- Name: cache_locks_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);


--
-- Name: cademi_integrations_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cademi_integrations_tenant_id_index ON public.cademi_integrations USING btree (tenant_id);


--
-- Name: checkout_sessions_tenant_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_sessions_tenant_id_created_at_index ON public.checkout_sessions USING btree (tenant_id, created_at);


--
-- Name: checkout_sessions_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_sessions_tenant_id_index ON public.checkout_sessions USING btree (tenant_id);


--
-- Name: checkout_sessions_tenant_id_step_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX checkout_sessions_tenant_id_step_index ON public.checkout_sessions USING btree (tenant_id, step);


--
-- Name: coupons_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX coupons_tenant_id_index ON public.coupons USING btree (tenant_id);


--
-- Name: email_campaign_sends_email_campaign_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_campaign_sends_email_campaign_id_index ON public.email_campaign_sends USING btree (email_campaign_id);


--
-- Name: email_campaigns_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_campaigns_status_index ON public.email_campaigns USING btree (status);


--
-- Name: email_campaigns_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_campaigns_tenant_id_index ON public.email_campaigns USING btree (tenant_id);


--
-- Name: gateway_credentials_gateway_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gateway_credentials_gateway_slug_index ON public.gateway_credentials USING btree (gateway_slug);


--
-- Name: gateway_credentials_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gateway_credentials_tenant_id_index ON public.gateway_credentials USING btree (tenant_id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: kyc_documents_user_id_kind_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kyc_documents_user_id_kind_index ON public.kyc_documents USING btree (user_id, kind);


--
-- Name: member_community_pages_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_community_pages_slug_index ON public.member_community_pages USING btree (slug);


--
-- Name: member_community_post_comments_member_community_post_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_community_post_comments_member_community_post_id_index ON public.member_community_post_comments USING btree (member_community_post_id);


--
-- Name: member_community_posts_member_community_page_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_community_posts_member_community_page_id_index ON public.member_community_posts USING btree (member_community_page_id);


--
-- Name: member_notifications_product_id_user_id_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_notifications_product_id_user_id_read_at_index ON public.member_notifications USING btree (product_id, user_id, read_at);


--
-- Name: member_notifications_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_notifications_type_index ON public.member_notifications USING btree (type);


--
-- Name: member_notifications_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_notifications_user_id_created_at_index ON public.member_notifications USING btree (user_id, created_at);


--
-- Name: order_items_order_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX order_items_order_id_index ON public.order_items USING btree (order_id);


--
-- Name: orders_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX orders_tenant_id_index ON public.orders USING btree (tenant_id);


--
-- Name: panel_notifications_event_key_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX panel_notifications_event_key_index ON public.panel_notifications USING btree (event_key);


--
-- Name: panel_notifications_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX panel_notifications_tenant_id_index ON public.panel_notifications USING btree (tenant_id);


--
-- Name: panel_notifications_tenant_id_user_id_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX panel_notifications_tenant_id_user_id_read_at_index ON public.panel_notifications USING btree (tenant_id, user_id, read_at);


--
-- Name: panel_notifications_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX panel_notifications_type_index ON public.panel_notifications USING btree (type);


--
-- Name: panel_notifications_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX panel_notifications_user_id_created_at_index ON public.panel_notifications USING btree (user_id, created_at);


--
-- Name: panel_push_subscriptions_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX panel_push_subscriptions_tenant_id_index ON public.panel_push_subscriptions USING btree (tenant_id);


--
-- Name: panel_push_subscriptions_user_id_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX panel_push_subscriptions_user_id_tenant_id_index ON public.panel_push_subscriptions USING btree (user_id, tenant_id);


--
-- Name: platform_audit_logs_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX platform_audit_logs_action_index ON public.platform_audit_logs USING btree (action);


--
-- Name: platform_translations_group_locale_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX platform_translations_group_locale_idx ON public.platform_translations USING btree ("group", locale);


--
-- Name: product_affiliate_enrollments_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_affiliate_enrollments_status_index ON public.product_affiliate_enrollments USING btree (status);


--
-- Name: product_coproducers_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_coproducers_email_index ON public.product_coproducers USING btree (email);


--
-- Name: product_coproducers_product_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_coproducers_product_id_status_index ON public.product_coproducers USING btree (product_id, status);


--
-- Name: product_order_bumps_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_order_bumps_product_id_index ON public.product_order_bumps USING btree (product_id);


--
-- Name: products_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_slug_index ON public.products USING btree (slug);


--
-- Name: products_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_tenant_id_index ON public.products USING btree (tenant_id);


--
-- Name: refund_requests_tenant_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refund_requests_tenant_id_status_index ON public.refund_requests USING btree (tenant_id, status);


--
-- Name: refund_requests_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refund_requests_user_id_status_index ON public.refund_requests USING btree (user_id, status);


--
-- Name: saved_payment_methods_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX saved_payment_methods_tenant_id_index ON public.saved_payment_methods USING btree (tenant_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: settings_key_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX settings_key_index ON public.settings USING btree (key);


--
-- Name: settings_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX settings_tenant_id_index ON public.settings USING btree (tenant_id);


--
-- Name: spedy_integrations_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spedy_integrations_tenant_id_index ON public.spedy_integrations USING btree (tenant_id);


--
-- Name: subscriptions_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_tenant_id_index ON public.subscriptions USING btree (tenant_id);


--
-- Name: team_audit_logs_action_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_audit_logs_action_index ON public.team_audit_logs USING btree (action);


--
-- Name: team_audit_logs_actor_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_audit_logs_actor_user_id_index ON public.team_audit_logs USING btree (actor_user_id);


--
-- Name: team_audit_logs_target_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_audit_logs_target_id_index ON public.team_audit_logs USING btree (target_id);


--
-- Name: team_audit_logs_target_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_audit_logs_target_type_index ON public.team_audit_logs USING btree (target_type);


--
-- Name: team_audit_logs_tenant_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_audit_logs_tenant_id_created_at_index ON public.team_audit_logs USING btree (tenant_id, created_at);


--
-- Name: team_audit_logs_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_audit_logs_tenant_id_index ON public.team_audit_logs USING btree (tenant_id);


--
-- Name: team_roles_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_roles_tenant_id_index ON public.team_roles USING btree (tenant_id);


--
-- Name: users_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_tenant_id_index ON public.users USING btree (tenant_id);


--
-- Name: utmify_integrations_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX utmify_integrations_tenant_id_index ON public.utmify_integrations USING btree (tenant_id);


--
-- Name: wallet_transactions_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wallet_transactions_tenant_id_index ON public.wallet_transactions USING btree (tenant_id);


--
-- Name: wallet_transactions_withdrawal_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wallet_transactions_withdrawal_id_index ON public.wallet_transactions USING btree (withdrawal_id);


--
-- Name: webhook_logs_webhook_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_logs_webhook_id_created_at_index ON public.webhook_logs USING btree (webhook_id, created_at);


--
-- Name: webhooks_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_tenant_id_index ON public.webhooks USING btree (tenant_id);


--
-- Name: withdrawals_payout_external_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX withdrawals_payout_external_id_index ON public.withdrawals USING btree (payout_external_id);


--
-- Name: withdrawals_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX withdrawals_status_index ON public.withdrawals USING btree (status);


--
-- Name: withdrawals_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX withdrawals_tenant_id_index ON public.withdrawals USING btree (tenant_id);


--
-- Name: api_checkout_sessions api_checkout_sessions_api_application_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_checkout_sessions
    ADD CONSTRAINT api_checkout_sessions_api_application_id_foreign FOREIGN KEY (api_application_id) REFERENCES public.api_applications(id) ON DELETE CASCADE;


--
-- Name: cademi_integration_subscription_plan cad_int_plan_int_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_subscription_plan
    ADD CONSTRAINT cad_int_plan_int_fk FOREIGN KEY (cademi_integration_id) REFERENCES public.cademi_integrations(id) ON DELETE CASCADE;


--
-- Name: cademi_integration_subscription_plan cad_int_plan_plan_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_subscription_plan
    ADD CONSTRAINT cad_int_plan_plan_fk FOREIGN KEY (subscription_plan_id) REFERENCES public.subscription_plans(id) ON DELETE CASCADE;


--
-- Name: cademi_integration_product cademi_integration_product_cademi_integration_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product
    ADD CONSTRAINT cademi_integration_product_cademi_integration_id_foreign FOREIGN KEY (cademi_integration_id) REFERENCES public.cademi_integrations(id) ON DELETE CASCADE;


--
-- Name: cademi_integration_product_offer cademi_integration_product_offer_cademi_integration_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product_offer
    ADD CONSTRAINT cademi_integration_product_offer_cademi_integration_id_foreign FOREIGN KEY (cademi_integration_id) REFERENCES public.cademi_integrations(id) ON DELETE CASCADE;


--
-- Name: cademi_integration_product_offer cademi_integration_product_offer_product_offer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product_offer
    ADD CONSTRAINT cademi_integration_product_offer_product_offer_id_foreign FOREIGN KEY (product_offer_id) REFERENCES public.product_offers(id) ON DELETE CASCADE;


--
-- Name: cademi_integration_product cademi_integration_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cademi_integration_product
    ADD CONSTRAINT cademi_integration_product_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: checkout_sessions checkout_sessions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_sessions
    ADD CONSTRAINT checkout_sessions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: coupon_product coupon_product_coupon_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupon_product
    ADD CONSTRAINT coupon_product_coupon_id_foreign FOREIGN KEY (coupon_id) REFERENCES public.coupons(id) ON DELETE CASCADE;


--
-- Name: coupon_product coupon_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupon_product
    ADD CONSTRAINT coupon_product_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: coupons coupons_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: email_campaign_sends email_campaign_sends_email_campaign_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_campaign_sends
    ADD CONSTRAINT email_campaign_sends_email_campaign_id_foreign FOREIGN KEY (email_campaign_id) REFERENCES public.email_campaigns(id) ON DELETE CASCADE;


--
-- Name: kyc_documents kyc_documents_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kyc_documents
    ADD CONSTRAINT kyc_documents_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_achievement_unlocks member_achievement_unlocks_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_achievement_unlocks
    ADD CONSTRAINT member_achievement_unlocks_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_achievement_unlocks member_achievement_unlocks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_achievement_unlocks
    ADD CONSTRAINT member_achievement_unlocks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_area_domains member_area_domains_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_area_domains
    ADD CONSTRAINT member_area_domains_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_certificates_issued member_certificates_issued_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_certificates_issued
    ADD CONSTRAINT member_certificates_issued_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_certificates_issued member_certificates_issued_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_certificates_issued
    ADD CONSTRAINT member_certificates_issued_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_comments member_comments_member_lesson_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_comments
    ADD CONSTRAINT member_comments_member_lesson_id_foreign FOREIGN KEY (member_lesson_id) REFERENCES public.member_lessons(id) ON DELETE SET NULL;


--
-- Name: member_comments member_comments_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_comments
    ADD CONSTRAINT member_comments_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.member_comments(id) ON DELETE SET NULL;


--
-- Name: member_comments member_comments_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_comments
    ADD CONSTRAINT member_comments_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_comments member_comments_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_comments
    ADD CONSTRAINT member_comments_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: member_comments member_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_comments
    ADD CONSTRAINT member_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_community_pages member_community_pages_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_pages
    ADD CONSTRAINT member_community_pages_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_community_post_comments member_community_post_comments_member_community_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_comments
    ADD CONSTRAINT member_community_post_comments_member_community_post_id_foreign FOREIGN KEY (member_community_post_id) REFERENCES public.member_community_posts(id) ON DELETE CASCADE;


--
-- Name: member_community_post_comments member_community_post_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_comments
    ADD CONSTRAINT member_community_post_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_community_post_likes member_community_post_likes_member_community_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_likes
    ADD CONSTRAINT member_community_post_likes_member_community_post_id_foreign FOREIGN KEY (member_community_post_id) REFERENCES public.member_community_posts(id) ON DELETE CASCADE;


--
-- Name: member_community_post_likes member_community_post_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_post_likes
    ADD CONSTRAINT member_community_post_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_community_posts member_community_posts_member_community_page_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_posts
    ADD CONSTRAINT member_community_posts_member_community_page_id_foreign FOREIGN KEY (member_community_page_id) REFERENCES public.member_community_pages(id) ON DELETE CASCADE;


--
-- Name: member_community_posts member_community_posts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_community_posts
    ADD CONSTRAINT member_community_posts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_internal_products member_internal_products_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_internal_products
    ADD CONSTRAINT member_internal_products_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_internal_products member_internal_products_related_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_internal_products
    ADD CONSTRAINT member_internal_products_related_product_id_foreign FOREIGN KEY (related_product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: member_lesson_progress member_lesson_progress_member_lesson_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lesson_progress
    ADD CONSTRAINT member_lesson_progress_member_lesson_id_foreign FOREIGN KEY (member_lesson_id) REFERENCES public.member_lessons(id) ON DELETE CASCADE;


--
-- Name: member_lesson_progress member_lesson_progress_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lesson_progress
    ADD CONSTRAINT member_lesson_progress_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_lesson_progress member_lesson_progress_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lesson_progress
    ADD CONSTRAINT member_lesson_progress_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_lessons member_lessons_member_module_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lessons
    ADD CONSTRAINT member_lessons_member_module_id_foreign FOREIGN KEY (member_module_id) REFERENCES public.member_modules(id) ON DELETE CASCADE;


--
-- Name: member_lessons member_lessons_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_lessons
    ADD CONSTRAINT member_lessons_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_modules member_modules_member_section_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_modules
    ADD CONSTRAINT member_modules_member_section_id_foreign FOREIGN KEY (member_section_id) REFERENCES public.member_sections(id) ON DELETE CASCADE;


--
-- Name: member_modules member_modules_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_modules
    ADD CONSTRAINT member_modules_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_modules member_modules_related_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_modules
    ADD CONSTRAINT member_modules_related_product_id_foreign FOREIGN KEY (related_product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: member_notifications member_notifications_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_notifications
    ADD CONSTRAINT member_notifications_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_notifications member_notifications_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_notifications
    ADD CONSTRAINT member_notifications_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_push_subscriptions member_push_subscriptions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_push_subscriptions
    ADD CONSTRAINT member_push_subscriptions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_push_subscriptions member_push_subscriptions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_push_subscriptions
    ADD CONSTRAINT member_push_subscriptions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_sections member_sections_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_sections
    ADD CONSTRAINT member_sections_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: member_turma_user member_turma_user_member_turma_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turma_user
    ADD CONSTRAINT member_turma_user_member_turma_id_foreign FOREIGN KEY (member_turma_id) REFERENCES public.member_turmas(id) ON DELETE CASCADE;


--
-- Name: member_turma_user member_turma_user_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turma_user
    ADD CONSTRAINT member_turma_user_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: member_turmas member_turmas_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_turmas
    ADD CONSTRAINT member_turmas_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_offer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_offer_id_foreign FOREIGN KEY (product_offer_id) REFERENCES public.product_offers(id) ON DELETE SET NULL;


--
-- Name: order_items order_items_subscription_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_subscription_plan_id_foreign FOREIGN KEY (subscription_plan_id) REFERENCES public.subscription_plans(id) ON DELETE SET NULL;


--
-- Name: orders orders_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: orders orders_product_offer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_product_offer_id_foreign FOREIGN KEY (product_offer_id) REFERENCES public.product_offers(id) ON DELETE SET NULL;


--
-- Name: orders orders_subscription_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_subscription_plan_id_foreign FOREIGN KEY (subscription_plan_id) REFERENCES public.subscription_plans(id) ON DELETE SET NULL;


--
-- Name: orders orders_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: panel_notifications panel_notifications_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.panel_notifications
    ADD CONSTRAINT panel_notifications_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: panel_push_subscriptions panel_push_subscriptions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.panel_push_subscriptions
    ADD CONSTRAINT panel_push_subscriptions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: platform_audit_logs platform_audit_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_audit_logs
    ADD CONSTRAINT platform_audit_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: product_affiliate_enrollments product_affiliate_enrollments_affiliate_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_affiliate_enrollments
    ADD CONSTRAINT product_affiliate_enrollments_affiliate_user_id_foreign FOREIGN KEY (affiliate_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: product_affiliate_enrollments product_affiliate_enrollments_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_affiliate_enrollments
    ADD CONSTRAINT product_affiliate_enrollments_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_coproducers product_coproducers_co_producer_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_coproducers
    ADD CONSTRAINT product_coproducers_co_producer_user_id_foreign FOREIGN KEY (co_producer_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: product_coproducers product_coproducers_inviter_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_coproducers
    ADD CONSTRAINT product_coproducers_inviter_user_id_foreign FOREIGN KEY (inviter_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: product_coproducers product_coproducers_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_coproducers
    ADD CONSTRAINT product_coproducers_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_offers product_offers_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_offers
    ADD CONSTRAINT product_offers_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_order_bumps product_order_bumps_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_order_bumps
    ADD CONSTRAINT product_order_bumps_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_order_bumps product_order_bumps_target_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_order_bumps
    ADD CONSTRAINT product_order_bumps_target_product_id_foreign FOREIGN KEY (target_product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_order_bumps product_order_bumps_target_product_offer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_order_bumps
    ADD CONSTRAINT product_order_bumps_target_product_offer_id_foreign FOREIGN KEY (target_product_offer_id) REFERENCES public.product_offers(id) ON DELETE SET NULL;


--
-- Name: product_user product_user_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_user
    ADD CONSTRAINT product_user_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_user product_user_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_user
    ADD CONSTRAINT product_user_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: product_webhook product_webhook_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_webhook
    ADD CONSTRAINT product_webhook_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_webhook product_webhook_webhook_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_webhook
    ADD CONSTRAINT product_webhook_webhook_id_foreign FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: refund_requests refund_requests_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_requests
    ADD CONSTRAINT refund_requests_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: refund_requests refund_requests_resolved_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_requests
    ADD CONSTRAINT refund_requests_resolved_by_user_id_foreign FOREIGN KEY (resolved_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: refund_requests refund_requests_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refund_requests
    ADD CONSTRAINT refund_requests_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: saved_payment_methods saved_payment_methods_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_payment_methods
    ADD CONSTRAINT saved_payment_methods_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: spedy_integration_product spedy_integration_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spedy_integration_product
    ADD CONSTRAINT spedy_integration_product_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: spedy_integration_product spedy_integration_product_spedy_integration_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spedy_integration_product
    ADD CONSTRAINT spedy_integration_product_spedy_integration_id_foreign FOREIGN KEY (spedy_integration_id) REFERENCES public.spedy_integrations(id) ON DELETE CASCADE;


--
-- Name: subscription_plans subscription_plans_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_saved_payment_method_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_saved_payment_method_id_foreign FOREIGN KEY (saved_payment_method_id) REFERENCES public.saved_payment_methods(id) ON DELETE SET NULL;


--
-- Name: subscriptions subscriptions_subscription_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_subscription_plan_id_foreign FOREIGN KEY (subscription_plan_id) REFERENCES public.subscription_plans(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: team_audit_logs team_audit_logs_actor_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_audit_logs
    ADD CONSTRAINT team_audit_logs_actor_user_id_foreign FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: team_role_product team_role_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_role_product
    ADD CONSTRAINT team_role_product_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: team_role_product team_role_product_team_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_role_product
    ADD CONSTRAINT team_role_product_team_role_id_foreign FOREIGN KEY (team_role_id) REFERENCES public.team_roles(id) ON DELETE CASCADE;


--
-- Name: users users_kyc_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_kyc_reviewed_by_foreign FOREIGN KEY (kyc_reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_team_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_role_id_foreign FOREIGN KEY (team_role_id) REFERENCES public.team_roles(id) ON DELETE SET NULL;


--
-- Name: utmify_integration_product utmify_integration_product_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utmify_integration_product
    ADD CONSTRAINT utmify_integration_product_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: utmify_integration_product utmify_integration_product_utmify_integration_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.utmify_integration_product
    ADD CONSTRAINT utmify_integration_product_utmify_integration_id_foreign FOREIGN KEY (utmify_integration_id) REFERENCES public.utmify_integrations(id) ON DELETE CASCADE;


--
-- Name: wallet_transactions wallet_transactions_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: webhook_logs webhook_logs_webhook_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_webhook_id_foreign FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: withdrawals withdrawals_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO winfy;


--
-- PostgreSQL database dump complete
--

\unrestrict mjlx64shom0GQxreFF10m7cbfBuO5ONgR1qZQqTg6L4ysBEoJ1azP4Tpkdx8Oms

